# A Dockerized Python Flask app on top of Openshift 4 

Create a very simple hello world Python app with Flask framework, containerized it, and deploy it into Openshift 4.

Happy Coding , Simplicity is essential. 

[Deploying a simple Python app to Kubernetes/OpenShift | JJ Asghar | Conf42 Python 2022](https://www.youtube.com/watch?v=t6r3SgK-bDQ)

[Gunicorn is een pure Python HTTP-server voor WSGI-applicaties. Hiermee kunt je elke Python-toepassing gelijktijdig uitvoeren door meerdere Python-processen binnen één enkele dyno uit te voeren. Het biedt een perfecte balans tussen prestaties, flexibiliteit en eenvoud van configuratie](https://developers.redhat.com/articles/2023/08/17/how-deploy-flask-application-python-gunicorn#the_application)


- Parameterize SparQL queries with Python variables.
- Make sure “Run All” produces no image - crasbacklooperrors after fetch-build-deploy in k8s openshift 
- Follow the twelfe Principles of AGILE   Release early Release often  Working software -is the- Primary measure of progress

[SPARQL Tutorial 1 - Introducing SPARQL](https://www.youtube.com/watch?v=nbUYrs_wWto&list=PLaa8QYrMzXNnzY-4YVM5507iZuESWVcnU)

[SPARQL Tutorial 2 - Our first select query](https://www.youtube.com/watch?v=xYDS7InaFZM&list=PLaa8QYrMzXNnzY-4YVM5507iZuESWVcnU&index=2)

[SPARQL Tutorial 3 - Triple Patterns](https://www.youtube.com/watch?v=-Z2y6LeNacw&list=PLaa8QYrMzXNnzY-4YVM5507iZuESWVcnU&index=3)

[SPARQL Tutorial 4 - Bind](https://www.youtube.com/watch?v=4MjAbt9C61Y&list=PLaa8QYrMzXNnzY-4YVM5507iZuESWVcnU&index=4)

[SPARQL Tutorial 5 - Group Patterns](https://www.youtube.com/watch?v=RT1C_ZoxJEw&list=PLaa8QYrMzXNnzY-4YVM5507iZuESWVcnU&index=5)

[SPARQL Tutorial 6 - IRI abbreviations](https://www.youtube.com/watch?v=QPDRPmZ9f0w&list=PLaa8QYrMzXNnzY-4YVM5507iZuESWVcnU&index=6)

[SPARQL Tutorial 7 - Group Pattern abbreviations](https://www.youtube.com/watch?v=Xi0rE1xczb8&list=PLaa8QYrMzXNnzY-4YVM5507iZuESWVcnU&index=7)

[SPARQL Tutorial 8 - Literal abbreviations](https://www.youtube.com/watch?v=M9MxKjz0KE0&list=PLaa8QYrMzXNnzY-4YVM5507iZuESWVcnU&index=8)

[SPARQL Tutorial 9 - HTML literals](https://www.youtube.com/watch?v=jbotjsjWo0Q&list=PLaa8QYrMzXNnzY-4YVM5507iZuESWVcnU&index=10)


## [Het wordt beschouwd als een microframework omdat het alleen de essentiële zaken voor webontwikkeling biedt, waarbij de nadruk ligt op eenvoud en uitbreidbaarheid](https://web.engr.oregonstate.edu/~budd/Books/oopintro3e/info/slides/chap03/slide28.htm)

## Build and Push to Docker Hub from Openshift 4
```
$ oc new-build --strategy docker --binary --name=containerized-hello-world-python 

$ oc start-build containerized-hello-world-python  --from-dir=. --follow --wait
```

## Deploy to OpenShift 4
```
$ oc new-app containerized-hello-world-python  --name=containerized-hello-world-python 
```

## Expose a Secure URL for this Flask app
```
$ oc create route edge --service=containerized-hello-world-python 
```
##     - python3 transformation/main.py ${CHANGED_FILES}

## route 
```
kind: Route
apiVersion: route.openshift.io/v1
metadata:
  name: mbk-frontend
  namespace: mbk-mbk-productie
spec:
  host: modellenbibliotheek.belastingdienst.nl
  to:
    kind: Service
    name: mbk-frontend
    weight: 100
  port:
    targetPort: 5000-tcp
  tls:
    termination: edge
    insecureEdgeTerminationPolicy: Redirect
  wildcardPolicy: None
```

## service 
```
kind: Service
apiVersion: v1
metadata:
  name: mbk-frontend
  namespace : mbk-mbk-productie
spec:
  ports:
    - name: 5000-tcp
      protocol: TCP
      port: 5000
      targetPort: 5000
    - name: 8080-tcp
      protocol: TCP
      port: 8080
      targetPort: 8080
  internalTrafficPolicy: Cluster
  type: ClusterIP
  ipFamilyPolicy: SingleStack
  sessionAffinity: None
  selector:
    app.openshift.io/runtime: python
    deployment: mbk-frontend
```


## deployment
```
# test 16:50
kind: Deployment
apiVersion: apps/v1
metadata:
  name: mbk-frontend
  namespace: mbk-mbk-productie
  labels:
    app: mbk-frontend
    app.kubernetes.io/component: mbk-frontend
    app.kubernetes.io/instance: mbk-mbk-productie
    app.kubernetes.io/part-of: mbk-modellenbibliotheek
    app.openshift.io/runtime: python
spec:
  replicas: 2
  selector:
    matchLabels:
      app.openshift.io/runtime: python
      deployment: mbk-frontend
  template:
    metadata:
      creationTimestamp: null
      labels:
        app.openshift.io/runtime: python
        deployment: mbk-frontend
      annotations:
        openshift.io/generated-by: OpenShiftNewApp
    spec:
      volumes:
        - name: mbk-frontend-endpoint-js-productie
          configMap:
            name: mbk-frontend-endpoint-js-productie
        - name: mbk-frontend-config-py-productie
          configMap:
            name: mbk-frontend-config-py-productie
      containers:
        - name: mbk-frontend
          image: >-
             cir-cn.chp.belastingdienst.nl/mbk/mbk-frontend:latest
          ports:
            - containerPort: 5000
              protocol: TCP
            - containerPort: 8080
              protocol: TCP
          resources: {}
          terminationMessagePath: /dev/termination-log
          terminationMessagePolicy: File
          imagePullPolicy: IfNotPresent
          volumeMounts:
            - name: mbk-frontend-endpoint-js-productie
              mountPath: /deployment/frontend/static/ep/endpoint.js
              subPath: endpoint.js
            - name: mbk-frontend-config-py-productie
              mountPath: /deployment/frontend/ep/config.py
              subPath: config.py
      restartPolicy: Always
      terminationGracePeriodSeconds: 30
      dnsPolicy: ClusterFirst
      securityContext: {}
      schedulerName: default-scheduler
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxUnavailable: 25%
      maxSurge: 25%
  revisionHistoryLimit: 10
  progressDeadlineSeconds: 600

```

#configmap 1
```
kind: ConfigMap
#oc create configmap mbk-frontend-endpoint-js-tst   --from-file=endpoint.js
# # #oc set volume deployment mbk-frontend --add --type configmap --configmap-name mbk-frontend-endpoint-js-tst --mount-path=/deployment/frontend/static/ep/
apiVersion: v1
metadata:
  name: mbk-frontend-config-py-test
  namespace: mbk-mbk-test
data:
  config.py: >-
    ##################### CONTAINER PLATFORM ENDPOINTS #####################
    
    DATASTORE_LOOKUP_ENDPOINT = "http://mbk-fuseki:3030/modellenbibliotheek/sparql"
    
    DATASTORE_ENDPOINT = "http://mbk-fuseki:3030/modellenbibliotheek"

    DB_CONFIG = {
        "dbname": "database1",
        "user": "user1",
        "password": "password1",
        "host": "mbk-postgres",
        "port": "5432"
    }

    ##################### SINGLE SIGN ON #####################
    
    PRODUCTION_BASE_URL = "https://fibi1.belastingdienst.nl"
    
    BASE_URL = "https://fibi2.acc.belastingdienst.nl"
    
    REDIRECT_URL = "https://modellenbibliotheek.tst.belastingdienst.nl/authorized"
    
    AUTHORIZATION_URL = BASE_URL + "/as/authorization.oauth2"
    
    TOKEN_URL = BASE_URL + "/as/token.oauth2"
    
    USERINFO_URL = BASE_URL + "/idp/userinfo.openid"
    
    CLIENT_ID = "42ee28a4-26f5-418b-8249-b115dc740622"
    
    CLIENT_KEY = "lxdkV2VdVz7H1Tk3RxqPLpN8F4pAyoTWaK3tZTShFnM="
    
    SCOPE = "openid profile"
    
    ##################### FLASK ENDPOINTS #####################
    
    UPLOAD_ROUTE = "/upload"
    
    SSO_ROUTE = "/authorized"
    
    DOWNLOAD_ROUTE = "/download"
    
    QUERYDIENST_ROUTE = "/querydienst"
    
    USERMENU_ROUTE = "/usermenu"
```

#configmap 2 agnostic

```
kind: ConfigMap
#oc create configmap mbk-frontend-endpoint-js-tst   --from-file=endpoint.js
###oc set volume deployment mbk-frontend --add --type configmap --configmap-name mbk-frontend-endpoint-js-tst --mount-path=/deployment/frontend/static/ep/
apiVersion: v1
metadata:
  name: mbk-frontend-endpoint-js-test
  namespace: mbk-mbk-test
data:
  endpoint.js: >-
    const endpoint =
    "https://mbieb.tst.belastingdienst.nl/modellenbibliotheek/sparql";


    if (typeof rdflib !== 'undefined') {
        rdflib.setEndpoint(endpoint);
    }

    const welkom = '<p>Modellenbibliotheek</p><div class="px-4 py-5 my-5
    text-center"><h1 class="display-8 fw-bold">Modellenbibliotheek</h1><div
    class="col-lg-6 mx-auto"><img src="/static/mb-lets-run.png"
    width="400px"/><p class="lead mb-4">Vanaf deze pagina heeft u toegang tot de
    <br/><b>TEST</b> omgeving TestScottvoorSebas POD van de Modellenbibliotheek</p></div></div>';

    const breadcrumb_title = 'MBieb-tst';

    const py_prefix = '/static/';
```

## Principes van Parnas

Deze ideeën werden door computerwetenschapper David Parnas vastgelegd in een paar regels, die bekend staan als de principes van Parnas:

De ontwikkelaar van een softwarecomponent moet de beoogde gebruiker voorzien van alle informatie die nodig is 
om effectief gebruik te kunnen maken van de diensten die door de component worden geleverd, en mag geen andere informatie verstrekken.
De implementeerder van een softwarecomponent moet worden voorzien van alle informatie die nodig is om de gegeven verantwoordelijkheden uit te voeren die aan de component zijn toegewezen, en mag geen andere informatie krijgen.
