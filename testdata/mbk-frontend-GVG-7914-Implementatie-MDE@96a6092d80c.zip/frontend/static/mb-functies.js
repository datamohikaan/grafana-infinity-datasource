var toetsing_param;
var title;
const queryParameters = Object;
queryParameters.page = "";
var query_json_object;

$(document).ready(function () {
  $(function () {
    let url = new URL(window.location.href);
    window.history.replaceState(null, "", url.origin);

    let usermenu_object = JSON.parse(usermenu.replaceAll("&#34;", '"'));
    let parameters_string = parameters.replaceAll("&amp;", "&");
    let regel =
      '<a class="nav-link dropdown-toggle" id="dropdown01" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">' +
      usernaam +
      " (" +
      usergroepnaam +
      ")" +
      "</a>";
    $(regel).appendTo("#mb-usermenu");
    let items = [];
    $.each(usermenu_object, function (key, val) {
      $(regel).appendTo("mb-usermenuitem");
      items.push(
        '<a class="dropdown-item" rel="menu-link" nav-url="' +
          key +
          '">' +
          val +
          "</a>"
      );
    });
    $("<div/>", {
      class: "dropdown-menu",
      html: items.join(""),
    }).appendTo("#mb-usermenu");
    $("#mb-usermenu").addClass("mb-xxuserid");

    $.ajax({
      url: py_prefix + "mb-json-query.json",
      dataType: "json",
      async: false,
      success: function (data) {
        query_json_object = data;
      },
    });

    $("[rel=mb-bld-logo]").click(function (e) {
      e.preventDefault();
      if ($("#mb-bld-logo").css("display") == "none") {
        $("#mb-bld-logo").show();
      } else {
        $("#mb-bld-logo").hide();
      }
      return false;
    });

    $("a[rel=menu-link]").click(function (e) {
      e.preventDefault();
      $("#melding").html("");
      $(".dropdown-menu").removeClass("show");
      let pageValue = $(this).attr("nav-url");
      queryParameters.page = pageValue;
      page_open(queryParameters);
      return false;
    });

    rdflib.enableLinkCallback(true);
    $("#main-block-inhoud").html(welkom);

    //RJ console.log("Url parameters = " + parameters_string);
    let queryString = new URLSearchParams(parameters_string);
    //RJ console.log("Url queryString = " + queryString);
    queryParameters.page = queryString.get("page");
    if (queryParameters.page != null) {
      queryParameters.graph = queryString.get("graph");
      queryParameters.uri = queryString.get("uri");
      queryParameters.term = queryString.get("term");
      queryParameters.kg = queryString.get("kg");
      queryParameters.vnr = queryString.get("vnr");
      queryParameters.vdate = queryString.get("vdate");
      queryParameters.rdate = queryString.get("rdate");

      /*********************************************
       * Onderstaand is voor test
       ******************************************* */
      let inhoud = "";
      for (const key in queryParameters) {
        const value = queryParameters[key];
        if (value != null) {
          inhoud += " " + key + "=" + value + "\n";
        }
      }
      //RJ console.log(inhoud);
      page_open(queryParameters);
    }

    $("[rel=home-link]").click(function () {
      let url = new URL(window.location.href);
      window.location.href = url.origin;
      return false;
    });

    $("[rel=zoeken]").click(function () {
      $("#melding").html("");
      queryParameters.term = $("[name=term]").val().trim();
      search(queryParameters);
      return false;
    });

    $("#search-input").keypress(function (e) {
      var key = e.which;
      if (key == 13) {
        // the enter key code
        $("[rel=zoeken]").click();
        return false;
      }
    });

    $("#melding").click(function (e) {
      e.preventDefault();
      alert(title);
      return false;
    });
  });

  (function () {
    "use strict";
    window.addEventListener(
      "load",
      function () {
        // Fetch all the forms we want to apply custom Bootstrap validation styles to
        var forms = document.getElementsByClassName("needs-validation");
        // Loop over them and prevent submission
        var validation = Array.prototype.filter.call(forms, function (form) {
          form.addEventListener(
            "submit",
            function (event) {
              if (form.checkValidity() === false) {
                event.preventDefault();
                event.stopPropagation();
              }
              form.classList.add("was-validated");
            },
            false
          );
        });
      },
      false
    );
  })();
});

/*********************************************
* Onderstaand is voor https://jira.belastingdienst.nl/secure/attachment/921108/aanpassingen.txt
* GVG-6054-Overzicht-kennisbronnen_detailpagina
* https://jira.belastingdienst.nl/browse/GVG-6054
******************************************* */

function kennisbronnen(queryParameters) {
  let query_table1 = lees_query("kennisbronnen_table1");
  maak_history(queryParameters);

  setBreadcrumb(" / Kennisbronnen");
  $("#main-block-inhoud").html('<table class="table" id="table1"></table>');
  $("#main-block-kop").html("");
  rdflib.fetchData(document.getElementById("table1"), query_table1);

  bind_link(queryParameters);
  return false;
}

function domeinen(queryParameters) {
  let query_table1 = lees_query("domeinen_table1");
  maak_history(queryParameters);

  setBreadcrumb(" / Domeinen");
  $("#main-block-inhoud").html('<table class="table" id="table1"></table>');
  $("#main-block-kop").html("");
  rdflib.fetchData(document.getElementById("table1"), query_table1);

  bind_link(queryParameters);
  return false;
}

function nav_domein(queryParameters) {
  let graphuri = queryParameters.graph;
  let subjecturi = queryParameters.uri;
  let query_table1 = lees_query("nav_domein_table1");
  let query_table2 = lees_query("nav_domein_table2");
  maak_history(queryParameters);

  setBreadcrumb(
    ' / <a rel="breadcrumb-link" menu-url="domeinen.html">Domeinen</a> / Domein'
  );
  $("#main-block-inhoud").html(
    '<table class="table" id="table1"></table><h3>Kennisgebieden</h3>\
    <table class="table kennisgebied" id="table2"></table>'
  );
  $("#main-block-kop").html("");

  rdflib.fetchTriples(document.getElementById("table1"), query_table1, {
    uri: subjecturi,
  });
  rdflib.fetchData(document.getElementById("table2"), query_table2, {
    uri: subjecturi,
  });
  bind_link(queryParameters);

  return false;
}
// end  GVG-6054-Overzicht-kennisbronnen_detailpagina


function lees_query(query_lees_key) {
  //RJ console.log(query_lees_key);
  if (query_json_object.hasOwnProperty(query_lees_key)) {
    return query_json_object[query_lees_key].join(" ");
  } else {
    let melding = query_lees_key + " komt niet voor in de query_json_object.";
    $("#melding").html(melding);
  }
}

function maak_options(optionName) {
  let uitvoer = "";
  $.ajax({
    url: py_prefix + "mb-json-options.json",
    dataType: "json",
    async: false,
    success: function (data) {
      $.each(data, function (groep, options) {
        if (groep == optionName) {
          $.each(options.options, function (key, val) {
            uitvoer += '<option value="' + key + '">' + val + "</option>";
          });
        }
      });
    },
  });
  return uitvoer;
}

function link_callback() {
  let pageValue = event.currentTarget.dataset.link;
  let graphuri = event.currentTarget.dataset.graphuri;
  let subjecturi = event.currentTarget.dataset.subjecturi;

  queryParameters.page = pageValue;
  queryParameters.graph = graphuri;
  queryParameters.uri = subjecturi;

  page_open(queryParameters);
  return false;
}

function page_open(queryParameters) {
  let pageValue = queryParameters.page;

  $("#melding").html("");
  if (typeof window[pageValue] === "function") {
    window[pageValue](queryParameters);
  } else {
    let melding =
      pageValue +
      " is in deze versie van de modellenbibliotheek nog niet geïmplementeerd.";
    $("#main-block-inhoud").html("");
    $("#main-block-kop").html("");
    title =
      "page: " +
      queryParameters.pageValue +
      "\r\ngraphuri: " +
      queryParameters.graph +
      "\r\nsubjecturi: " +
      queryParameters.uri;
    //RJ console.log("Melding: " + melding);
    $("#melding").html(melding);
    $("#melding").prop("title", title);
  }
  return false;
}

function maak_history(queryParameters) {
  //RJ console.log(queryParameters);
  let pageValue = queryParameters.page;
  let graphuri = queryParameters.graph;
  let subjecturi = queryParameters.uri;

  let inhoud = "";
  let voorloop = "?";
  for (let key in queryParameters) {
    let value = queryParameters[key];
    if (value != null) {
      if (key == 'uri') {
        value = encodeURIComponent(value);
      }
      inhoud += voorloop + key + "=" + value;
      voorloop = "&";
    }
  }
  if (inhoud != "") {
    let url = new URL(window.location.href);
    window.history.pushState(null, "", url.origin + inhoud);
    $("#mb-bld-logo").append(inhoud + " <br/>");
  }
}

function bind_link(queryParameters) {
  // Voeg een download icon toe aan de links naar modellen:
  // nav_inModelversie

  for (const key in queryParameters) delete queryParameters[key];

  $("[rel=breadcrumb-link]").click(function (e) {
    e.preventDefault();
    $("#melding").html("");
    let url = $(this).attr("menu-url");
    queryParameters.page = url.split(".")[0];
    page_open(queryParameters);
    return false;
  });
}

function zet_download_links(queryParameters) {
  //RJ console.log(queryParameters);
  let pageValue = queryParameters.page;
  $("[data-link=nav_SBM]").each(function () {
    //RJ console.log("test");
    //RJ alert("test");
  });
}

function toetsing_return() {
  page_open(toetsing_param);
  return false;
}

function setBreadcrumb(breadcrumbs) {
  $("#breadcrumb").html(
    '<a rel="home-link" href="">' + breadcrumb_title + "</a>" + breadcrumbs
  );
}

/*********************************************
* Onderstaand is voor https://jira.belastingdienst.nl/secure/attachment/921108/aanpassingen.txt
* GVG-6054-Overzicht-kennisbronnen_detailpagina
* https://jira.belastingdienst.nl/browse/GVG-6054
******************************************* */

function registerwijzigingen(queryParameters) {
  let query_table1 = lees_query("registerwijzigingen_table1");
  maak_history(queryParameters);

  setBreadcrumb(
    ' / Registerwijzigingen'
  );
  $("#main-block-inhoud").html('<table class="table" id="table1"></table>');
  $("#main-block-kop").html("");
  rdflib.fetchData(document.getElementById("table1"), query_table1, {});

  // maak_history(queryParameters);
  bind_link(queryParameters);
  return false;
}


function dashboard(queryParameters) {
  let query_table1 = lees_query("dashboard_table1");
  let query_table2 = lees_query("dashboard_table2");
  maak_history(queryParameters);
 
  setBreadcrumb(" / Dashboard");
  $("#main-block-inhoud").html('<table class="table" id="table1"></table><table class="table" id="table2"></table>');
  $("#main-block-kop").html(
    '<p>Onderstaand dashboard geeft inzicht in stand van de modelleeropgave.</p>\
  <ul><li>Ingericht betekent dat zowel de datasteward, kennishouder als beherende afdeling geregistreerd is in het kennisgebiedenregister</li>\
  <li>Aangeboden betekent dat de modellen zijn aangeboden ter toetsing en publicatie bij de Modelautoriteit</li>\
  <li>Beschikbaar betekent dat de modellen zijn gepubliceerd in de Modellenbibliotheek</li>\
  <li>Herbruikbaar betekent dat de modellen zijn gepubliceerd in de Modellenbibliotheek met kwaliteitslabel A of B</li></ul>\
  <p>Er is ook een <a rel="breadcrumb-link" menu-url="dashboard2.html">dashboard per kennisgebied</a> beschikbaar.</p>'
  );
  rdflib.fetchData(document.getElementById("table1"), query_table1, {});
  rdflib.fetchData(document.getElementById("table2"), query_table2, {});
 
  bind_link(queryParameters);
  return false;
}
 
function nav_dashboard_kg_info(queryParameters) {
  let subjecturi = queryParameters.uri;
  let query_table1 = lees_query("dashboard_kg_info_table1");
  maak_history(queryParameters);
 
  setBreadcrumb(
    ' / <a rel="breadcrumb-link" menu-url="dashboard.html">Dashboard</a> / Dashboard modellen per kennisgebied'
  );
  $("#main-block-inhoud").html('<table class="table" id="table1"></table>');
  $("#main-block-kop").html("");
  rdflib.fetchData(document.getElementById("table1"), query_table1, {uri: subjecturi});
 
  bind_link(queryParameters);
  return false;
}
 
function nav_dashboard_dom_info(queryParameters) {
  let subjecturi = queryParameters.uri;
  let query_table1 = lees_query("dashboard_dom_info_table1");
  maak_history(queryParameters);
 
  setBreadcrumb(
    ' / <a rel="breadcrumb-link" menu-url="dashboard.html">Dashboard</a> / Dashboard modellen per kennisgebied'
  );
  $("#main-block-inhoud").html('<table class="table" id="table1"></table>');
  $("#main-block-kop").html("");
  rdflib.fetchData(document.getElementById("table1"), query_table1, {uri: subjecturi});
 
  bind_link(queryParameters);
  return false;
}
 
function dashboard2(queryParameters) {
  let query_table1 = lees_query("dashboard2_table1");
  maak_history(queryParameters);
 
  setBreadcrumb(
    ' / <a rel="breadcrumb-link" menu-url="dashboard.html">Dashboard</a> / Dashboard kennisgebieden'
  );
  $("#main-block-inhoud").html('<table class="table" id="table1"></table>');
  $("#main-block-kop").html("");
  rdflib.fetchData(document.getElementById("table1"), query_table1, {});
 
  bind_link(queryParameters);
  return false;
}

function find(queryParameters) {
  let uriParam = queryParameters.uri;
  let termParam = queryParameters.term;
  let kgParam = queryParameters.kg;
  let vnrParam = queryParameters.vnr;

  maak_history(queryParameters);

  setBreadcrumb(" / find");
  $("#main-block-inhoud").html(
    '<div class="px-4 py-5 my-5 text-center">\
     <h1 class="display-5 fw-bold">Oeps!</h1><div class="col-lg-6 mx-auto">\
     <p class="lead mb-4">Het begrip "<span id="term">..</span>" komt niet voor in de kennisbank. </p></div></div>'
  );
  $("#main-block-kop").html("");

  let graphquery = lees_query("find_graphquery");
  if (kgParam) {
    graphquery = graphquery + "?m kgr:kennisgebied ?kg." + lees_query("find_kgquery");
  }
  graphquery = graphquery + "}}";

  rdflib.fetchValue(
    uriParam,
    graphquery,
    { term: termParam, code: kgParam },
    (uri) => {
      queryParameters.uri = uri;
      queryParameters.page = "nav_begrip";
      page_open(queryParameters);
    }
  );

  document.getElementById("term").innerHTML = termParam;

  bind_link(queryParameters);
  return false;
}

function kennisbanken(queryParameters) {
  let query_table1 = lees_query("kennisbanken_table1");
  maak_history(queryParameters);

  setBreadcrumb(" / Kennisbanken");
  $("#main-block-inhoud").html('<table class="table" id="table1"></table>');
  $("#main-block-kop").html("");
  rdflib.fetchData(document.getElementById("table1"), query_table1);

  bind_link(queryParameters);
  return false;
}

function kennisgebiedenregister(queryParameters) {
  const queryData = {
    query_id: "kennisgebiedenregister_table1",
    query_parameters: [],
    //query_id: "nav_toetsingskader_table1",
    //query_parameters: {"URI":"1234", "GRAPH":"4567"}
  };
  fetch("/querier", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(queryData),
  })
    .then((response) => response.json())
    //RJ .then((data) => console.log(data));

  let query_table1 = lees_query("kennisgebiedenregister_table1");
  maak_history(queryParameters);

  setBreadcrumb(" / kennisgebiedenregister");
  $("#main-block-inhoud").html('<table class="table" id="table1"></table>');
  rdflib.fetchData(document.getElementById("table1"), query_table1), {};

  bind_link(queryParameters);
  return false;
}

function magazijn(queryParameters) {
  let query_table1 = lees_query("magazijn_table1");
  maak_history(queryParameters);

  setBreadcrumb(" / magazijn");
  $("#main-block-inhoud").html('<table class="table" id="table1"></table>');
  $("#main-block-kop").html("");
  rdflib.fetchData(document.getElementById("table1"), query_table1);

  bind_link(queryParameters);
  return false;
}

function toetsingslogboek(queryParameters) {
  let query_table1 = lees_query("toetsingslogboek_table1");
  maak_history(queryParameters);

  setBreadcrumb(" / Toetsingslogboek");
  $("#main-block-inhoud").html('<table class="table" id="table1"></table>');
  $("#main-block-kop").html(
    '<p>Onderstaande tabel geeft alle openstaande verzoeken aan de Modelautoriteit weer. Door op de link te klikken, is meer informatie te vinden via het ticket van de servicedesk.</p>\
  <p>Verzoeken met de status "Ingediend" zijn nog niet opgepakt door de Modelautoriteit. Verzoeken met de status "Onderhanden" zijn daadwerkelijk in behandeling bij de Modelautoriteit. Voor de overige verzoeken geldt dat de Modelautoriteit wacht op een reactie van de indiener.</p>'
  );
  rdflib.fetchData(document.getElementById("table1"), query_table1);

  bind_link(queryParameters);
  return false;
}

function toetsingslogboek_(queryParameters) {
  let query_table1 = lees_query("toetsingslogboek__table1");
  maak_history(queryParameters);

  setBreadcrumb(" / Toetsingslogboek");
  $("#main-block-inhoud").html('<table class="table" id="table1"></table>');
  $("#main-block-kop").html(
    '<p>Alle afgeronde verzoeken kunnen hier gevonden worden: <a rel="breadcrumb-link" menu-url="verzoeken.html">afgeronde verzoeken</a>.</p>\
  <p>Alle modellen in de modellenbibliotheek kunnen hier gevonden worden: <a rel="breadcrumb-link" menu-url="toetsingsmodellen.html">alle modellen</a>.</p>'
  );
  rdflib.fetchData(document.getElementById("table1"), query_table1);

  bind_link(queryParameters);
  return false;
}

function search(queryParameters) {
  let query_table1 = lees_query("search_table1");

  setBreadcrumb(" / Zoeken");
  $("#main-block-inhoud").html('<table class="table" id="table1"></table>');
  $("#main-block-kop").html(
    "<p>Zoekresultaten voor: <b>" + queryParameters.term + "</b></p>"
  );

  // const term = urlParams.get("term").replace(/[^a-zA-Z0-9\s]/g, "");
  rdflib.fetchData(document.getElementById("table1"), query_table1, {
    term: queryParameters.term,
  });

  bind_link(queryParameters);
  return false;
}

function upload() {
  setBreadcrumb(" / Upload model");
  $("#main-block-kop").html(
    "<p>Hier kun je je model uploaden om aan te bieden voor de Modellenbibliotheek. De met een * aangegeven velden zijn verplicht.</p>"
  );
  $("#main-block-inhoud").html(
    '\
  <form id="upload-model" name="upload-model" method="POST" enctype="multipart/form-data">\
  \
  <div class="form-group">\
    <label for="bd_user">Eigen user Id *</label>\
    <input type="text" name="bd_user" id="bd_user" class="form-control" value="' +
      userid +
      '" required/>\
  </div>\
  <div class="form-group">\
    <label for="domein">Domein actief</label>\
    <div><input type="text" name="domein" id="domein" class="form-control"/></div>\
  </div>\
  <div class="form-group">\
    <label for="titelVerzoek">Titel van het verzoek *</label>\
    <div><input type="text" name="titelVerzoek" id="titelVerzoek" class="form-control" value="Dit is de titel" required/></div>\
  </div>\
    <div class="form-group">\
    <label for="soortVerzoek">Soort verzoek *</label>\
    <select class="form-control" id="soortVerzoek" name="soortVerzoek"required>' +
      maak_options("soortVerzoek") +
      '</select>\
  </div>\
    <div class="form-group">\
    <label for="soortModel">Soort model *</label>\
    <select class="form-control" id="soortModel" name="soortModel" required>' +
      maak_options("soortModel") +
      '</select>\
  </div>\
  </div>\
    <div class="form-group">\
    <label for="modelStatus">Model status *</label>\
    <select class="form-control" id="modelStatus" name="modelStatus" required>' +
      maak_options("modelStatus") +
      '</select>\
  </div>\
    <div class="form-group">\
    <label for="sdJiraItemnummer">Service desk Jira itemnummer *</label>\
    <input type="text" name="sdJiraItemnummer" id="sdJiraItemnummer" class="form-control" value="SD1212123" required/>\
  </div>\
  <div class="form-group">\
    <label for="extraModelleurs">Extra modelleurs</label>\
    <input type="text" name="extraModelleurs" id="extraModelleurs" class="form-control" placeholder="Geef het user_id van de extra modelleur(s) gescheiden door een komma"/>\
  </div>\
  <div class="form-group">\
    <label for="opmerkingen">Opmerkingen</label>\
    <div><input type="text" name="opmerkingen" id="opmerkingen" class="form-control"/></div>\
  </div>\
  <div class="form-group">\
    <label for="fileToUpload">Kies het model voor upload</label>\
    <input type="file" name="fileToUpload" id="fileToUpload" class="form-control" required/>\
  </div>\
  <button id="btn" type="submit" name="upload_data" class="btn btn-primary mt-3">Upload</button>\
  </form>\
  <div id="upload_resultaat"></div>\
  '
  );

  $("form#upload-model").submit(function (e) {
    e.preventDefault();
    //alert('upload-model');
    const btn = document.getElementById('btn');
    btn.style.backgroundColor = 'orange';
    btn.innerHTML = 'uploading and transforming...';

    var formData = new FormData(this);
    var fileInput = $("#fileToUpload")[0];

    formData.append("userid", userid);
    formData.append("fileToUpload", fileInput.files[0]);

    $.ajax({
      url: "/upload",
      type: "POST",
      data: formData,
      cache: false,
      contentType: false,
      processData: false,
      beforeSend: function () {},
      success: function (data) {
        data = data.replace(/\n/g, "<br>").replace(/ /g, "&nbsp;");
        //alert(data);
        btn.style.backgroundColor = 'green';
        btn.innerHTML = 'Done';
        $("#upload_resultaat").html(data).show();
      },
    });
    return false;
  });
  return false;
}

function toevoegen_gebruikers() {
  setBreadcrumb(" / Toevoegen gebruikers");
  $("#main-block-kop").html(
    "<p>Hier kun je een excel toevoegen om gebruikers toe te voegen aan de Modellenbibliotheek.</p>"
  );

  $("#main-block-inhoud").html(
    '\
  <form id="toevoegen-gebruikers" name="toevoegen-gebruikers" method="POST" enctype="multipart/form-data">\
  \
  <label for="fileToUpload">Upload de template met de gebruikers die je wilt toevoegen</label>\
  <input type="file" name="fileToUpload" id="fileToUpload" class="form-control" required/>\
  <button type="submit" name="upload_data" class="btn btn-primary mt-3">Upload</button>\
  </form>\
  <div id="upload_resultaat"></div>\
  '
  );

  $("form#toevoegen-gebruikers").submit(function (e) {
    e.preventDefault();

    var formData = new FormData(this);
    var fileInput = $("#fileToUpload")[0];

    $.ajax({
      url: "/toevoegen_gebruikers",
      type: "POST",
      data: formData,
      cache: false,
      contentType: false,
      processData: false,
      beforeSend: function () {},
      success: function (response) {
        alert(response);
      },
    });
    return false;
  });
  return false;
}

function download() {
  setBreadcrumb(" / Download model");
  $("#main-block-kop").html(
    "<p>Hier kun je geuploade modellen downloaden.</p>"
  );

  $(document).ready(function () {
    $.ajax({
      url: "/download",
      type: "GET",
      success: function (models) {
        displayModels(models);
      },
    });
  });
}

function displayModels(models) {
  var tableHTML =
    "<table><thead><tr><th>Model naam</th><th>Graph URI</th><th>Upload moment</th><th>Model status</th></tr></thead><tbody>";
  models.forEach(function (model) {
    let fileName = model[0] + model[1];
    tableHTML += `<tr><td><a href='/download/${model[5]}/${model[0]}' download>${fileName}</a></td><td>${model[2]}</td><td>${model[3]}</td><td>${model[4]}</td></tr>`;
  });
  tableHTML += "</tbody</table>";
  $("#main-block-inhoud").html(tableHTML);
}

function query_dienst() {
  setBreadcrumb(" / Querydienst");
  $("#main-block-inhoud").html(
    '<form id="query-dienst" name="query-dienst" method="post"><textarea class="form-control" id="sparqlQuery" name="sparqlQuery" rows="10" cols="80">SELECT * \n WHERE \n { \n  GRAPH <urn:name:kennisgebiedenregister> { \n ?subject ?predicate ?object \n } \n } \n</textarea><button type="submit" name="query_dienst" class="btn btn-primary mt-3">Verstuur</button> </form> <div id="query_resultaat"></div>'
  );
  $("#main-block-kop").html(
    "<p>Hier kun je je query ingeven om uit te laten voeren door de Modellenbibliotheek.</p>"
  );

  $("form#query-dienst").submit(function (e) {
    e.preventDefault();
    //alert('query-dienst');

    var formData = new FormData(this);
    formData.append("userid", userid);

    $.ajax({
      url: "/querydienst",
      type: "POST",
      data: formData,
      cache: false,
      contentType: false,
      processData: false,
      beforeSend: function () {},
      success: function (data) {
        $("#query_resultaat").text(data).show();
      },
    });
    return false;
  });
  return false;
}

function fuseki_herstel() {
  setBreadcrumb(" / Fuseki Herstel");
  $("#main-block-kop").html(
    "<p>Hier kun je de Fuseki database herstellen, mits dit nodig is.</p>"
  );
  $("#main-block-inhoud").html('<div id="herstel_resultaat"></div>');
  var wachtwoord = window.prompt("Wachtwoord: ");
  if (wachtwoord === "MbiebFusekiHerstel!") {
    var button = $("<button/>", {
      text: "Fuseki Herstellen",
      click: function () {
        var bevestig = window.confirm(
          "De Fuseki database wordt hersteld, weet u zeker dat u door wilt gaan?"
        );
        if (bevestig) {
          $.ajax({
            url: "/fuseki_restore",
            method: "GET",
            success: function (data) {
              $("#herstel_resultaat")
                .html(data.replace(/\n/g, "<br>").replace(/ /g, "&nbsp;"))
                .show();
            },
          });
        }
      },
    });
    $("#main-block-inhoud").append(button);
  } else {
    $("#herstel_resultaat").html("Geen toegang.").show();
  }
}

function nav_CIM(queryParameters) {
  let graphuri = queryParameters.graph;
  let subjecturi = queryParameters.uri;
  let query_table1 = lees_query("nav_CIM_table1");
  let query_table2 = lees_query("nav_CIM_table2");
  maak_history(queryParameters);

  setBreadcrumb(
    ' / <a rel="breadcrumb-link" menu-url="kennisbanken.html">Kennisbanken</a> / LGD Model'
  );
  $("#main-block-inhoud").html(
    '<div class="row"><div class="col-3 scrollable"><ul class="tree" id="tree1"/></div><div class="col"><table class="table" id="table1"/></div></div>'
  );
  $("#main-block-kop").html("");

  rdflib.fetchTriples(document.getElementById("table1"), query_table1, {
    uri: graphuri,
  });
  const types = [
    "http://modellenbibliotheek.belastingdienst.nl/def/lgd#Entiteittype",
    "http://modellenbibliotheek.belastingdienst.nl/def/lgd#Relatietype",
    "http://modellenbibliotheek.belastingdienst.nl/def/lgd#Attribuutdomein",
  ];
  const propuri =
    "http://modellenbibliotheek.belastingdienst.nl/def/lgd#attribuut";

  rdflib.fetchTree(
    document.getElementById("tree1"),
    document.getElementById("table1"),
    query_table2,
    { graph: graphuri, types: types, lower: propuri }
  );
  zet_download_links(queryParameters);

  bind_link(queryParameters);
  return false;
}

function nav_SBM(queryParameters) {
  let graphuri = queryParameters.graph;
  let subjecturi = queryParameters.uri;
  let query_table1 = lees_query("nav_SBM_table1");
  let query_table2 = lees_query("nav_SBM_table2");
  maak_history(queryParameters);

  setBreadcrumb(
    ' / <a rel="breadcrumb-link" menu-url="kennisbanken.html">Kennisbanken</a> / Semantisch Model'
  );
  $("#main-block-inhoud").html(
    '<div class="row"><div class="col-3 scrollable"><ul class="tree" id="tree1"/></div><div class="col"><table class="table" id="table1"/></div></div>'
  );
  $("#main-block-kop").html("");

  rdflib.fetchTriples(document.getElementById("table1"), query_table1, {
    uri: graphuri,
  });
  const classuri = "http://www.w3.org/2004/02/skos/core#Concept";
  const propuri = "http://www.w3.org/2004/02/skos/core#broader";
  rdflib.fetchTree(
    document.getElementById("tree1"),
    document.getElementById("table1"),
    query_table2,
    { graph: graphuri, class: classuri, upper: propuri }
  );
  zet_download_links(queryParameters);

  bind_link(queryParameters);
  return false;
}

function nav_begrip(queryParameters) {
  query_begrip(queryParameters);
  return false;
}

function nav_broader(queryParameters) {
  query_begrip(queryParameters);
  return false;
}

function nav_related(queryParameters) {
  query_begrip(queryParameters);
  return false;
}

function query_begrip(queryParameters) {
  let graphuri = queryParameters.graph;
  let subjecturi = queryParameters.uri;
  let graphquery = lees_query("query_begrip_graphquery");
  let query_table1 = lees_query("query_begrip_table1");
  maak_history(queryParameters);

  setBreadcrumb(
    ' / <a rel="breadcrumb-link" menu-url="kennisbanken.html">Kennisbanken</a> / Semantisch Model / Begrippen'
  );
  $("#main-block-inhoud").html(
    '<div class="row"><div class="col-3 scrollable"><ul class="tree" id="tree1"></table></div><div class="col"><table class="table" id="table1"></table></div></div>'
  );
  $("#main-block-kop").html("");
  rdflib.fetchValue(graphuri, graphquery, { uri: subjecturi }, (graphuri) => {
    const classuri = "http://www.w3.org/2004/02/skos/core#Concept";
    const propuri = "http://www.w3.org/2004/02/skos/core#broader";
    rdflib.fetchTree(
      document.getElementById("tree1"),
      document.getElementById("table1"),
      query_table1,
      { graph: graphuri, class: classuri, upper: propuri }
    );
    rdflib.fetchTriples(document.getElementById("table1"), query_table1, {
      uri: subjecturi,
      graph: graphuri,
    });
  });

  bind_link(queryParameters);
  return false;
}

function nav_kennisgebied(queryParameters) {
  let graphuri = queryParameters.graph;
  let subjecturi = queryParameters.uri;
  let query_table1 = lees_query("nav_kennisgebied_table1");
  let query_table2 = lees_query("nav_kennisgebied_table2");
  let query_table3 = lees_query("nav_kennisgebied_table3");
  maak_history(queryParameters);

  setBreadcrumb(
    ' / <a rel="breadcrumb-link" menu-url="kennisgebiedenregister.html">Kennisgebiedenregister</a> / Kennisgebied'
  );
  $("#main-block-inhoud").html(
    '<table class="table" id="table1"></table><h3>Kennisdeelgebieden</h3>\
    <table class="table kennisdeelgebied" id="table2"></table><h3>Kennisbronnen (wet- en regelgeving)</h3>\
    <table class="table kennisbron" id="table3"></table>'
  );
  $("#main-block-kop").html("");

  rdflib.fetchTriples(document.getElementById("table1"), query_table1, {
    uri: subjecturi,
  });
  rdflib.fetchData(document.getElementById("table2"), query_table2, {
    uri: subjecturi,
  });
  rdflib.fetchData(document.getElementById("table3"), query_table3, {
    uri: subjecturi,
  });
  bind_link(queryParameters);

  return false;
}

function nav_toetsing_BegrippenMetOnbekendeKennisbron(queryParameters) {
  let graphuri = queryParameters.graph;
  let subjecturi = queryParameters.uri;
  let query_table1 = lees_query(
    "nav_toetsing_BegrippenMetOnbekendeKennisbron_table1"
  );
  let query_table2 = lees_query(
    "nav_toetsing_BegrippenMetOnbekendeKennisbron_table2"
  );
  maak_history(queryParameters);

  setBreadcrumb(
    ' / <a rel="breadcrumb-link" menu-url="toetsingslogboek_.html">Toetsingslogboek</a> / <a onclick="toetsing_return()">Toetsing</a> / Begrippen met onbekende kennisbron'
  );
  $("#main-block-inhoud").html(
    '<table class="table" id="table1"></table><table class="table" id="table2"></table>'
  );
  $("#main-block-kop").html(
    "<p>Onderstaande begrippen hebben wel een verwijzing naar een kennisbron, maar die verwijzing kan niet verbonden worden met in het model gespecificeerde kennisbron</p>"
  );
  rdflib.fetchTriples(document.getElementById("table1"), query_table1, {
    uri: subjecturi,
  });
  rdflib.fetchData(document.getElementById("table2"), query_table2, {
    graph: subjecturi,
  });

  bind_link(queryParameters);
  return false;
}

function nav_toetsing_BegrippenMetVerwijsfouten(queryParameters) {
  let graphuri = queryParameters.graph;
  let subjecturi = queryParameters.uri;
  let query_table1 = lees_query(
    "nav_toetsing_BegrippenMetVerwijsfouten_table1"
  );
  let query_table2 = lees_query(
    "nav_toetsing_BegrippenMetVerwijsfouten_table2"
  );
  maak_history(queryParameters);

  setBreadcrumb(
    ' / <a rel="breadcrumb-link" menu-url="toetsingslogboek_.html">Toetsingslogboek</a> / <a onclick="toetsing_return()">Toetsing</a> / Begrippen met verwijsfouten'
  );
  $("#main-block-inhoud").html(
    '<table class="table" id="table1"></table><table class="table" id="table2"></table>'
  );
  $("#main-block-kop").html("");
  rdflib.fetchTriples(document.getElementById("table1"), query_table1, {
    uri: subjecturi,
  });
  rdflib.fetchData(document.getElementById("table2"), query_table2, {
    graph: subjecturi,
  });

  bind_link(queryParameters);
  return false;
}

function nav_toetsing_BegrippenZonderKennisbron(queryParameters) {
  let graphuri = queryParameters.graph;
  let subjecturi = queryParameters.uri;
  let query_table1 = lees_query(
    "nav_toetsing_BegrippenZonderKennisbron_table1"
  );
  let query_table2 = lees_query(
    "nav_toetsing_BegrippenZonderKennisbron_table2"
  );
  maak_history(queryParameters);

  setBreadcrumb(
    ' / <a rel="breadcrumb-link" menu-url="toetsingslogboek_.html">Toetsingslogboek</a> / <a onclick="toetsing_return()">Toetsing</a> / Begrippen zonder kennisbron'
  );
  $("#main-block-inhoud").html(
    '<table class="table" id="table1"></table><table class="table" id="table2"></table>'
  );
  $("#main-block-kop").html("");

  rdflib.fetchTriples(document.getElementById("table1"), query_table1, {
    uri: subjecturi,
  });
  rdflib.fetchData(document.getElementById("table2"), query_table2, {
    graph: subjecturi,
  });

  bind_link(queryParameters);
  return false;
}

function nav_toetsing_BegrippenZonderLineage(queryParameters) {
  let graphuri = queryParameters.graph;
  let subjecturi = queryParameters.uri;
  let query_table1 = lees_query("nav_toetsing_BegrippenZonderLineage_table1");
  let query_table2 = lees_query("nav_toetsing_BegrippenZonderLineage_table2");
  maak_history(queryParameters);

  setBreadcrumb(
    ' / <a rel="breadcrumb-link" menu-url="toetsingslogboek_.html">Toetsingslogboek</a> / <a onclick="toetsing_return()">Toetsing</a> / Begrippen zonder horizontale lineage'
  );
  $("#main-block-inhoud").html(
    '<table class="table" id="table1"></table><table class="table" id="table2"></table>'
  );
  $("#main-block-kop").html(
    "<p>Onderstaande begrippen hebben geen relaties naar andere begrippen. Vaak komt dat omdat in de definitie niet met blokhaaken [..] naar een begrip wordt verwezen. Ook kan het voorkomen dat er wel blokhaken zijn gebruikt, maar het betreffende begrip kan niet gevonden worden, waardoor er geen relatie is gelegd.</p>"
  );

  rdflib.fetchTriples(document.getElementById("table1"), query_table1, {
    uri: subjecturi,
  });
  rdflib.fetchData(document.getElementById("table2"), query_table2, {
    graph: subjecturi,
  });

  bind_link(queryParameters);
  return false;
}

function nav_toetsing_Kennisbrongebruik(queryParameters) {
  let graphuri = queryParameters.graph;
  let subjecturi = queryParameters.uri;
  let query_table1 = lees_query("nav_toetsing_Kennisbrongebruik_table1");
  let query_table2 = lees_query("nav_toetsing_Kennisbrongebruik_table2");
  maak_history(queryParameters);

  setBreadcrumb(
    ' / <a rel="breadcrumb-link" menu-url="toetsingslogboek_.html">Toetsingslogboek</a> / <a onclick="toetsing_return()">Toetsing</a> / Kennisbrongebruik'
  );
  $("#main-block-inhoud").html(
    '<table class="table" id="table1"></table><table class="table" id="table2"></table>'
  );
  $("#main-block-kop").html(
    '<p>Onderstaande lijst geeft het overzicht van aantal verwijzingen naar een in dit model gespecificeerde kennisbron. Bij nul begrippen is sprake van een kennisbron die onnodig opgenomen is in dit model, of de verwijzingen naar deze kennisbron kloppen niet. Verwijzingen werken alleen als deze verwijzingen eindigen op de waarde in de kolom "link". Deze kolom mag niet leeg zijn.</p>'
  );
  rdflib.fetchTriples(document.getElementById("table1"), query_table1, {
    uri: subjecturi,
  });
  rdflib.fetchData(document.getElementById("table2"), query_table2, {
    graph: subjecturi,
  });

  bind_link(queryParameters);
  return false;
}

function nav_toetsing_CIMElementenIncorrecteLineage(queryParameters) {
  let graphuri = queryParameters.graph;
  let subjecturi = queryParameters.uri;
  let query_table1 = lees_query(
    "nav_toetsing_CIMElementenIncorrecteLineage_table1"
  );
  let query_table2 = lees_query(
    "nav_toetsing_CIMElementenIncorrecteLineage_table2"
  );
  maak_history(queryParameters);

  setBreadcrumb(
    ' / <a rel="breadcrumb-link" menu-url="toetsingslogboek_.html">Toetsingslogboek</a> / <a onclick="toetsing_return()">Toetsing</a> / LGD Elementen met incorrecte lineage'
  );
  $("#main-block-inhoud").html(
    '<table class="table" id="table1"></table><table class="table" id="table2"></table>'
  );
  $("#main-block-kop").html(
    "<p>Onderstaande LGD modelelementen hebben verwijzen niet naar een begrip in hetzelfde kennis(deel)gebied. Hierboven is aangegeven welke versie van het semantisch model daarbij wordt gebruikt. Als dit niet wordt getoond, of alleen een URI (en geen naam), dan kan het betreffende semantische model niet gevonden worden (en zullen alle modelelementen geen correcte lineage hebben).</p>"
  );

  rdflib.fetchTriples(document.getElementById("table1"), query_table1, {
    uri: subjecturi,
  });
  rdflib.fetchData(document.getElementById("table2"), query_table2, {
    graph: subjecturi,
  });

  bind_link(queryParameters);
  return false;
}

function nav_toetsing_CIMElementenZonderLineage(queryParameters) {
  let graphuri = queryParameters.graph;
  let subjecturi = queryParameters.uri;
  let query_table1 = lees_query(
    "nav_toetsing_CIMElementenZonderLineage_table1"
  );
  let query_table2 = lees_query(
    "nav_toetsing_CIMElementenZonderLineage_table2"
  );
  maak_history(queryParameters);

  setBreadcrumb(
    ' / <a rel="breadcrumb-link" menu-url="toetsingslogboek_.html">Toetsingslogboek</a> / <a onclick="toetsing_return()">Toetsing</a> / LGD Elementen zonder lineage'
  );
  $("#main-block-inhoud").html(
    '<table class="table" id="table1"></table><table class="table" id="table2"></table>'
  );
  $("#main-block-kop").html(
    "<p>Onderstaande LGD modelelementen verwijzen niet naar een begrip in hetzelfde kennis(deel)gebied.</p>"
  );

  rdflib.fetchTriples(document.getElementById("table1"), query_table1, {
    uri: subjecturi,
  });
  rdflib.fetchData(document.getElementById("table2"), query_table2, {
    graph: subjecturi,
  });

  bind_link(queryParameters);
  return false;
}

function nav_toetsing_LosseEntiteittypen(queryParameters) {
  let graphuri = queryParameters.graph;
  let subjecturi = queryParameters.uri;
  let query_table1 = lees_query("nav_toetsing_LosseEntiteittypen_table1");
  let query_table2 = lees_query("nav_toetsing_LosseEntiteittypen_table2");
  maak_history(queryParameters);

  setBreadcrumb(
    ' / <a rel="breadcrumb-link" menu-url="toetsingslogboek_.html">Toetsingslogboek</a> / <a onclick="toetsing_return()">Toetsing</a> / Losse entiteittypen'
  );
  $("#main-block-inhoud").html(
    '<table class="table" id="table1"></table><table class="table" id="table2"></table>'
  );
  $("#main-block-kop").html(
    "<p>Onderstaande entiteittypen hebben geen enkele relatie met een ander element in het LGD. Hoewel dit niet in alle gevallen foutief is, kan het wel een indicatie zijn op een overbodig uitgewerkt stukje model of een entiteittype dat per ongeluk nog is achtergebleven in het opgeleverde model.</p>"
  );

  rdflib.fetchTriples(document.getElementById("table1"), query_table1, {
    uri: subjecturi,
  });
  rdflib.fetchData(document.getElementById("table2"), query_table2, {
    graph: subjecturi,
  });

  bind_link(queryParameters);
  return false;
}

function nav_toetsing_OntbrekendeAttribuutdomeinen(queryParameters) {
  let graphuri = queryParameters.graph;
  let subjecturi = queryParameters.uri;
  let query_table1 = lees_query(
    "nav_toetsing_OntbrekendeAttribuutdomeinen_table1"
  );
  let query_table2 = lees_query(
    "nav_toetsing_OntbrekendeAttribuutdomeinen_table2"
  );
  maak_history(queryParameters);

  setBreadcrumb(
    ' / <a rel="breadcrumb-link" menu-url="toetsingslogboek_.html">Toetsingslogboek</a> / <a onclick="toetsing_return()">Toetsing</a> / Ontbrekende attribuutdomeinen'
  );
  $("#main-block-inhoud").html(
    '<table class="table" id="table1"></table><table class="table" id="table2"></table>'
  );
  $("#main-block-kop").html(
    "<p>Bij onderstaande attribuuttypen is geen attribuutdomein gespecificeerd, of wordt verwezen naar een onbekend attribuutdomein.</p>"
  );
  rdflib.fetchTriples(document.getElementById("table1"), query_table1, {
    uri: subjecturi,
  });
  rdflib.fetchData(document.getElementById("table2"), query_table2, {
    graph: subjecturi,
  });

  bind_link(queryParameters);
  return false;
}

function nav_toetsing_OverbodigeAttribuutdomeinen(queryParameters) {
  let graphuri = queryParameters.graph;
  let subjecturi = queryParameters.uri;
  let query_table1 = lees_query(
    "nav_toetsing_OverbodigeAttribuutdomeinen_table1"
  );
  let query_table2 = lees_query(
    "nav_toetsing_OverbodigeAttribuutdomeinen_table2"
  );
  maak_history(queryParameters);

  setBreadcrumb(
    ' / <a rel="breadcrumb-link" menu-url="toetsingslogboek_.html">Toetsingslogboek</a> / <a onclick="toetsing_return()">Toetsing</a> / Overbodige attribuutdomeinen'
  );
  $("#main-block-inhoud").html(
    '<table class="table" id="table1"></table><table class="table" id="table2"></table>'
  );
  $("#main-block-kop").html(
    "<p>Onderstaande attribuutdomeinen worden niet gebruikt in het model, maar zijn wel onderdeel van het model (NB: shortcuts zijn al uit dit overzicht gefiltered)</p>"
  );

  rdflib.fetchTriples(document.getElementById("table1"), query_table1, {
    uri: subjecturi,
  });
  rdflib.fetchData(document.getElementById("table2"), query_table2, {
    graph: subjecturi,
  });

  bind_link(queryParameters);
  return false;
}

function nav_toetsing(queryParameters) {
  let graphuri = queryParameters.graph;
  let subjecturi = queryParameters.uri;
  let query_table1 = lees_query("nav_toetsing_table1");
  let query_table2 = lees_query("nav_toetsing_table2");
  maak_history(queryParameters);

  // Bewaar de huidige parameters voor breadcrumb
  toetsing_param = queryParameters;
  setBreadcrumb(
    ' / <a rel="breadcrumb-link" menu-url="toetsingslogboek_.html">Toetsingslogboek</a> / Toetsing'
  );
  $("#main-block-inhoud").html(
    '<table class="table" id="table1"></table><table class="table" id="table2"></table>'
  );
  $("#main-block-kop").html(
    "<p>Onderstaande tabel geeft een overzicht van de toetsingen die uitgevoerd kunnen worden voor dit model</p>"
  );

  rdflib.fetchTriples(document.getElementById("table1"), query_table1, {
    uri: graphuri,
  });
  rdflib.fetchData(document.getElementById("table2"), query_table2, {
    graph: graphuri,
  });

  bind_link(queryParameters);
  return false;
}

function nav_triples(queryParameters) {
  let graphuri = queryParameters.graph;
  let subjecturi = queryParameters.uri;
  maak_history(queryParameters);

  setBreadcrumb("");
  $("#main-block-inhoud").html('<table class="table" id="table1"></table>');
  $("#main-block-kop").html("");

  const graphparam = graphuri;
  const querypre = "?query=construct%7B%3Fs%3Fp%3Fo%7Dwhere%7Bgraph%3C";
  const querypost = "%3E%7B%3Fs%3Fp%3Fo%7D%7D";
  window.location.replace(endpoint + querypre + graphparam + querypost);

  bind_link(queryParameters);
  return false;
}

/*********************************************
* Onderstaand is voor https://jira.belastingdienst.nl/secure/attachment/921108/aanpassingen.txt
* GVG-6054-Overzicht-kennisbronnen_detailpagina
* https://jira.belastingdienst.nl/browse/GVG-6054
******************************************* */

function nav_wijziging(queryParameters) {
  let graphuri = queryParameters.graph;
  let subjecturi = queryParameters.uri;
  let query_table1 = lees_query("nav_wijziging_table1");
  maak_history(queryParameters);

  setBreadcrumb(
    ' / <a rel="breadcrumb-link" menu-url="registerwijzigingen.html">Registerwijzigingen</a> / Wijziging'
  );
  $("#main-block-inhoud").html('<table class="table" id="table1"></table>');
  $("#main-block-kop").html("");

  rdflib.fetchTriples(document.getElementById("table1"), query_table1, {
    uri: subjecturi,
  });

  bind_link(queryParameters);
  return false;
}

function nieuw_type(queryParameters) {
  let graphuri = queryParameters.graph;
  let subjecturi = queryParameters.uri;
  maak_history(queryParameters);

  setBreadcrumb(" / nieuw_type");
  $("#main-block-inhoud").html('<table class="table" id="table1"></table>');
  $("#main-block-kop").html("");

  bind_link(queryParameters);
  return false;
}

function nieuw_afbakeningstype(queryParameters) {
  let graphuri = queryParameters.graph;
  let subjecturi = queryParameters.uri;
  maak_history(queryParameters);

  setBreadcrumb(" / nieuw_afbakeningstype");
  $("#main-block-inhoud").html('<table class="table" id="table1"></table>');
  $("#main-block-kop").html("");

  bind_link(queryParameters);
  return false;
}

function nieuw_domein(queryParameters) {
  let graphuri = queryParameters.graph;
  let subjecturi = queryParameters.uri;
  maak_history(queryParameters);

  setBreadcrumb(" / nieuw_domein");
  $("#main-block-inhoud").html('<table class="table" id="table1"></table>');
  $("#main-block-kop").html("");

  bind_link(queryParameters);
  return false;
}

function nieuw_grondslag(queryParameters) {
  let graphuri = queryParameters.graph;
  let subjecturi = queryParameters.uri;
  maak_history(queryParameters);

  setBreadcrumb(" / nieuw_grondslag");
  $("#main-block-inhoud").html('<table class="table" id="table1"></table>');
  $("#main-block-kop").html("");

  bind_link(queryParameters);
  return false;
}

function nieuw_status(queryParameters) {
  let graphuri = queryParameters.graph;
  let subjecturi = queryParameters.uri;
  maak_history(queryParameters);

  setBreadcrumb(" / nieuw_status");
  $("#main-block-inhoud").html('<table class="table" id="table1"></table>');
  $("#main-block-kop").html("");

  bind_link(queryParameters);
  return false;
}

function nieuw_isDefinedBy(queryParameters) {
  let graphuri = queryParameters.graph;
  let subjecturi = queryParameters.uri;
  maak_history(queryParameters);

  setBreadcrumb(" / nieuw_isDefinedBy");
  $("#main-block-inhoud").html('<table class="table" id="table1"></table>');
  $("#main-block-kop").html("");

  bind_link(queryParameters);
  return false;
}

function nieuw_related(queryParameters) {
  let graphuri = queryParameters.graph;
  let subjecturi = queryParameters.uri;
  maak_history(queryParameters);

  setBreadcrumb(" / nieuw_related");
  $("#main-block-inhoud").html('<table class="table" id="table1"></table>');
  $("#main-block-kop").html("");

  bind_link(queryParameters);
  return false;
}

function nieuw_inModelversie(queryParameters) {
  let graphuri = queryParameters.graph;
  let subjecturi = queryParameters.uri;
  maak_history(queryParameters);

  setBreadcrumb(" / nieuw_inModelversie");
  $("#main-block-inhoud").html('<table class="table" id="table1"></table>');
  $("#main-block-kop").html("");

  bind_link(queryParameters);
  return false;
}

function nieuw_kennisbron(queryParameters) {
  let graphuri = queryParameters.graph;
  let subjecturi = queryParameters.uri;
  maak_history(queryParameters);

  setBreadcrumb(" / nieuw_kennisbron");
  $("#main-block-inhoud").html('<table class="table" id="table1"></table>');
  $("#main-block-kop").html("");

  bind_link(queryParameters);
  return false;
}

function nav_toetsingskader(queryParameters) {
  /* let graphuri = queryParameters.graph; */
  const graphuri = "urn:name:toetsingskader";
  let subjecturi = queryParameters.uri;
  let query_table1 = lees_query("nav_toetsingskader_table1");
  maak_history(queryParameters);

  setBreadcrumb(
    ' / <a rel="breadcrumb-link" menu-url="toetsingslogboek_.html">Toetsingslogboek</a> / Toetsingskader'
  );
  $("#main-block-inhoud").html(
    '<div class="row"><div class="col-3 scrollable"><ul class="tree" id="tree1"></table></div><div class="col"><table class="table" id="table1"></table></div></div>'
  );
  $("#main-block-kop").html("");
  rdflib.fetchTriples(document.getElementById("table1"), query_table1, {
    uri: subjecturi,
    graph: graphuri,
  });
  const classuri = "http://www.w3.org/ns/dqv#Metric";
  const propuri = "http://www.w3.org/ns/dqv#inDimension";
  const types = ["http://www.w3.org/ns/dqv#Dimension"];
  rdflib.fetchTree(
    document.getElementById("tree1"),
    document.getElementById("table1"),
    query_table1,
    { graph: graphuri, upper: propuri, types: types }
  );

  bind_link(queryParameters);
  return false;
}

function nav_toetsingsrapport(queryParameters) {
  let subjecturi = queryParameters.uri;
  let query_kwlabel = lees_query("nav_toetsingsrapport_kwlabel");
  let query_table1 = lees_query("nav_toetsingsrapport_table1");
  let query_table2 = lees_query("nav_toetsingsrapport_table2");
  let query_table3 = lees_query("nav_toetsingsrapport_table3");
  let query_table4 = lees_query("nav_toetsingsrapport_table4");
  maak_history(queryParameters);

  setBreadcrumb(
    ' / <a rel="breadcrumb-link" menu-url="toetsingslogboek_.html">Toetsingslogboek</a> / Toetsingsrapport'
  );
  $("#main-block-inhoud").html(
    '<table class="table" id="table1"></table>\
    <ul class="nav nav-tabs" id="myTab" role="tablist">\
      <li class="nav-item" role="presentation">\
        <button class="nav-link active" id="kwaliteitslabel-tab" data-bs-toggle="tab" data-bs-target="#kwaliteitslabel" type="button" role="tab" aria-controls="kwaliteitslabel" aria-selected="true">Kwaliteitslabel</button>\
      </li>\
      <li class="nav-item" role="presentation">\
        <button class="nav-link" id="dimensies-tab" data-bs-toggle="tab" data-bs-target="#dimensies" type="button" role="tab" aria-controls="dimensies" aria-selected="false">Dimensies</button>\
      </li>\
      <li class="nav-item" role="presentation">\
        <button class="nav-link" id="metingen-tab" data-bs-toggle="tab" data-bs-target="#metingen" type="button" role="tab" aria-controls="metingen" aria-selected="false">Metingen</button>\
      </li>\
      <li class="nav-item" role="presentation">\
        <button class="nav-link" id="advies-tab" data-bs-toggle="tab" data-bs-target="#advies" type="button" role="tab" aria-controls="advies" aria-selected="false">Advies</button>\
      </li>\
    </ul>\
    <div class="tab-content" id="myTabContent">\
      <div class="tab-pane fade show active" id="kwaliteitslabel" role="tabpanel" aria-labelledby="kwaliteitslabel-tab">\
        <p>De Modelautoriteit heeft het volgende kwaliteitslabel toegekend:</p>\
        <p style="font-size:40px;" id="kwlabel">?</p>\
      </div>\
      <div class="tab-pane fade" id="dimensies" role="tabpanel" aria-labelledby="dimensies-tab">\
        <p>Onderstaande tabel geeft het oordeel van de Modelautoriteit per toetsdimensie:</p>\
        <table class="table" id="table4"></table>\
      </div>\
      <div class="tab-pane fade" id="metingen" role="tabpanel" aria-labelledby="metingen-tab">\
        <p>Onderstaande tabel geeft inzicht in de kwaliteit van het model</p>\
        <table class="table" id="table2"></table>\
      </div>\
      <div class="tab-pane fade" id="advies" role="tabpanel" aria-labelledby="advies-tab">\
        <p>Onderstaande tabel geeft een overzicht van de adviezen van de Modelautoriteit</p>\
        <table class="table" id="table3"></table>\
      </div>\
    </div>\
  '
  );
  $("#main-block-kop").html("");
  rdflib.fetchValue(null, query_kwlabel, { uri: subjecturi }, (kwlabel) => {
    const kwlabelfield = document.getElementById("kwlabel");
    kwlabelfield.innerHTML = kwlabel;
  });
  rdflib.fetchTriples(document.getElementById("table1"), query_table1, {
    uri: subjecturi,
  });
  rdflib.fetchData(document.getElementById("table2"), query_table2, {
    uri: subjecturi,
  });
  rdflib.fetchData(document.getElementById("table3"), query_table3, {
    uri: subjecturi,
  });
  rdflib.fetchData(document.getElementById("table4"), query_table4, {
    uri: subjecturi,
  });

  bind_link(queryParameters);
  return false;
}

function nav_toetsing_BegrippenMetCirkelverwijzing(queryParameters) {
  let graphuri = queryParameters.graph;
  let subjecturi = queryParameters.uri;
  let query_table1 = lees_query(
    "nav_toetsing_BegrippenMetCirkelverwijzing_table1"
  );
  let query_table2 = lees_query(
    "nav_toetsing_BegrippenMetCirkelverwijzing_table2"
  );
  maak_history(queryParameters);

  setBreadcrumb(
    ' / <a rel="breadcrumb-link" menu-url="toetsingslogboek_.html">Toetsingslogboek</a> / <a onclick="toetsing_return()">Toetsing</a> / Begrippen met cirkelverwijzing'
  );
  $("#main-block-inhoud").html(
    '<table class="table" id="table1"></table><table class="table" id="table2"></table>'
  );
  $("#main-block-kop").html(
    "<p>Onderstaande begrippen hebben een directe of indirecte cirkelverwijzing. Dit ontstaat als in een definitie van een begrip naar dit begrip zelf wordt verwezen, of als er via verwijzingen in definities een lus te maken is (A->B->..->Z->A</p>"
  );
  rdflib.fetchTriples(document.getElementById("table1"), query_table1, {
    uri: subjecturi,
  });
  rdflib.fetchData(document.getElementById("table2"), query_table2, {
    graph: subjecturi,
  });

  bind_link(queryParameters);
  return false;
}

function nav_toetsing_KennisbronnenZonderVindbareLocatie(queryParameters) {
  let graphuri = queryParameters.graph;
  let subjecturi = queryParameters.uri;
  let query_table1 = lees_query(
    "nav_toetsing_KennisbronnenZonderVindbareLocatie_table1"
  );
  let query_table2 = lees_query(
    "nav_toetsing_KennisbronnenZonderVindbareLocatie_table2"
  );
  maak_history(queryParameters);

  setBreadcrumb(
    ' / <a rel="breadcrumb-link" menu-url="toetsingslogboek_.html">Toetsingslogboek</a> / <a onclick="toetsing_return()">Toetsing</a> / Kennisbronnen zonder vindbare locatie'
  );
  $("#main-block-inhoud").html(
    '<table class="table" id="table1"></table><table class="table" id="table2"></table>'
  );
  $("#main-block-kop").html(
    "<p>Onderstaan overzicht geeft alle kennisbronnen weer die geen vindbare bronlocatie hebben. Dit zijn kennisbronnen zonder enige bronlocatie en kennisbronnen met een bronlocatie die geen URL betreft, maar slechts een tekstuele verwijzing.</p>"
  );
  rdflib.fetchTriples(document.getElementById("table1"), query_table1, {
    uri: subjecturi,
  });
  rdflib.fetchData(document.getElementById("table2"), query_table2, {
    graph: subjecturi,
  });

  bind_link(queryParameters);
  return false;
}

//function nav_inModelversie(queryParameters) {
//    let uri = queryParameters.graph;
//    const turtle_url = `/turtle_${uri}`;
//    fetch(turtle_url)
//        .then(response => {
//            const blob = response.blob();
//            const link = document.createElement('a');
//            link.download = 'turtle.ttl';
//            link.href = window.URL.createObjectURL(blob);
//            document.body.appendChild(link);
//            link.click();
//            document.body.removeChild(link);
//        })
//        .catch(error => console.error('Kan Turtle niet ophalen:', error));
//        zet_download_links(queryParameters);
//}

function verzoeken(queryParameters) {
  let graphuri = queryParameters.graph;
  let query_table1 = lees_query("verzoeken_table1");
  maak_history(queryParameters);

  setBreadcrumb(
    ' / <a rel="breadcrumb-link" menu-url="toetsingslogboek_.html">Toetsingslogboek</a> / Afgeronde verzoeken'
  );
  $("#main-block-inhoud").html('<table class="table" id="table1"></table>');
  $("#main-block-kop").html("");

  rdflib.fetchData(document.getElementById("table1"), query_table1);

  bind_link(queryParameters);
  return false;
}

function toetsingsmodellen(queryParameters) {
  let graphuri = queryParameters.graph;
  let query_table1 = lees_query("toetsingsmodellen_table1");
  maak_history(queryParameters);

  setBreadcrumb(
    ' / <a rel="breadcrumb-link" menu-url="toetsingslogboek_.html">Toetsingslogboek</a> / Alle modellen'
  );
  $("#main-block-inhoud").html('<table class="table" id="table1"></table>');
  $("#main-block-kop").html("");
  rdflib.fetchData(document.getElementById("table1"), query_table1);

  bind_link(queryParameters);
  return false;
}
