ENV = "ONT"     # TODO: VOOR HET PUSHEN, VERANDER DIT NAAR "ONT", VOOR LOKAAL TESTEN, VERANDER NAAR "LOC"

##################### CONTAINER PLATFORM ENDPOINTS #####################
if ENV == "LOC":
    DATASTORE_ENDPOINT = "https://mbieb2.ont.belastingdienst.nl/modellenbibliotheek"
    DB_CONFIG = {
        "dbname": "postgres",
        "user": "postgres",
        "password": "bdadmin",
        "host": "localhost",
        "port": "5432"
    }
elif ENV in ["ONT", "TST", "ACC", "PROD"]:
    DATASTORE_ENDPOINT = "http://mbk-fuseki:3030/modellenbibliotheek"
    DB_CONFIG = {
        "dbname": "database1",
        "user": "user1",
        "password": "password1",
        "host": "mbk-postgres",
        "port": "5432"
    }
DATASTORE_LOOKUP_ENDPOINT = DATASTORE_ENDPOINT + "/sparql"

##################### SINGLE SIGN ON #####################
PRODUCTION_BASE_URL = "https://fibi1.belastingdienst.nl"
BASE_URL = "https://fibi2.acc.belastingdienst.nl"
REDIRECT_URL = "https://modellenbibliotheek.ont.belastingdienst.nl/authorized"
AUTHORIZATION_URL = BASE_URL + "/as/authorization.oauth2"
TOKEN_URL = BASE_URL + "/as/token.oauth2"
USERINFO_URL = BASE_URL + "/idp/userinfo.openid"
CLIENT_ID = "7cb623f1-ddec-4541-a13d-9f2bcbe74647"
CLIENT_KEY = "F5udJRW2s9QnLvs77nqQni7xy7jf6I2AiaBjSkwWpl8="
SCOPE = "openid profile"

##################### FLASK ENDPOINTS #####################
SECRET = "test"
QUERY_ROUTE = "/querier"
UPLOAD_ROUTE = "/upload"
SSO_ROUTE = "/authorized"
DOWNLOAD_ROUTE = "/download"
QUERYDIENST_ROUTE = "/querydienst"
FUSEKI_RESTORE = "/fuseki_restore"
TOEVOEGEN_GEBRUIKERS = "/toevoegen_gebruikers"

PUBLIC_PAGES = [
    "",
    "/authorized",
    "?page=domeinen",
    "?page=kennisbronnen",
    "?page=kennisgebiedenregister",
    "?page=registerwijzigingen",
    "?page=kennisbanken",
    "?page=toetsingslogboek",
    "?page=dashboard",
    "?page=dashboard2"
]

ROLEBASED_ACCESS_MAPPING = {
    "mau": ["upload", "/upload", "query_dienst", "?page=upload", "?page=query_dienst", "?page=magazijn", "?page=toetsingslogboek_"],
    "das": ["upload", "/upload", "?page=upload"],
    "mod": ["upload", "/upload", "?page=upload"],
    "beh": ["upload", "/upload", "?page=upload", "query_dienst", "?page=query_dienst", "?page=magazijn", "fuseki_restore", "?page=fuseki_herstel"],
    "dflt": []
}

##################### FUNCTIONAL ENDPOINTS #####################
TOETSINGSLOGBOEK_ENDPOINT = DATASTORE_ENDPOINT + "?graph=urn:name:toetsingslogboek"
