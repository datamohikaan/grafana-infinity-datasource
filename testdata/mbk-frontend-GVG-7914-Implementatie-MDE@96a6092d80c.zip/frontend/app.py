import os.path
import requests
import warnings
import re
import tempfile
import pandas as pd
from flask import Flask, request, render_template, Response, send_file, jsonify, redirect, abort
import json
from utils import constants as cn
import psycopg2
import uuid
from rdflib import Graph, Literal,URIRef
from rdflib.namespace import RDF, RDFS, XSD
import frontend.ep.config as config
import frontend.application_fields as afn
import os
import io
import subprocess
from datetime import datetime
from requests_oauthlib import OAuth2Session
from functools import wraps

dir_path = None
model_name = None
render_result = None
turtle_url = None
original_route = None
usergroep = None
app = Flask(__name__)


def check_role_access(func):
    @wraps(func)
    def decorated_function(*args, **kwargs):
        if request.path.startswith(("?page=nav", "?page=find")) or "find" in request.path:
            pass
        else:
            if request.path not in (config.ROLEBASED_ACCESS_MAPPING[usergroep] + config.PUBLIC_PAGES):
                abort(403)
            else:
                pass
        return func(*args, **kwargs)
    return decorated_function


@app.errorhandler(403)
def forbid_access(error):
    return jsonify({
        "result": "Geen toegang tot deze functionaliteit",
        "original route": original_route,
        "usergroep": usergroep
    }), 403

if config.ENV in ["ONT", "TST", "ACC", "PROD"]:
    @app.route('/', methods=["GET", "POST"])
    @app.route('/<route>', methods=["GET", "POST"])
    @app.route(config.SSO_ROUTE, methods=["GET", "POST"])
    def index_with_sso(route=None):
        global original_route
        global usergroep
        original_route = request.full_path.replace("/", "") if "/authorized" not in request.path else original_route
        original_route = "" if original_route == "?" else original_route

        if afn.CODE in request.args:  # user is logged in
            authorization_code = request.args.get(afn.CODE)

            # Endpoint 2: Access Token
            token_params = {
                afn.GRANT_TYPE: afn.AUTHORIZATION_CODE,
                afn.CODE: authorization_code,
                afn.CLIENT_ID: config.CLIENT_ID,
                afn.CLIENT_SECRET: config.CLIENT_KEY,
                afn.REDIRECT_URI: config.REDIRECT_URL
            }
            token_response = requests.post(config.TOKEN_URL, data=token_params, headers=afn.TOKEN_HEADER, verify=False)
            token_data = token_response.json()

            # Endpoint 3: User information
            userinfo_headers = {"Authorization": f'Bearer {token_data["access_token"]}'}
            userdata = requests.get(config.USERINFO_URL, headers=userinfo_headers, verify=False).json()

            # Mapping for menu options based on usergroep
            usermenu_mapping = json.load(open("frontend/static/mb-json-groep.json"))
            # TODO: Verwijder regel 56-62 wanneer gebruikersrollen worden opgehaald uit IMS
            users_mapping = json.load(open("frontend/static/mb-json-users.json"))
            if userdata[afn.USER_NAME] not in users_mapping.keys():
                usergroep = "dflt"
            else:
                usergroep = users_mapping[userdata[afn.USER_NAME]]

            usermenu = json.dumps(usermenu_mapping[usergroep][afn.USERMENU])  # TODO: Verander wanneer de usergroep wordt meegegeven door de Identity Bridge
            usergroepnaam = usermenu_mapping[usergroep][afn.USERGROEPNAAM]

            if original_route.startswith(("?page=nav", "?page=find")) or "find" in original_route:
                pass
            else:
                if original_route not in (config.ROLEBASED_ACCESS_MAPPING[usergroep] + config.PUBLIC_PAGES):
                    abort(403)
                else:
                    pass

            sso_response = render_template(
                "index.html",
                # Render the index page with HTML variables
                usernaam=userdata[afn.NAME],
                userid=userdata[afn.USER_NAME],
                usergroepnaam=usergroepnaam,
                usermenu=usermenu,
                parameters=original_route
            )
            return sso_response
        else:
            oauth = OAuth2Session(
                client_id=config.CLIENT_ID,
                redirect_uri=config.REDIRECT_URL,
                scope=config.SCOPE,
            )
            authorization_url, authorization_code = oauth.authorization_url(config.AUTHORIZATION_URL)
            return redirect(authorization_url)
elif config.ENV == "LOC":
    @app.route('/', methods=["GET"])
    @app.route('/<route>', methods=["GET", "POST"])
    def index_without_sso(route=""):
        global original_route
        original_route = request.full_path.replace("/", "")

        usermenu_mapping = json.load(open(
            os.path.realpath(os.path.join(os.path.dirname(__file__), '..')) + os.sep + "frontend" + os.sep + "static" + os.sep + "mb-json-groep.json"
        ))
        # NOTE: Om lokaal te kunnen testen, kan de gebruikersrol (beh/mau/das/mod) worden aangepast om verschillende functies te zien
        usermenu = json.dumps(usermenu_mapping["loc"][afn.USERMENU])
        usergroepnaam = usermenu_mapping["loc"][afn.USERGROEPNAAM]
        return render_template(
            "index.html",
            usernaam="LOCAL",
            userid="LOC00",
            usergroepnaam=usergroepnaam,
            usermenu=usermenu,
            parameters=original_route
        )


@app.route(config.QUERY_ROUTE, methods=["POST"])
@check_role_access
def query_fuseki():
    query_table = json.load(open(
        os.path.realpath(os.path.join(os.path.dirname(__file__), '..')) + os.sep + "frontend" + os.sep + "static" + os.sep + "mb-json-query.json"
    ))

    query_id = request.json["query_id"]
    query_parameters = request.json["query_parameters"]
    query = "".join(query_table[query_id])

    if len(query_parameters) > 0:
        for param in query_parameters:
            query = query.replace(f"<@{param}@>", query_parameters[param])

    response = requests.post(config.DATASTORE_LOOKUP_ENDPOINT, data={'query': query}, verify=False)

    return jsonify(str(response.json()))


@app.route(config.UPLOAD_ROUTE, methods=["POST"])
@check_role_access
def upload_file():
    global render_result
    global dir_path
    global model_name
    global turtle_url

    file = request.files["fileToUpload"]
    file_name = file.filename.replace(" ", "_")
    file_name_splitted = file_name.split(".")
    file_type = file_name_splitted[-1:][0]
    file_extension = "." + file_name_splitted[-1:][0]
    model_name = file_name.replace(file_extension, "")
    file_id = uuid.uuid4().hex

    if (not file_extension.startswith(".xl")) and (file_extension != cn.LDM_EXTENSION): #and (file_extension != cn.XML_EXTENSION):
        return "Verkeerd bestandstype geselecteerd. Kies een BMS of Powerdesigner LDM bestand."
    else:
        # Pre-work for the transformation
        upload_data = dict(request.form)
        file_content = file.read()
        dir_path = tempfile.mkdtemp()
        input_file_path = os.path.join(dir_path, file_name)
        with open(input_file_path, 'wb') as f:
            f.write(file_content)

        # Transformation
        result = subprocess.run(
            [
                'python',
                '-c',
                #f'from frontend.turtle_creator import TurtleCreator; turtle_creator = TurtleCreator([r"{input_file_path}"]); turtle_creator.create_turtle(); print("VDA naam = ", turtle_creator.get_vda_model_name()); print("yml = ", turtle_creator.get_yml_data())'
                f'from frontend.turtle_creator import TurtleCreator; turtle_creator = TurtleCreator([r"{input_file_path}"]); turtle_creator.create_turtle(); print("VDA naam = ", turtle_creator.get_vda_model_name())'
            ],
            capture_output=True,
            text=True
        )

        if result.returncode == 0:
            render_result = result.stdout
            vda_model_naam = re.search(r'VDA naam =(.+?)\n', render_result).group(1)
            turtle_url = re.search(r'endpoint =(.+?)\n', render_result).group(1)
            turtle_content = requests.get(turtle_url, verify=False).text.encode('utf-8')
            named_graph = turtle_url.replace(config.DATASTORE_ENDPOINT + '?graph=', '')

            # if transformation is successful, upload in the document store
            db_connection = psycopg2.connect(**config.DB_CONFIG)
            db_cursor = db_connection.cursor()
            with db_cursor:
                create_table_query = f"CREATE TABLE IF NOT EXISTS Modelverzoeken (file_id varchar(100), model_name varchar(100), vda_model_name varchar(100), binary_data bytea, file_extension varchar(5), named_graph varchar(1000), upload_moment timestamp, bd_user varchar(7), domain varchar(100), title_request varchar(100), request_type varchar(100), model_type varchar(100), model_status varchar(100), jira_number varchar(10), extra_modellers varchar(100), remarks varchar(5000))"
                insert_query = f"INSERT INTO Modelverzoeken (file_id, model_name, vda_model_name, binary_data, file_extension, named_graph, upload_moment, bd_user, domain, title_request, request_type,  model_type, model_status, jira_number, extra_modellers, remarks) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
                db_cursor.execute(create_table_query)
                # Table insert 1: original document
                db_cursor.execute(
                    insert_query,
                    (
                        f"{file_id}-{file_name_splitted[-1:][0]}",
                        model_name,
                        vda_model_naam,
                        file_content,
                        file_extension,
                        named_graph,
                        datetime.now(),
                        upload_data[afn.BDUSER],
                        upload_data[afn.DOMAIN],
                        upload_data[afn.TITEL_VERZOEK],
                        upload_data[afn.SOORT_VERZOEK],
                        upload_data[afn.SOORT_MODEL],
                        upload_data[afn.MODEL_STATUS],
                        upload_data[afn.SD_JIRA_ITEM_NUMMER],
                        upload_data[afn.EXTRA_MODELLEURS],
                        upload_data[afn.REMARKS]
                    )
                )
                # Table insert 2: transformed model = turtle
                db_cursor.execute(
                    insert_query,
                    (
                        f"{file_id}-ttl",
                        model_name,
                        vda_model_naam,
                        turtle_content,
                        cn.TURTLE_EXTENSION,
                        named_graph,
                        datetime.now(),
                        upload_data[afn.BDUSER],
                        upload_data[afn.DOMAIN],
                        upload_data[afn.TITEL_VERZOEK],
                        upload_data[afn.SOORT_VERZOEK],
                        upload_data[afn.SOORT_MODEL],
                        upload_data[afn.MODEL_STATUS],
                        upload_data[afn.SD_JIRA_ITEM_NUMMER],
                        upload_data[afn.EXTRA_MODELLEURS],
                        upload_data[afn.REMARKS]
                    )
                )
                db_connection.commit()
                db_cursor.close()
                db_connection.close()

            # Writing to Toestingslogboek Knowledge Graph
            model_verzoek_uri = URIRef("http://modellenbibliotheek.belastingdienst.nl/id/verzoek/" + str(file_id))
            current_toetsingslogboek = requests.get(config.TOETSINGSLOGBOEK_ENDPOINT, verify=False).text.encode()
            g = Graph()
            g.parse(current_toetsingslogboek, format="turtle")
            g.bind("tlb", cn.NS_TLB)
            g.add((model_verzoek_uri, RDF.type, cn.NS_TLB.Verzoek))
            if upload_data[afn.SOORT_VERZOEK] == "TPV":
                g.add((model_verzoek_uri, RDF.type, cn.NS_TLB.Publicatieverzoek))
            elif upload_data[afn.SOORT_VERZOEK] == "FBV":
                g.add((model_verzoek_uri, RDF.type, cn.NS_TLB.Feedbackverzoek))
            g.add((model_verzoek_uri, RDFS.label, Literal(upload_data[afn.TITEL_VERZOEK])))
            g.add((model_verzoek_uri, cn.NS_TLB.betreft, URIRef(named_graph)))
            g.add((model_verzoek_uri, cn.NS_TLB.datumVerzoek, Literal(datetime.now().date(), datatype=XSD.date)))
            g.add((model_verzoek_uri, cn.NS_TLB.ingediendDoor, URIRef("http://modellenbibliotheek.belastingdienst.nl/id/medewerker/" + upload_data[afn.BDUSER])))
            g.add((model_verzoek_uri, cn.NS_MB.code, Literal(upload_data[afn.SD_JIRA_ITEM_NUMMER])))
            g.add((model_verzoek_uri, cn.NS_TLB.jiraLink, URIRef("https://jira.belastingdienst.nl/servicedesk/customer/portal/78/" + upload_data[afn.SD_JIRA_ITEM_NUMMER])))
            if upload_data[afn.EXTRA_MODELLEURS] != "":
                betrokken_personen = re.split(r'[,\s;]+', upload_data[afn.EXTRA_MODELLEURS])
                for persoon in betrokken_personen:
                    g.add((model_verzoek_uri, cn.NS_TLB.betrokken, URIRef("http://modellenbibliotheek.belastingdienst.nl/id/medewerker/" + persoon)))
            g.add((model_verzoek_uri, cn.NS_TLB.status, cn.NS_TLB.Aangemeld))
            requests.put(config.TOETSINGSLOGBOEK_ENDPOINT, data=g.serialize(format="turtle").encode('utf-8'), headers=cn.turtle_headers, verify=False)
        else:
            render_result = result.stderr

    return jsonify(render_result)


@app.route(config.TOEVOEGEN_GEBRUIKERS, methods=["POST"])
@check_role_access
def adding_users():
    file = pd.ExcelFile(request.files["fileToUpload"])
    dfs = {sheet_name: file.parse(sheet_name) for sheet_name in file.sheet_names}
    existing_users = json.load(open(os.getcwd() + "\static\mb-json-users.json".replace("\\", os.sep)))

    try:
        for sheet in file.sheet_names:
            usernames_to_add = dfs[sheet]["Username"]
            existing_users.update({user_id: afn.MAPPING_USERGROUPS[sheet] for user_id in usernames_to_add})
            with open(os.getcwd() + "\static\mb-json-users.json".replace("\\", os.sep), "w") as json_file:
                json.dump(existing_users, json_file, indent=4)
        return "Gebruikers toegevoegd!"
    except():
        return "FOUT: Gebruikers toevoegen is mislukt."


@app.route(config.DOWNLOAD_ROUTE)
def retrieve_models_documentstore():
    db_connection = psycopg2.connect(**config.DB_CONFIG)
    db_cursor = db_connection.cursor()

    with db_cursor:
        db_cursor.execute(f"SELECT model_name, file_extension, named_graph, upload_moment, model_status, file_id FROM Modellen")
        db_connection.commit()
        models = db_cursor.fetchall()
        db_cursor.close()
        db_connection.close()
    return jsonify(models)


@app.route('/download/<string:file_id>')
def retrieve_model_documentstore(file_id: str):
    db_connection = psycopg2.connect(**config.DB_CONFIG)
    db_cursor = db_connection.cursor()

    with db_cursor:
        db_cursor.execute(f"SELECT binary_data, vda_model_name, file_extension FROM Modellen WHERE file_id = %s", (file_id, ))
        db_connection.commit()
        result = db_cursor.fetchone()
        db_cursor.close()
        db_connection.close()

        if result is None:
            return "Bestand niet gevonden."

        file_content, vda_model_name, file_extension = result

    file_name = f"{vda_model_name}{file_extension}"

    return send_file(
        io.BytesIO(file_content),
        mimetype='application/octet-stream',
        as_attachment=True,
        download_name=file_name
    )


@app.route('/turtle_<string:uri>')
def view_turtle(uri: str):
    turtle_url = config.DATASTORE_ENDPOINT + "?graph=urn" + uri
    turtle_content = requests.get(turtle_url, verify=False).text
    response = Response(turtle_content, content_type='text/turtle')
    response.headers['Content-Disposition'] = f'attachment;filename="{model_name}.ttl"'
    return response


@app.route(config.QUERYDIENST_ROUTE, methods=["POST"])
@check_role_access
def querydienst():
    query = request.form['sparqlQuery']
    response = requests.post(config.DATASTORE_LOOKUP_ENDPOINT, data={'query': query}, verify=False)
    if response.status_code == 200:
        return jsonify(str(response.json()))
    else:
        return jsonify("Query niet correct.")


@app.route(config.FUSEKI_RESTORE)
@check_role_access
def fuseki_restore():
    result = subprocess.run(
        [
            'python',
            'utils' + os.sep + 'fuseki_restore.py'
        ],
        capture_output=True,
        text=True
    )
    if result.returncode == 0:
        return jsonify(result.stdout)
    else:
        return jsonify(result.stderr)


if __name__ == "__main__":
    warnings.filterwarnings("ignore")
    app.run(debug=True)
