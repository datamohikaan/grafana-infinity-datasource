import sys
import os.path
import pandas as pd
from transformation.sm_transformer import SMTransformer
from transformation.ldm_transformer import LDMTransformer
from validation.sm_validator import SMValidator
from rdflib import Graph
from os import path
from utils.loaderquads import LoaderQuads


class TurtleCreator:
    def __init__(self, gitlab_changed_files):
        self.gitlab_changed_files = gitlab_changed_files
        self.root_dir = os.path.realpath(os.path.join(os.path.dirname(__file__), '../..'))
        self.file = None
        self.file_dir = None
        self.file_name = None
        self.file_extension = None
        self.file_name_turtle = None
        self.uri = None
        self.yml = None
        self.vda_model_name = None

    def create_turtle(self):
        for idx, arg in enumerate(self.gitlab_changed_files[0:], start=0):
            print("Argument #{} is {}".format(idx, arg))
            raw_filename = arg
            self.set_file_info(raw_filename)

            print("hele pad filedir + file=" + self.file_dir + self.file)
            if path.isfile(self.file_dir + self.file):
                self.print_file_info()
                if self.file_extension == ".ttl":
                    self.handle_turtle_file()
                else:
                    self.handle_non_turtle_file()
                LoaderQuads(self.file_dir, self.file_name, self.uri, self.file_name_turtle).load_sparql()

        print("Number of elements excluding the name of the program:", (len(sys.argv) - 1))

    def set_file_info(self, raw_filename):
        self.file = raw_filename.rsplit(os.sep, 1)[-1]
        relative_path = raw_filename.replace(self.file, "")
        self.file_dir = os.path.join(self.root_dir, relative_path)
        split_filename_extension = os.path.splitext(self.file)
        self.file_name = split_filename_extension[0]
        self.file_extension = split_filename_extension[1]

    def handle_non_turtle_file(self):
        if self.file_extension == ".ldm":
            print("hoi ldm nice to see you again!")
            ldm_transformer = LDMTransformer(self.file_dir, self.file, self.file_name)
            ldm_transformer.transform_ldm_xml_to_rdf()
            self.vda_model_name = ldm_transformer.get_vda_model_name()
            self.yml = ldm_transformer.get_yml_data()

            # Obtaining the graph uri and name of the turtle file
            self.uri = ldm_transformer.get_model_uri()
            self.file_name_turtle = ldm_transformer.get_file_name_turtle()
            print("\nuri = " + self.uri)

        elif self.file_extension.startswith(".xl"):
            print("hoi SM nice to see you again!")
            input_xlsx = pd.ExcelFile(self.file_dir + self.file)

            # Model validation
            sm_validator = SMValidator(input_xlsx)
            sm_validator.validate_model()

            # Model transformation
            sm_transformer = SMTransformer(self.file_dir, self.file_name, input_xlsx)
            sm_transformer.transform_sm_xml_to_rdf()
            self.vda_model_name = sm_transformer.get_vda_model_name()

            # Obtaining the graph uri and name of the turtle file
            self.uri = sm_transformer.get_uri()
            self.file_name_turtle = sm_transformer.get_file_name_turtle()
            print("\nuri = " + self.uri)
        else:
            raise ValueError(f"Transformatie mislukt. Verkeerd bestandstype {self.file_extension} geselecteerd. Kies een .xlsx of .ldm bestand.")

    def handle_turtle_file(self):
        kennisgebiedenregister_dir = self.root_dir + os.sep + "kennisgebiedenregister" + os.sep
        self.parse_and_serialize_kennisgebiedenregister(kennisgebiedenregister_dir)
        uri = "urn:name:kennisgebiedenregister"
        print(uri)
        file_name_turtle = "sjebang_kennisgebiedenregister.ttl"
        print("file_name_turtle=" + self.file_dir + file_name_turtle)

    def parse_and_serialize_kennisgebiedenregister(self, kennisgebiedenregister):
        # g1 = Graph()
        # g1.parse(kennisgebiedenregister + "affiliatie.ttl")
        #
        # g2 = Graph()
        # g2.parse(kennisgebiedenregister + "domeinen.ttl")
        #
        # g3 = Graph()
        # g3.parse(kennisgebiedenregister + "kennisdeelgebieden.ttl")
        #
        # g4 = Graph()
        # g4.parse(kennisgebiedenregister + "kennisgebieden.ttl")
        #
        # g5 = Graph()
        # g5.parse(kennisgebiedenregister + "wetgeving.ttl")
        #
        # graph = g1 + g2 + g3 + g4 + g5
        graph = Graph()
        #graph.serialize(kennisgebiedenregister + "sjebang_kennisgebiedenregister.ttl", format="turtle")
        graph.serialize(kennisgebiedenregister, format="turtle")

    def get_yml_data(self):
        return self.yml

    def get_vda_model_name(self):
        return self.vda_model_name

    def print_file_info(self):
        if path.isfile(self.file_dir + self.file):
            print("directory = " + self.file_dir)
            print("file_name = " + self.file_name)
            print("file_extension = " + self.file_extension)
            print("Is it File?" + str(path.isfile(self.file_dir + self.file)))
            if self.file_extension != ".ttl":
                print("target directory = " + self.file_dir)
                print("file_name = " + self.file_name)
                print("file_extension = .ttl ")
