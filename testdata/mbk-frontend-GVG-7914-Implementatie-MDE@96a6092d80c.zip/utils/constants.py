from rdflib import Namespace, URIRef

######################################################################################################################
# GENERAL #
######################################################################################################################
# Namespaces URFs
URF_MB = "http://modellenbibliotheek.belastingdienst.nl/def/mb#"
URF_KGR = "http://modellenbibliotheek.belastingdienst.nl/def/kgr#"

# Custom Namespaces
NS_MB = Namespace(URF_MB)
NS_KGR = Namespace(URF_KGR)
NS_SKOSXL = Namespace("http://www.w3.org/2008/05/skos-xl#")
NS_SM = Namespace("http://modellenbibliotheek.belastingdienst.nl/def/sm#")
NS_LGD = Namespace("http://modellenbibliotheek.belastingdienst.nl/def/lgd#")
NS_TLB = Namespace("http://modellenbibliotheek.belastingdienst.nl/def/tlb#")

# Extensions
TURTLE_EXTENSION = ".ttl"
XLSX_EXTENSION = ".xlsx"
LDM_EXTENSION = ".ldm"
XML_EXTENSION = ".xml"
HTTP = "http"

# Request Header
turtle_headers = {'Content-Type': 'text/turtle;charset=utf-8'}

# Prefixes
LM_PREFIX = URIRef("http://modellenbibliotheek.belastingdienst.nl/lm/")

######################################################################################################################
# SEMANTIC MODEL #
######################################################################################################################
# General
SEMANTISCH_MODEL = "Semantisch model"
SM = "SM"

# BMS Template Sheet Names
ALGEMEEN = "Algemeen"
BEGRIPPEN = "Begrippen"
KENNISBRONNEN = "Kennisbronnen"
TERMVORMEN = "Termvormen"

# Sheet Algemeen column names
KENNISGEBIED_EN_METADATA = "KENNISGEBIED & METADATA"
WAARDEN = "WAARDEN"  # corresponds to the column "In te vullen waarden / IN TE VULLEN WAARDEN"
LINKS = "LINKS"
TOELICHTING_EN_INVULINSTRUCTIE = "TOELICHTING EN INVULINSTRUCITE"

# Column mapping dictionary
# Note: in case there are additional versions of the BMS template of sheet "Algemeen", specify the corresponding column
# names down here
ALGEMEEN_COLUMN_MAPPING = {
    WAARDEN: ["In te vullen waarden", "IN TE VULLEN WAARDEN"],
    TOELICHTING_EN_INVULINSTRUCTIE: ["Toelichting en invulinstructie"],
    LINKS: ["Links", "LINKS"]
}

# Sheet Algemeen row names
NAAM_KB = "NAAM KENNISGEBIED"
CODE_KB = "CODE KENNISGEBIED"
NAAM_KDGB = "NAAM KENNISDEELGEBIED"
CODE_KDGB = "CODE KENNISDEELGEBIED"
NAAM_MODEL = "NAAM MODEL"
TAAL_MODEL = "PRIMAIRE TAAL VAN HET MODEL"
SECTAAL_MODEL = "SECUNDAIRE TAAL VAN HET MODEL"
VERSIE_NUM_MODEL = "VERSIENUMMER MODEL"
VERSIE_DATUM_MODEL = "VERSIEDATUM MODEL"
BMS_VERSIE = "GEBASEERD OP BMS-TEMPLATE VERSIE"
ALGEMEEN_FIELD_MAPPING = {
    NAAM_KB: ["Naam kennisgebied"],
    CODE_KB: ["Code kennisgebied"],
    NAAM_KDGB: ["Naam kennisdeelgebied"],
    CODE_KDGB: ["Code kennisdeelgebied"],
    NAAM_MODEL: ["Naam model"],
    TAAL_MODEL: ["Primaire taal van het model"],
    SECTAAL_MODEL: ["Secundaire taal van het model"],
    VERSIE_NUM_MODEL: ["Versienummer model"],
    VERSIE_DATUM_MODEL: ["Versiedatum model"],
    BMS_VERSIE: ["Gebaseerd op BMS-template versie", "Gebaseerd op BMS Versie"]
}
ALGEMEEN_MANDATORY_FIELDS = {
    NAAM_KB,
    CODE_KB,
    NAAM_MODEL,
    TAAL_MODEL,
    VERSIE_NUM_MODEL,
    VERSIE_DATUM_MODEL,

}
ALGEMEEN_OPTONAL_FIELDS = [
    NAAM_KDGB,
    CODE_KDGB,
    SECTAAL_MODEL,
    BMS_VERSIE
]

# Sheet Kennisbronnen column names
CITEERTITEL = "CITEERTITEL"
ONDERDEELVAN = "ONDERDEEL VAN"
BRONNAAM = "BRONNAAM"
BRONLOCATIE = "BRONLOCATIE"
KENNISBRONNEN_MANDATORY_COLUMNS = [
    CITEERTITEL,
    ONDERDEELVAN,
    BRONNAAM,
    BRONLOCATIE
]
KENNISBRONNEN_OPTIONAL_COLUMNS = []
KENNISBRONNEN_COLUMNS = KENNISBRONNEN_MANDATORY_COLUMNS + KENNISBRONNEN_OPTIONAL_COLUMNS
KENNISBRONNEN_COLUMN_MAPPING = {
    CITEERTITEL: ["Citeertitel", "CITEERTITEL"],
    ONDERDEELVAN: ["Onderdeel van", "ONDERDEEL VAN"],
    BRONNAAM: ["Bronnaam", "BRONNAAM"],
    BRONLOCATIE: ["Bronlocatie", "BRONLOCATIE"]
}

# Sheet Begrippen column names
VOORKEURSTERM = "VOORKEURSTERM"
BOVENLIGGEND_BEGRIP = "BOVENLIGGEND BEGRIP"
DEFINITIE = "DEFINITIE"
TOELICHTING = "TOELICHTING"
REDACTIONELE_OPMERKING = "REDACTIONELE OPMERKING"
ALTERNATIEVE_TERMEN = "ALTERNATIEVE TERM(EN)"
BEGRIPPEN_KENNISBRONNEN = "KENNISBRON(NEN)"
VOORKEURSTERM_SECUNDAIRE_TAAL = "VOORKEURSTERM SECUNDAIRE TAAL"
DEFINITIE_SECUNDAIRE_TAAL = "DEFINITIE SECUNDAIRE TAAL"
VOORBEELDEN = "VOORBEELD(EN)"
BEGRIPPEN_MANDATORY_COLUMNS = [
    VOORKEURSTERM,
    BOVENLIGGEND_BEGRIP,
    DEFINITIE,
    TOELICHTING,
    ALTERNATIEVE_TERMEN,
    BEGRIPPEN_KENNISBRONNEN,
    VOORBEELDEN
]
BEGRIPPEN_OPTIONAL_COLUMNS = [
    REDACTIONELE_OPMERKING,
    VOORKEURSTERM_SECUNDAIRE_TAAL,
    DEFINITIE_SECUNDAIRE_TAAL
]
BEGRIPPEN_COLUMNS = BEGRIPPEN_MANDATORY_COLUMNS + BEGRIPPEN_OPTIONAL_COLUMNS
BEGRIPPEN_COLUMN_MAPPING = {
    VOORKEURSTERM: ["VOORKEURSTERM", "Voorkeursterm"],
    BOVENLIGGEND_BEGRIP: ["BOVENLIGGEND BEGRIP", "Bovenliggend begrip"],
    DEFINITIE: ["DEFINITIE", "Definitie"],
    TOELICHTING: ["TOELICHTING", "Toelichting"],
    REDACTIONELE_OPMERKING: ["REDACTIONELE OPMERKING", "Redactionele Opmerking"],
    ALTERNATIEVE_TERMEN: ["ALTERNATIEVE TERM(EN)", "Alternatieve term(en)", "Synoniem(en)", "Synoniemen"],
    BEGRIPPEN_KENNISBRONNEN: ["KENNISBRON(NEN)", "Kennisbron(nen)"],
    VOORBEELDEN: ["VOORBEELD(EN)", "Voorbeeld(en)"]
}

# Sheet Termvormen
ENKELVOUD = "ENKELVOUD"
MEERVOUD = "MEERVOUD"
AFKORTING = "AFKORTING"
TERMVORMEN_MANDATORY_COLUMNS = [
    ENKELVOUD,
    MEERVOUD,
    AFKORTING
]
TERMVORMEN_OPTIONAL_COLUMNS = []
TERMVORMEN_COLUMNS = TERMVORMEN_MANDATORY_COLUMNS + TERMVORMEN_OPTIONAL_COLUMNS
TERMVORMEN_COLUMN_MAPPING = {
    ENKELVOUD: ["ENKELVOUD"],
    MEERVOUD: ["MEERVOUD"],
    AFKORTING: ["AFKORTING"]
}

######################################################################################################################
# LDM Model #
######################################################################################################################
VERSION = "Version"
OBJECT_ID = "ObjectID"
NAME = "Name"
ANNOTATION = "Annotation"
DESCRIPTION = "Description"
MODIFICATION_DATE = "ModificationDate"
REF_ENT_ID = "RefEntID"
ID = "Id"

ENTITY2TOENTITY1ROLE = "Entity2ToEntity1Role"
ENTITY1TOENTITY2ROLE = "Entity1ToEntity2Role"
ENTITY1TOENTITY2ROLECARDINALITY = "Entity1ToEntity2RoleCardinality"
ENTITY2TOENTITY1ROLECARDINALITY = "Entity2ToEntity1RoleCardinality"
MODEL_PROPERTY_SET = [OBJECT_ID, VERSION, NAME, "Code", ANNOTATION, "RepositoryFilename", "CreationDate", "Creator", MODIFICATION_DATE, "Modifier", DESCRIPTION, "Comments"]
ENTITY_PROPERTY_SET = [OBJECT_ID, NAME, "Code", "CreationDate", "Creator", MODIFICATION_DATE, "Modifier", DESCRIPTION]
ATTRIBUTE_PROPERTY_SET = [OBJECT_ID, NAME, "Code", "CreationDate", "Creator", MODIFICATION_DATE, "Modifier", "DataType", "Length", DESCRIPTION]
INDEX_PROPERTY_SET = [OBJECT_ID, NAME, "Code", "CreationDate", "Creator", MODIFICATION_DATE, "Modifier"]
IDXATTRIBUTE_PROPERTY_SET = [OBJECT_ID, "CreationDate", "Creator", MODIFICATION_DATE, "Modifier"]
RELATIONSHIP_PROPERTY_SET = [OBJECT_ID, NAME, "Code", "CreationDate", "Creator", MODIFICATION_DATE, "Modifier", "Entity2ToEntity1Role", "Entity1ToEntity2Role", "Entity1ToEntity2RoleCardinality", "Entity2ToEntity1RoleCardinality"  ]
RELENTITY_PROPERTY_SET = [OBJECT_ID, NAME, "Code", MODIFICATION_DATE]
DOMAIN_PROPERTY_SET = [OBJECT_ID, NAME, "Code", MODIFICATION_DATE]
SHORTCUT_PROPERTY_SET = [OBJECT_ID, NAME, "Code", "TargetID", MODIFICATION_DATE]

PROPERTY_PATTERN = r'(\d+(?:\.\d+){2})'