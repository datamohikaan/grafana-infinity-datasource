def query_code_kennisgebieden(lookup_code_kb: str):
    return f"""
    prefix kgr: <http://modellenbibliotheek.belastingdienst.nl/def/kgr#>
    select ?kennisgebied 
    where {{ graph <urn:name:kennisgebiedenregister> {{
    ?kennisgebied kgr:code {lookup_code_kb}.
    ?kennisgebied a kgr:Kennisgebied.
    }}
    }}
    """


def query_code_begrippen(lookup_code_kb: str, lookup_begrip: str):
    return f"""
    PREFIX skos: <http://www.w3.org/2004/02/skos/core#>
    prefix kgr: <http://modellenbibliotheek.belastingdienst.nl/def/kgr#>
    select ?begrip
    where {{
        graph <urn:name:kennisgebiedenregister> {{
            ?kg a kgr:Kennisgebied.
            ?kg kgr:code "{lookup_code_kb}".
        }}
        graph ?bgraph {{
            ?model a skos:ConceptScheme.
            ?model kgr:kennisgebied ?kg.
            ?begrip a skos:Concept.
            ?begrip (skos:prefLabel|skos:hiddenLabel) ?term.
            FILTER (regex(?term,"^{lookup_begrip}$","i"))
        }}
    }}
    """
