import os.path
import sys
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.append(os.path.dirname(CURRENT_DIR))
import os
import sys
import uuid
import ssl
import pandas as pd
from SPARQLWrapper import SPARQLWrapper2
from rdflib import URIRef, Graph
from utils.sparql_queries import query_code_kennisgebieden, query_code_begrippen

# TODO: Mag eventueel eruit als er geen environment variabelen nodig zijn
def get_environment():
    if os.getenv('CI_ENVIRONMENT_NAME'):
        return os.getenv('CI_ENVIRONMENT_NAME')
    else:
        return "ontwikkeling"


# TODO: Mag eventueel eruit als er geen environment variabelen nodig zijn
def get_datastore_endpoint():
    return os.getenv('DATASTORE')


def read_sheet_as_dataframe(
        xls_file: pd.ExcelFile,
        sheet_name: str,
        index_column: int = None,
        rename_columns: bool = False,
        rename_index: bool = False,
        column_mapping: dict = None,
        index_mapping: dict = None,
):
    """Reads sheet from an Excel file where the choice can be made to rename the columns to a generic name
        :param xls_file: the respective Excel sheet that need to be read in
        :param sheet_name: the corresponding sheet name
        :param index_column: optional argument, in case one would like to specify an index column
        :param rename_columns: optional argument, flag to indicate whether one would like to rename the column names
        and provide generic names
        :param rename_index: optional argument, flag to indicate whether one would like to rename the index names
        and provide generic names
        :param column_mapping: optional argument, the column mapping needed for the column renaming
        :param index_mapping: optional argument, the index mapping needed for the index renaming
        :return: created dataframe with potentially specified index column and generic column names
    """
    df = pd.read_excel(xls_file, sheet_name, index_col=index_column)

    if rename_columns:
        for generic_name, column_names in column_mapping.items():
            actual_columns = [col for col in df.columns if col in column_names]
            if actual_columns:
                df.rename(columns={actual_columns[0]: generic_name}, inplace=True)

    if rename_index:
        for generic_name, index_names in index_mapping.items():
            actual_index = [index for index in df.index if index in index_names]
            if actual_index:
                df.rename(index={actual_index[0]: generic_name}, inplace=True)

    return df


def create_uri(name: str) -> URIRef:
    """Each cononical uri has the following structure according to RFC4122.

    :param name: name of the namespace
    :return: the created uri
    """
    uuidstr = uuid.uuid5(uuid.NAMESPACE_URL, name)
    return URIRef(f'urn:uuid:{uuidstr}')


def get_column_index(df: pd.DataFrame, column: str):
    """Returns the column index number of a dataframe - the number does not start at zero, but is corrected with plus one
    :param df: the dataframe of which the index number is desired
    :param column: the column name
    :return: the column index number
    """
    return df.columns.get_loc(column) + 1


def capitalize_df(df: pd.DataFrame, capitalize_index: bool = False, capitalize_columns: bool = False):
    """
    :param df: the input dataframe
    :param capitalize_index: flag whether we want to  capitalize the index names
    :param capitalize_columns: flag whether to capitalize the column names
    :return: the dataframe with the capitalized names
    """
    if capitalize_index:
        df.index = [index.upper() for index in df.index]

    if capitalize_columns:
        df.columns = [column.upper() for column in df.columns]

    return df


def lookup_kb_uri(lookup_endpoint: str, lookup_code_kb: str, is_kg: bool):
    """Looks up the uris from Kennisgebiedenregister
    :param lookup_endpoint: the end point reference from the the look-up should be done
    :param lookup_code_kb: the respective code to be looked up, either a kb code or a kdgb code
    :param is_kg: flag to specify whether the code is kb (True) or kdgb (False)
    :return: list containing the uris
    """
    ssl._create_default_https_context = ssl._create_unverified_context
    sparql = SPARQLWrapper2(lookup_endpoint)
    sparql.setQuery(query_code_kennisgebieden(lookup_code_kb))
    uri = []
    for result in sparql.query().bindings:
        uri.append(result['kennisgebied'].value)
    if not uri:
        if is_kg:
            raise ValueError(
                f"Het kennisgebied met code {lookup_code_kb} komt niet voor in het kennisgebiedenregister."
            )
            sys.exit(1)
        else:
            print(
                f"Het kennisdeelgebied met code {lookup_code_kb} komt niet voor in het kennisgebiedenregister."
            )
    else:
        return uri[0]


def lookup_begrip_uri(lookup_endpoint: str, lookup_code_kb: str, lookup_begrip: str):
    """Looks up the uris from Kennisgebiedenregister
    :param lookup_endpoint: the end point reference from the the look-up should be done
    :param lookup_code_kb: the respective code to be looked up, either a kb code or a kdgb code
    :param lookup_begrip: "begrip" to be looked up
    :return: list containing the uris
    """
    ssl._create_default_https_context = ssl._create_unverified_context
    sparql = SPARQLWrapper2(lookup_endpoint)
    sparql.setQuery(query_code_begrippen(lookup_code_kb, lookup_begrip))
    uri = []
    for result in sparql.query().bindings:
        uri.append(result['begrip'].value)
    if not uri:
        print(
            f"Het begrip \"{lookup_begrip}\" komt niet voor in het kennisgebiedenregister {lookup_code_kb}."
        )
    else:
        return uri[0]


def find_uri_in_graph(g: Graph, filters):
    """Returns the uri of a triple of the respective graph
    :param g: the respecive Graph
    :param filters: item to look for in the graph, no type is passed to have it generic
    :return: uri of the item
    """
    for (s, p, o) in g:
        if o == filters:
            return s