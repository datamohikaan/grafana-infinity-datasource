from utils import constants as cn


def __get_nodes_by_path(parent, xml_path: str) -> list:
    """Looks for all the nodes within a path and returns it
    :param parent: the starting node
    :param xml_path: the path where to look the nodes in
    :return: the list of found nodes
    """
    current_node = parent
    for tag in xml_path.split("/")[0:-1]:
        tag_desc = tag.split("|")
        tag_name, tag_index = tag_desc[0], (int(tag_desc[1]) if len(tag_desc) == 2 else 0)
        child_nodes = []
        for child_node in current_node.childNodes:
            if child_node.nodeName == tag_name:
                child_nodes.append(child_node)
        if len(child_nodes) < tag_index + 1:
            return []
        current_node = child_nodes[tag_index]

    # Special treatment for path on last level
    tag = xml_path.split("/")[-1]
    tag_desc = tag.split("|")
    tag_name, tag_index = tag_desc[0], (int(tag_desc[1]) if len(tag_desc) == 2 else None)
    child_nodes = []
    for child_node in current_node.childNodes:
        if child_node.nodeName == tag_name:
            child_nodes.append(child_node)
    if tag_index == None:
        return child_nodes
    elif len(child_nodes) < tag_index + 1:
        return []
    else:
        current_node = child_nodes[tag_index]
        return current_node


def __get_model_nodes_recursively(o_model) -> list:
    """Looks for all the nodes recursively
    :param o_model: the node where the recursive search should start
    :return: the list of found nodes
    """
    if o_model.nodeName != "o:Model" and o_model.nodeName != "o:Package":
        return []
    return_list = []
    submodels = __get_nodes_by_path(o_model, "c:Packages/o:Package")
    if submodels != None:
        for submodel in submodels:
            return_list.append(submodel)
            return_list = return_list + __get_model_nodes_recursively(submodel)
    else:
        return []
    return return_list


def get_model_nodes(input_xml) -> list:
    """Finding all nodes within the model
    :param input_xml: the model
    :return: the list of the found nodes
    """
    return_list = []
    try:
        o_model = __get_nodes_by_path(input_xml, "Model/o:RootObject/c:Children/o:Model")[0]
        return_list.append(o_model)
    except IndexError:
        return []
    return_list = return_list + __get_model_nodes_recursively(o_model)
    return return_list


def get_model_properties(model_node) -> dict:
    """Obtaining the properties from a specific model node
    :param model_node: the model node of which the properties should be obtained
    :return: the dictionary with the model properties
    """
    return __get_properties_by_list(model_node, cn.MODEL_PROPERTY_SET)


def __get_properties_by_list(parent, attribute_list) -> dict:
    """Obtaining the properties from a parent node according to the attribute list
    :param parent: the model node of which the properties should be obtained
    :param attribute_list: the list containing the attributes that should be looked for
    :return: the dictionary with the found properties
    """
    return_dict = {}
    for attribute in attribute_list:
        return_dict[attribute] = ""
        for child in parent.childNodes:
            if child.nodeName == "a:" + attribute:
                return_dict[attribute] = child.childNodes[0].data
                break
    return return_dict


def get_entity_nodes_in_model(model_node) -> list:
    """Obtaining the entity nodes from a model
    :param model_node: the model node of which the entity nodes should be obtained
    :return: the list containing the nodes
    """
    return __get_nodes_by_path(model_node, "c:Entities/o:Entity")


def get_entity_properties(entity_node) -> dict:
    """Obtaining the entity properties from an entity node
    :param entity_node: the node of which the properties should be obtained
    :return: dictionary containing the properties
    """
    return __get_properties_by_list(entity_node, cn.ENTITY_PROPERTY_SET)


def get_attribute_nodes_in_entities(attribute_node) -> list:
    """Obtaining the attributes nodes from an entity
    :param attribute_node: the respective attribute node
    :return: the list containing the nodes
    """
    return __get_nodes_by_path(attribute_node, "c:Attributes/o:EntityAttribute")


def get_attribute_properties(attribute_node) -> dict:
    """Obtaining the attributes properties from an attribute
    :param attribute_node: the respective attribute node
    :return: the dictionary containing the properties
    """
    return __get_properties_by_list(attribute_node, cn.ATTRIBUTE_PROPERTY_SET)


def get_domain_nodes_in_model(model_node) -> list:
    """Obtaining the domain nodes in a model
    :param model_node: the respective model node
    :return: the list containing the nodes
    """
    return __get_nodes_by_path(model_node, "c:Domains/o:Domain")


def get_domain_properties(domain_node) -> dict:
    """Obtaining the domain properties from a domain node
    :param domain_node: the respective domain node
    :return: the dictionary containing the domain properties
    """
    return __get_properties_by_list(domain_node, cn.DOMAIN_PROPERTY_SET)


def get_shortcut_nodes_in_model(model_node) -> list:
    """Obtaining the shortcut nodes in a model
    :param model_node: the respective model
    :return: the list containing the nodes
    """
    return __get_nodes_by_path(model_node, "c:Domains/o:Shortcut")


def get_shortcut_properties(shortcut_node) -> dict:
    """Obtaining the shortcut properties from the node
    :param shortcut_node: the respective node
    :return: the dictionary containing the properties
    """
    return __get_properties_by_list(shortcut_node, cn.SHORTCUT_PROPERTY_SET)


def get_relation_nodes_in_model(relation_node) -> list:
    """Obtaining the relation nodes in a model
    :param relation_node: the respective model
    :return: the list containing the nodes
    """
    return __get_nodes_by_path(relation_node, "c:Relationships/o:Relationship")


def get_relation_properties(relation_node) -> dict:
    """Obtaining the relation properties from the node
    :param relation_node: the respective node
    :return: the dictionary containing the properties
    """
    return __get_properties_by_list(relation_node, cn.RELATIONSHIP_PROPERTY_SET)


def get_attribute_domain_properties(attribute_node) -> dict:
    """Obtaining the attribute domain properties from the node
    :param attribute_node: the respective node
    :return: the dictionary containing the properties
    """
    return_dict = __get_properties_by_list(attribute_node, cn.DOMAIN_PROPERTY_SET)
    ref_entity = __get_nodes_by_path(attribute_node, "c:Domain/o:Domain")
    try:
      ref_entity_id = ref_entity[0].getAttribute("Ref")
    except IndexError:
      return_dict["RefEntID"] = ""
      return return_dict
    return_dict["RefEntID"] = ref_entity_id
    return return_dict


def get_attribute_domain_shortcut_properties(attribute_node) -> dict:
    """Obtaining the shortcut domain properties from the node
    :param attribute_node: the respective node
    :return: the dictionary containing the properties
    """
    return_dict = __get_properties_by_list(attribute_node, cn.ATTRIBUTE_PROPERTY_SET)
    ref_entity = __get_nodes_by_path(attribute_node, "c:Domain/o:Shortcut")
    try:
      ref_entity_id = ref_entity[0].getAttribute("Ref")
    except IndexError:
      return_dict["RefEntID"] = ""
      return return_dict
    return_dict["RefEntID"] = ref_entity_id
    return return_dict


def get_relation_entity_1_properties(relation_entity_node):
    """Obtaining the relation entity properties
    :param relation_entity_node: the respective node
    :return: the dictionary containing the properties
    """
    return_dict = __get_properties_by_list(relation_entity_node, cn.RELENTITY_PROPERTY_SET)
    ref_entity = __get_nodes_by_path(relation_entity_node, "c:Object1/o:Entity")
    try:
      ref_entity_id = ref_entity[0].getAttribute("Ref")
    except IndexError:
      return_dict["RefatbCode"] = ""
      return return_dict
    return_dict["RefEntID"] = ref_entity_id
    return return_dict


def get_relation_entity_2_properties(relation_entity_node):
    """Obtaining the relation entity properties
    :param relation_entity_node: the respective node
    :return: the dictionary containing the properties
    """
    return_dict = __get_properties_by_list(relation_entity_node, cn.RELENTITY_PROPERTY_SET)
    ref_entity = __get_nodes_by_path(relation_entity_node, "c:Object2/o:Entity")
    try:
      ref_entity_id = ref_entity[0].getAttribute("Ref")
    except IndexError:
      return_dict["RefatbCode"] = ""
      return return_dict
    return_dict["RefEntID"] = ref_entity_id
    return return_dict
