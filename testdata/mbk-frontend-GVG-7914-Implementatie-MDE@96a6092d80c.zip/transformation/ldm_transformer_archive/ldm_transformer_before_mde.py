import os
import re
import uuid
import xml.dom.minidom
from datetime import datetime
import shutil
import yaml
import json
from rdflib import Graph, URIRef, Literal
from rdflib.namespace import RDF, RDFS, DCTERMS, SKOS, XSD
from striprtf.striprtf import rtf_to_text
import utils.constants as cn
import utils.utils_ldm_handler as ldm
from transformation.mde.pd_ldm_preprocessor import PowerDesignerLDMPreprocessor
from transformation.mde import xml_extractor, ldm2json, mde_generator
from utils.utils import create_uri


class LDMTransformer:
    def __init__(self, file_dir: str, file: str, file_name: str):
        self.file_dir = file_dir
        self.file_name = file_name
        self.file_path = file_dir + os.sep + file
        self.file_name_turtle = self.file_name + cn.TURTLE_EXTENSION
        self.yaml = None
        self.input_xml = xml.dom.minidom.parse(self.file_path)
        self.g = Graph()
        self.versie_num_model = None
        self.model_uri = None
        self.naam_model = None
        self.logisch_model = None
        self.versie_datum_model = None
        self.ldm_json = None

    def generate_yml(self):
        """Generates the yml files needed for the transformation to turtle. Code is obtained from the MDE.
        """
        MDE_ROOT_DIR = os.path.dirname(os.getcwd()) + os.sep + "transformation" + os.sep + "mde"
        MDE_OUTPUT_DIR = os.path.join(MDE_ROOT_DIR, "output")

        if os.path.isdir(MDE_OUTPUT_DIR):
            shutil.rmtree(MDE_OUTPUT_DIR)
        # Recreate output directory
        os.mkdir(MDE_OUTPUT_DIR)

        # Run preprocessor
        preprocessor: PowerDesignerLDMPreprocessor = PowerDesignerLDMPreprocessor()
        preprocessor.preprocess_ldm(self.file_path)
        # Run extractor
        xml_extractor.extract(self.file_path.replace(".ldm", "_preprocessed.ldm"),
                              os.path.join(MDE_ROOT_DIR, "mde_utils/powerdesigner-extractor-config.yml"),
                              MDE_OUTPUT_DIR)
        # Run YML convertor
        ldm2yaml.generate_json(source_path=MDE_OUTPUT_DIR, target_file=self.file_path.replace(".ldm", ".yml"))

        # Saving yaml
        with open(self.file_path.replace(".ldm", ".yml"), "r") as file:
            self.yaml = yaml.safe_load(file)

        with open(os.path.join(MDE_OUTPUT_DIR, "ldm.json"), 'r') as json_file:
            self.ldm_json = json.load(json_file)

    def create_namespace_graph(self):
        """Creates the Namespace graph with the specified namespaces.
        :return: returns the created Namespace Graph.
        """
        # Adding custom namespaces
        naam_kb = "lOC"
        self.g.bind("mb", cn.NS_MB)
        self.g.bind("lgd", cn.NS_LGD)
        self.g.bind("kgr", cn.NS_KGR)
        self.g.bind("skos", SKOS)
        self.g.bind("rdfs", RDFS)
        self.g.bind("dcterms", DCTERMS)

        # Obtaining model information
        for mdl in ldm.get_model_nodes(self.input_xml):
            model_properties = ldm.get_model_properties(mdl)
            self.versie_num_model = re.findall(cn.PROPERTY_PATTERN, model_properties[cn.VERSION])[0]
            self.naam_model = model_properties[cn.NAME]
            # self.versie_datum_model = datetime.fromtimestamp(int(model_properties[cn.MODIFICATION_DATE]))
            # 1706189133
            # print("dt_object =", dt_object)
            # dt_object = 2024 - 01 - 25 14: 25:33
            dt_object = datetime.fromtimestamp(int(model_properties[cn.MODIFICATION_DATE]))
            self.versie_datum_model = str(dt_object.year) + "-" + str(dt_object.month) + "-" + str(dt_object.day)
            model_file_name = model_properties[cn.OBJECT_ID] + self.versie_num_model

        self.logisch_model = "Logisch model " + Literal(self.naam_model)
        # Creating model and model version uris
        hash_uuid = uuid.uuid5(uuid.NAMESPACE_URL, str(model_file_name))
        self.model_uri = URIRef(f'urn:uuid:{hash_uuid}')
        model_version_uri = (URIRef(cn.LM_PREFIX + self.versie_num_model))

        # Adding model information to the graph
        self.g.add((self.model_uri, RDF.type, cn.NS_LGD.LogischGegevensdefinitieModel))
        self.g.add((self.model_uri, RDF.type, cn.NS_MB.Model))
        self.g.add((self.model_uri, cn.NS_KGR.kennisgebied,
                    URIRef("http://modellenbibliotheek.belastingdienst.nl/id/kennisgebied/" + naam_kb)))
        self.g.add((self.model_uri, RDFS.label, Literal(self.logisch_model)))
        self.g.add((model_version_uri, RDF.type, cn.NS_MB.Modelversie))
        self.g.add((model_version_uri, cn.NS_MB.versieVan, self.model_uri))
        self.g.add((model_version_uri, cn.NS_MB.versiedatum, Literal(self.versie_datum_model, datatype=XSD.date)))
        self.g.add((model_version_uri, cn.NS_MB.versienummer, Literal(self.versie_num_model)))
        self.g.add((model_version_uri, RDFS.label, Literal(self.logisch_model)))
        self.g.add((model_version_uri, cn.NS_MB.status, cn.NS_MB.Finaal))
        self.g.add((model_version_uri, cn.NS_MB.naam, Literal(self.naam_model + "-" + self.versie_num_model)))
        self.g.add((model_version_uri, cn.NS_MB.titel, Literal(self.naam_model + "-" + self.versie_num_model)))

    def process_entities(self):
        """Processes the entity properties and adds it to the NameSpace graph"""
        for model in ldm.get_model_nodes(self.input_xml):
            for entity in ldm.get_entity_nodes_in_model(model):
                entity_properties = ldm.get_entity_properties(entity)
                entity_name = entity_properties[cn.NAME]
                entity_description = entity_properties[cn.DESCRIPTION]
                entity_description = rtf_to_text(entity_description)
                clean_entity_description = entity_description.strip()
                subject = create_uri(str(entity_properties[cn.OBJECT_ID]))

                self.g.add((subject, RDFS.isDefinedBy, self.model_uri))

                self.g.add((subject, RDF.type, cn.NS_LGD.Entiteittype))
                self.g.add((subject, RDFS.label, Literal(entity_name)))
                self.g.add((subject, cn.NS_LGD.naam, Literal(entity_name)))
                self.g.add((subject, cn.NS_LGD.gegevensdefinitie, Literal(clean_entity_description)))

                for attribute in ldm.get_attribute_nodes_in_entities(entity):
                    attribute_properties = ldm.get_attribute_properties(attribute)
                    self.g.add((subject, cn.NS_LGD.attribuut, create_uri(str(attribute_properties[cn.OBJECT_ID]))))

    def process_attributes(self):
        """Processes the attribute properties and adds it to the graph"""
        for model in ldm.get_model_nodes(self.input_xml):
            for entity in ldm.get_entity_nodes_in_model(model):
                for attribute in ldm.get_attribute_nodes_in_entities(entity):
                    attribute_properties = ldm.get_attribute_properties(attribute)

                    # label
                    subject = create_uri(f"{attribute_properties[cn.OBJECT_ID]}")
                    self.g.add((subject, RDF.type, cn.NS_LGD.Attribuuttype))
                    self.g.add((subject, RDFS.label, Literal(attribute_properties[cn.NAME])))

                    # begripsnaam
                    attribute_description = rtf_to_text(attribute_properties[cn.DESCRIPTION])
                    attribute_description = attribute_description.replace('\n', "")
                    if len(attribute_description) > 0:
                        self.g.add((subject, cn.NS_LGD.begripsnaam, Literal(attribute_description)))

                    # domain
                    attribute_domain_properties = ldm.get_attribute_domain_properties(attribute)
                    for domain in ldm.get_domain_nodes_in_model(model):
                        domain_properties = ldm.get_domain_properties(domain)
                        if domain.getAttribute(cn.ID) == attribute_domain_properties[cn.REF_ENT_ID]:
                            self.g.add(
                                (subject, cn.NS_LGD.attribuutdomein, create_uri(f"{domain_properties[cn.OBJECT_ID]}")))

                    # shortcuts
                    attribute_shortcut_properties = ldm.get_attribute_domain_shortcut_properties(attribute)
                    for shortcut in ldm.get_shortcut_nodes_in_model(model):
                        shortcut_properties = ldm.get_shortcut_properties(shortcut)
                        if shortcut.getAttribute(cn.ID) == attribute_shortcut_properties[cn.REF_ENT_ID]:
                            self.g.add((subject, cn.NS_LGD.attribuutdomein,
                                        create_uri(f"{shortcut_properties[cn.OBJECT_ID]}")))

    def process_relations(self):
        """Processes the relation properties and adds it to the graph"""
        for model in ldm.get_model_nodes(self.input_xml):
            for relation in ldm.get_relation_nodes_in_model(model):
                relation_properties = ldm.get_relation_properties(relation)
                subject = create_uri(f"{relation_properties[cn.OBJECT_ID]}")
                self.g.add((subject, RDF.type, cn.NS_LGD.Relatietype))
                self.g.add((subject, RDFS.label, Literal(relation_properties[cn.NAME])))
                self.g.add((subject, RDFS.isDefinedBy, self.model_uri))
                self.g.add((subject, cn.NS_LGD.naarRolnaam,
                            Literal(relation_properties[cn.ENTITY1TOENTITY2ROLE])
                            ))
                self.g.add((subject, cn.NS_LGD.vanrRolnaam,
                            Literal(relation_properties[cn.ENTITY2TOENTITY1ROLE])
                            ))
                self.g.add((subject, cn.NS_LGD.naarCardinaliteit,
                            Literal(relation_properties[cn.ENTITY2TOENTITY1ROLECARDINALITY])
                            ))
                self.g.add((subject, cn.NS_LGD.vanCardinaliteit,
                            Literal(relation_properties[cn.ENTITY1TOENTITY2ROLECARDINALITY])
                            ))

                relation_entity_properties_1 = ldm.get_relation_entity_1_properties(relation)
                for entity in ldm.get_entity_nodes_in_model(model):
                    entity_properties = ldm.get_entity_properties(entity)
                    if entity.getAttribute(cn.ID) == relation_entity_properties_1[cn.REF_ENT_ID]:
                        self.g.add(
                            (subject, cn.NS_LGD.naarEntiteittype, create_uri(f"{entity_properties[cn.OBJECT_ID]}")))

                relation_entity_properties_2 = ldm.get_relation_entity_2_properties(relation)
                for entity in ldm.get_entity_nodes_in_model(model):
                    entity_properties = ldm.get_entity_properties(entity)
                    if entity.getAttribute(cn.ID) == relation_entity_properties_2[cn.REF_ENT_ID]:
                        self.g.add(
                            (subject, cn.NS_LGD.vanEntiteittype, create_uri(f"{entity_properties[cn.OBJECT_ID]}")))

    def process_domains(self):
        """Processes the domain properties and adds it to the graph"""
        for model in ldm.get_model_nodes(self.input_xml):
            for domain in ldm.get_domain_nodes_in_model(model):
                domain_properties = ldm.get_domain_properties(domain)
                subject = create_uri(f"{domain_properties[cn.OBJECT_ID]}")
                self.g.add((subject, RDF.type, cn.NS_LGD.Attribuutdomein))
                self.g.add((subject, RDFS.label, Literal(domain_properties[cn.NAME])))
                self.g.add((subject, RDFS.isDefinedBy, self.model_uri))

    def process_shortcuts(self):
        """Processes the shortcut properties and adds it to the graph"""
        for model in ldm.get_model_nodes(self.input_xml):
            for shortcut in ldm.get_shortcut_nodes_in_model(model):
                shortcut_properties = ldm.get_shortcut_properties(shortcut)
                subject = create_uri(f"{shortcut_properties[cn.OBJECT_ID]}")
                self.g.add((subject, RDF.type, cn.NS_LGD.Attribuutdomein))
                self.g.add((subject, RDFS.label, Literal(shortcut_properties[cn.NAME])))
                self.g.add((subject, RDFS.isDefinedBy, self.model_uri))

    def get_model_uri(self):
        """Returns the model uri"""
        return self.model_uri

    def get_file_name_turtle(self):
        """Returns the name of the turtle file"""
        return self.file_name_turtle

    def get_yml_data(self):
        """Returns the generated yaml file"""
        return self.yaml

    def transform_ldm_xml_to_rdf(self):
        """Main function that processes the LDM input file and transforms it into the Turtle file"""
        self.generate_yml()
        self.create_namespace_graph()
        self.process_entities()
        self.process_attributes()
        self.process_relations()
        self.process_domains()
        self.process_shortcuts()
        self.g.serialize(destination=self.file_dir + self.file_name_turtle)
        f = open(self.file_dir + self.file_name_turtle, "a")
        f.write(f"#Named Graph name: {self.logisch_model}, {self.model_uri}")
        f.close()
