#filename LDMHandler.py Created on 2021-11-11
#@author: PB
import xml.dom.minidom
from xml.dom.minidom import parse


#
#         ,.=:!!t3Z3z.,                  Why did we create PowerDeComposer
#        :tt:::tt333EE3                  --------------------
#        Et:::MAC-OSEEL @Ee.,      ..,   http://powerdecomposer.x-breeze.com/
#       ;tt:::tt333EE7 ;EEEEEEttttt33#   https://github.com/petjiang/PDMHandler
#      :Et:::zt333EEQ. $EEELINUX 33QL    https://dev.azure.com/x-breeze/_git/PowerDeComposer_Public?anchor=how-to-get-powerdecomposer
#      it::::tt333EEF @EEEEEEttttt33F
#     ;3=*^```"*4EEV :EEEEEEttttt33@.
#     ,.=::::!t=., ` @EEEEEEtttz33QF
#    ;::::::::zt33)   "4EEEtttji3P*      Only need to break through one key point:
#   :t::::::::tt33.:Z3z..  `` ,..g.      The model file (.pdm .ldm .cdm file) of PowerDesigner pyramide
#   i:::WINDOWSt33F AEEEtttt::::ztF      is actually a standard XML data file.
#  ;:::::::::t33V ;EEEttttt::::t3        Didn't you expect it? :)
#  E::::::::zt33L @EEECHROMEOSz3F
# {3=*^```"*4E3) ;EEEtttt:::::tZ
#              ` :EEEEtttt::::z7         Yes,it is just a tiny code for fun.
#                  "VEzjt:;;z>*`         Use Python to realize the processing of PowerDesigner data model files
#
#                                        

# <a:ObjectID>267CD695-BA81-416F-9803-07119CED9D21</a:ObjectID> ObjectID a.k.a. "UUID"-expose-getter by list
# <o:Model Id="o2">    "Ref" getter ByPath
# f.write (atb.getAttribute("Id") +"\n") 
# If atb.getAttribute("Id") == "o17" :
# sed -i 's/MDL_PROP_SET/MODEL_PROPERTY_SET/g' LDMHandler.py
               
class LDMHandler(object):

  MODEL_PROPERTY_SET            = ["ObjectID","Version", "Name","Code",  "Annotation", "RepositoryFilename", "CreationDate","Creator","ModificationDate","Modifier", "Description", "Comments"]
  ENTITY_PROPERTY_SET           = ["ObjectID","Name","Code","CreationDate","Creator","ModificationDate","Modifier","Description"  ]
  ATTRIBUTE_PROPERTY_SET        = ["ObjectID","Name","Code","CreationDate","Creator","ModificationDate","Modifier", "DataType", "Length","Description" ]
  INDEX_PROPERTY_SET            = ["ObjectID","Name","Code","CreationDate","Creator","ModificationDate","Modifier"]
  IDXATTRIBUTE_PROPERTY_SET     = ["ObjectID","CreationDate","Creator","ModificationDate","Modifier"]
  RELATIONSHIP_PROPERTY_SET     = ["ObjectID", "Name", "Code", "CreationDate", "Creator", "ModificationDate", "Modifier", "Entity2ToEntity1Role", "Entity1ToEntity2Role", "Entity1ToEntity2RoleCardinality", "Entity2ToEntity1RoleCardinality"  ]
  RELENTITY_PROPERTY_SET        = ["ObjectID","Name","Code","ModificationDate" ]
  DOMAIN_PROPERTY_SET           = ["ObjectID","Name","Code","ModificationDate" ]
  SHORTCUT_PROPERTY_SET         = ["ObjectID","Name","Code" , "TargetID", "ModificationDate"]

  def __init__(self):
    return

  @staticmethod
  def parse(ldmfilename):
    return xml.dom.minidom.parse(ldmfilename)

  @staticmethod
  def __get_nodes_by_path(parent,xml_path):
    curr_node = parent
    for tag in xml_path.split("/")[0:-1] :
      tag_desc = tag.split("|")
      tag_name,tag_index = tag_desc[0], ( int(tag_desc[1]) if len(tag_desc) == 2 else 0 )
      child_nodes = []
      for child_node in curr_node.childNodes :
        if child_node.nodeName == tag_name :
          child_nodes.append(child_node)
      if len(child_nodes) < tag_index + 1 :
        return []
      curr_node = child_nodes[tag_index]
    # -- Speciale behandeling van pad op het laatste niveau -- #
    tag = xml_path.split("/")[-1]
    tag_desc = tag.split("|")
    tag_name,tag_index = tag_desc[0], ( int(tag_desc[1]) if len(tag_desc) == 2 else None )
    child_nodes = []
    for child_node in curr_node.childNodes :
      if child_node.nodeName == tag_name :
        child_nodes.append(child_node)
    if tag_index == None :
      return child_nodes
    elif len(child_nodes) < tag_index + 1 :
      return []
    else :
      curr_node = child_nodes[tag_index]
      return curr_node

  @staticmethod
  def __get_props_by_list(parent,attr_list):
    ret_dict = {}
    for attr in attr_list :
      ret_dict[attr] = ""
      for child in parent.childNodes :
        if child.nodeName == "a:" + attr :
          ret_dict[attr] = child.childNodes[0].data
          break
    return ret_dict

############################################################
#  o__         __o        ,__o        __o           __o
#  ,>/_       -\<,      _-\_<,       _`\<,_       _ \<_
# (*)`(*).....O/ O.....(*)/'(*).....(*)/ (*).....(_)/(_)

  @staticmethod
  def getmdlProps(mdlnode):
    return LDMHandler.__get_props_by_list(mdlnode, LDMHandler.MODEL_PROPERTY_SET)

  @staticmethod
  def getEntProps(entnode):
    return LDMHandler.__get_props_by_list(entnode, LDMHandler.ENTITY_PROPERTY_SET)

  @staticmethod
  def getAtbProps(atbnode):
    return LDMHandler.__get_props_by_list(atbnode, LDMHandler.ATTRIBUTE_PROPERTY_SET)

  @staticmethod
  def getIdxProps(idxnode):
    return LDMHandler.__get_props_by_list(idxnode, LDMHandler.INDEX_PROPERTY_SET)

  @staticmethod
  def getRelProps(relnode):
    return LDMHandler.__get_props_by_list(relnode, LDMHandler.RELATIONSHIP_PROPERTY_SET)

  @staticmethod
  def getDomainProps(domainnode):
    return LDMHandler.__get_props_by_list(domainnode, LDMHandler.DOMAIN_PROPERTY_SET)

  @staticmethod
  def getShortcutProps(shortcutnode):
    return LDMHandler.__get_props_by_list(shortcutnode, LDMHandler.SHORTCUT_PROPERTY_SET) 

############################################################
#  o__         __o        ,__o        __o           __o
#  ,>/_       -\<,      _-\_<,       _`\<,_       _ \<_
# (*)`(*).....O/ O.....(*)/'(*).....(*)/ (*).....(_)/(_)
############################################################
# All "packages, entity definitions, entity attributes definitions, indexes , reference definitions,
# etc." are all defined in the path of the .ldm file
# (represented by a file-like system path): /Model/o:RootObject/c:Children/o:Model

  @staticmethod
  def __get_mdlnodes_recursively(o_mdl):
    #-- Moet een o:Model/o:Pakket-knooppunt passeren --#
    if o_mdl.nodeName != "o:Model" and o_mdl.nodeName != "o:Package" :
      return []
    ret_list = []
    submdls = LDMHandler.__get_nodes_by_path(o_mdl,"c:Packages/o:Package")
    if submdls != None :
      for submdl in submdls :
        ret_list.append(submdl)
        ret_list = ret_list + LDMHandler.__get_mdlnodes_recursively(submdl)
    else :
      return []
    return ret_list

  @staticmethod
  def getmdlNodes(hpdm):
    ret_list = []
    try:
      o_mdl  = LDMHandler.__get_nodes_by_path(hpdm,"Model/o:RootObject/c:Children/o:Model")[0]
      ret_list.append(o_mdl)
    except IndexError:
      print ( "ERROR: geen geldig ldm-bestand!")
      return []
    ret_list = ret_list + LDMHandler.__get_mdlnodes_recursively(o_mdl)
    return ret_list

  @staticmethod
  def getEntNodesInmdl(mdlnode):
    return LDMHandler.__get_nodes_by_path(mdlnode, "c:Entities/o:Entity")

  @staticmethod
  def getAtbNodesInEnt(atbnode):
    return LDMHandler.__get_nodes_by_path(atbnode, "c:Attributes/o:EntityAttribute")

  @staticmethod
  def getIdxNodesInEnt(idxnode):
    return LDMHandler.__get_nodes_by_path(idxnode, "c:Identifiers/o:Identifier")

  @staticmethod
  def getIdxColNodesInIdx(idxcolnode):
    return LDMHandler.__get_nodes_by_path(idxcolnode,"c:IndexColumns/o:IndexColumn")

  @staticmethod
  def getRelNodesInmdl(relnode):
   return LDMHandler.__get_nodes_by_path(relnode, "c:Relationships/o:Relationship")

  @staticmethod
  def getRelEnt1Props(relentnode):
    ret_dict = LDMHandler.__get_props_by_list(relentnode, LDMHandler.RELENTITY_PROPERTY_SET)
    refent = LDMHandler.__get_nodes_by_path(relentnode, "c:Object1/o:Entity")
    try:
      refentid = refent[0].getAttribute("Ref")
    except IndexError:
      ret_dict["RefatbCode"] = ""
      return ret_dict
    ret_dict["RefEntID"] = refentid
    return ret_dict

  @staticmethod
  def getRelEnt2Props(relentnode):
    ret_dict = LDMHandler.__get_props_by_list(relentnode, LDMHandler.RELENTITY_PROPERTY_SET)
    refent = LDMHandler.__get_nodes_by_path(relentnode, "c:Object2/o:Entity")
    try:
      refentid = refent[0].getAttribute("Ref")
    except IndexError:
      ret_dict["RefatbCode"] = ""
      return ret_dict
    ret_dict["RefEntID"] = refentid
    return ret_dict

  @staticmethod
  def getNodePath(node) :
    curr = node
    path_nodes = []
    while(1):
      if curr != None and curr.nodeName != "#document" :
        path_nodes.append(curr.tagName)
      else :
        break
      curr = curr.parentNode 
    path_nodes.reverse()
    path = "".join([ slash + node for slash in '/' for node in path_nodes ])
    return path

  # GVG 3606 20220808
  @staticmethod
  def getDomainNodesInmdl(mdlnode):
    return LDMHandler.__get_nodes_by_path(mdlnode, "c:Domains/o:Domain") 

  @staticmethod
  def getShortcutNodesInmdl(mdlnode):
    return LDMHandler.__get_nodes_by_path(mdlnode, "c:Domains/o:Shortcut") 


  @staticmethod
  def getAtbDomainShortcutProps(atbnode):
    ret_dict = LDMHandler.__get_props_by_list(atbnode, LDMHandler.ATTRIBUTE_PROPERTY_SET)
    refent = LDMHandler.__get_nodes_by_path(atbnode, "c:Domain/o:Shortcut")
    try:
      refentid = refent[0].getAttribute("Ref")
    except IndexError:
      ret_dict["RefEntID"] = ""
      return ret_dict
    ret_dict["RefEntID"] = refentid
    return ret_dict
  
  @staticmethod
  def getAtbDomainProps(atbnode):
    ret_dict = LDMHandler.__get_props_by_list(atbnode, LDMHandler.DOMAIN_PROPERTY_SET)
    refent = LDMHandler.__get_nodes_by_path(atbnode, "c:Domain/o:Domain")
    try:
      refentid = refent[0].getAttribute("Ref")
    except IndexError:
      ret_dict["RefEntID"] = ""
      return ret_dict
    ret_dict["RefEntID"] = refentid
    return ret_dict


# hope the run will be okay!.
# hopefully more features will be added in it, and it will be useful to solve some headachy problem. Just like :
# compare the online database instance with LDM file.
# autogen SQL schema from PDM file (PowerDesigner's auto-gen setting sucks)
# autogen ORM from LDM file (seems awesome?!,support embed c,SQLAlchemy..)
#
##########################################
#
#  / First Law of Bicycling:            \
#  |                                    |
#  | No matter which way you ride, it's |
#  \ uphill and against the wind.       /
#   ------------------------------------
#          \   ^__^
#           \  (oo)\_______
#              (__)\       )\/\
#                  ||----w |
#                  ||     ||
#
###########################################
