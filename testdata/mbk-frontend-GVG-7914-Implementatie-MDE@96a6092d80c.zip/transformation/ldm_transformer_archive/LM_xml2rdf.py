# ! /usr/bin/python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar 21 10:39:56 2022

@author: Peter Bosch
"""
import os
import re
import uuid
from datetime import datetime
from timeit import default_timer as timer

from rdflib import Graph, URIRef, Literal
# Turtle libs
from rdflib.namespace import Namespace, RDF, RDFS, XSD, DCTERMS, SKOS


# create uri
# Elke canonieke URI heeft de volgende opbouw, conform RFC4122:
# convert .ldm to .ttl


def lm_turtlemania(file_dir, file, file_name):
    start_timer_lm_xml2rdf = timer()
    # datetime object containing current date and time
    now = datetime.now()
    dt_string = now.strftime("%d/%m/%Y %H:%M:%S")

    from LDMHandler import LDMHandler
    print("jeuh" + file_dir)
    lm = LDMHandler.parse(file_dir + os.sep + file)
    g = Graph()

    # here we go
    #############################################################
    #  o__         __o        ,__o        __o           __o
    #  ,>/_       -\<,      _-\_<,       _`\<,_       _ \<_
    # (*)`(*).....O/ O.....(*)/'(*).....(*)/ (*).....(_)/(_)
    # https://confluence.belastingdienst.nl/display/GVG/Identificatie+van+een+modelelementß
    uri = lm_fileuri(file_dir, file, file_name)
    # GRAPH <urn:uuid:97afbbc6-05ff-5d00-8227-5d600d7f385f>
    modelURI = (URIRef(uri))
    method_prefix(modelURI, lm, g)
    method_model(modelURI, lm, g)
    method_semver(modelURI, lm, g)

    ##method_entities_console(modelURI ,lm, g)
    method_entities(modelURI, lm, g)

    ##method_attribute_console  (modelURI ,lm, g)
    method_attributes(modelURI, lm, g)

    ##method_relationships_console(modelURI ,lm, g)
    method_relationships(modelURI ,lm, g)

    ##method_domains_console(modelURI, lm, g)
    method_domains(modelURI ,lm, g)

    ##method_shortcuts_console(modelURI ,lm, g)
    method_shortcuts(modelURI ,lm, g)

    # finally serialize the graph into  the turtle file when done.
    file_name_turtle = file_name + ".ttl"
    g.serialize(destination=file_dir + file_name_turtle)

    # go hybrid..
    #file_name_turtle = file_name + ".ttl"
    #f = open(file_dir+file_name_turtle, "w")
    # f.write("#Filename = Hope the run will be okay . \n")
    f = open(file_dir+file_name_turtle, "a")
    f.write("#Filename = Hope the run will be okay! . \n")

    # dze end hope the run will be okay.
    #  o__         __o        ,__o        __o           __o
    #  ,>/_       -\<,      _-\_<,       _`\<,_       _ \<_
    # (*)`(*).....O/ O.....(*)/'(*).....(*)/ (*).....(_)/(_)
    #############################################################
    # close the file when done.
    f.close()

    end_timer_lm_xml2rdf = timer()
    elapsed_time = round((end_timer_lm_xml2rdf - start_timer_lm_xml2rdf), 2)
    print(">>>Measure of the Elapsed Time LM_xml2rdf = " +
          str(elapsed_time) + " seconds<<<")
    
    return file_name_turtle
#######################################################################
# Functions below that are called
# Structured programming:
# Entire program logic 'modularized' in functions.
# create fileuri GRAPH <urn:uuid:97afbbc6-05ff-5d00-8227-5d600d7f385f>
#######################################################################
             
def uri(name):
    uuidstr = uuid.uuid5(uuid.NAMESPACE_URL, name)
    return URIRef(f'urn:uuid:{uuidstr}')


def lm_fileuri(file_dir, file, file_name):

    from LDMHandler import LDMHandler
    lm = LDMHandler.parse(file_dir + os.sep + file)
    for mdl in LDMHandler.getmdlNodes(lm):
        mdl_Props = LDMHandler.getmdlProps(mdl)
        print("ModelObjectID: ", mdl_Props["ObjectID"])
        # naam_model = mdl_Props["Code"]
        # print(f'Code: {naam_model}')
        pattern = r'(\d+(?:\.\d+){2})'
        versie_num_model = re.findall(pattern, mdl_Props["Version"])
        versie_num_model = versie_num_model[0]
        # print(f'Version: {versie_num_model}')
        model_file_name = mdl_Props["ObjectID"] + versie_num_model
        # print(f'derived_model_file_name : {model_file_name}')

        hash_uuid = uuid.uuid5(uuid.NAMESPACE_URL, str(model_file_name))
        uri = f'urn:uuid:{hash_uuid}'
        print(f'Named_graph/URI: {uri}')

        return uri


def method_prefix(modelURI, lm, g):
    #############################################################

    # Custom namespaces
    NS_MB = Namespace("http://modellenbibliotheek.belastingdienst.nl/def/mb#")
    NS_LGD = Namespace(
        "http://modellenbibliotheek.belastingdienst.nl/def/lgd#")  # 210
    NS_KGR = Namespace(
        "http://modellenbibliotheek.belastingdienst.nl/def/kgr#")

    # add custom namespaces
    g.bind("mb", NS_MB)
    g.bind("lgd", NS_LGD)
    g.bind("kgr", NS_KGR)
    g.bind("skos", SKOS)
    g.bind("rdfs", RDFS)
    g.bind("dcterms", DCTERMS)


def method_model(modelURI, lm, g):
    from LDMHandler import LDMHandler
    for mdl in LDMHandler.getmdlNodes(lm):
        mdl_Props = LDMHandler.getmdlProps(mdl)

        naam_model = mdl_Props["Name"]
        print(f'Code: {naam_model}')

        objectid_model = mdl_Props["ObjectID"]
        print(f'objectid_model: {objectid_model}')
        naam_kb = "lOC"
        resDefinitie = re.findall(r'\[.*?\]', mdl_Props["Annotation"])
        print(resDefinitie)
        for x in resDefinitie:
            res = str(x)[1:-1]
            if ("naam_kb=" in res):
                naam_kb = res.replace("naam_kb=", '')
                print(naam_kb)
                # if ("versie_datum_model=" in res):
                #    versie_datum_model = res.replace("versie_datum_model=", '')
                #    print(versie_datum_model)

        # Custom namespaces
        NS_MB = Namespace(
            "http://modellenbibliotheek.belastingdienst.nl/def/mb#")
        NS_LGD = Namespace(
            "http://modellenbibliotheek.belastingdienst.nl/def/lgd#")  # 210
        NS_KGR = Namespace(
            "http://modellenbibliotheek.belastingdienst.nl/def/kgr#")
        # g.add((modelURI, RDF.type, SKOS.ConceptScheme))
        g.add((modelURI, RDF.type, NS_LGD.LogischGegevensdefinitieModel))
        g.add((modelURI, RDF.type, NS_MB.Model))
        g.add((modelURI, NS_KGR.kennisgebied, URIRef(
            "http://modellenbibliotheek.belastingdienst.nl/id/kennisgebied/"+naam_kb)))
                  
        logisch_model = "Logisch model " + Literal(naam_model)
        g.add((modelURI, RDFS.label, Literal(logisch_model)))


def method_semver(modelURI, lm, g):
    from LDMHandler import LDMHandler
    for mdl in LDMHandler.getmdlNodes(lm):
        mdl_Props = LDMHandler.getmdlProps(mdl)

        naam_model = mdl_Props["Name"]
        logisch_model = "Logisch model " + Literal(naam_model)

        pattern = r'(\d+(?:\.\d+){2})'
        versie_num_model = re.findall(pattern, mdl_Props["Version"])
        versie_num_model = versie_num_model[0]
        print(f'Version: {versie_num_model}')

        # versie_datum_model = mdl_Props["ModificationDate"] # 680196758 = 2023-03-30 19:19:18
        versie_datum_model = datetime.fromtimestamp(
            int(mdl_Props["ModificationDate"]))
        print("MdlModificationDate: ", mdl_Props["ModificationDate"], "=",  datetime.fromtimestamp(
            int(mdl_Props["ModificationDate"])))

        # modelversie
        # add triples to the rdf graph
        LMPREFIX = URIRef("http://modellenbibliotheek.belastingdienst.nl/lm/")
        NS_MB = Namespace(
            "http://modellenbibliotheek.belastingdienst.nl/def/mb#")

        #modelversieURI = (URIRef(LMPREFIX + versie_num_model))
        #g.add((modelversieURI, RDF.type, NS_MB.Modelversie))
        #g.add((modelversieURI, NS_MB["versieVan"], modelURI))
        #g.add((modelversieURI, NS_MB["versiedatum"], Literal(
        #    versie_datum_model, datatype=XSD.date)))
        #g.add((modelversieURI, NS_MB["versienummer"],
        #       Literal(versie_num_model)))
        #g.add((modelversieURI, RDFS.label, Literal(
        #    logisch_model) + " "+versie_num_model))
        #modelversieURI = (
        #    URIRef(LMPREFIX + kennisgebied + "/" + versie_num_model))
        
        modelversieURI = (URIRef(LMPREFIX + versie_num_model))
        g.add((modelversieURI, RDF.type, NS_MB.Modelversie))
        g.add((modelversieURI, NS_MB.versieVan, modelURI))
        g.add((modelversieURI, NS_MB.versiedatum, Literal(
            versie_datum_model, datatype=XSD.date)))
        g.add((modelversieURI, NS_MB.versienummer, Literal(versie_num_model)))
        g.add((modelversieURI, RDFS.label, Literal(
            logisch_model) + " "+versie_num_model))
        g.add((modelversieURI, NS_MB.status, NS_MB.Finaal))
        
        


def method_entities_console(modelURI, lm, g):
    from LDMHandler import LDMHandler
    for mdl in LDMHandler.getmdlNodes(lm):
        mdl_Props = LDMHandler.getmdlProps(mdl)
        for ent in LDMHandler.getEntNodesInmdl(mdl):
            ent_Props = LDMHandler.getEntProps(ent)
            print(" Entity:",  ent_Props["Name"])


def method_entities(modelURI, lm, g):
    # entity_name :Natuurlijk persoon
    #    attribute_name :bsn
    #    attribute_name :geboortedatum
    # 👇 🐢
    # <urn:uuid:eef8a4b4-1234-555f-beef-721fe1cd5a90> a lgd:Entiteittype ;
    #     rdfs:label "Natuurlijk persoon" ;
    #     lgd:attribuut <urn:uuid:7b3e2cdd-d3e2-5c97-a18f-760418b8cb8c>,
    #         <urn:uuid:c51c9a21-2674-5e3e-abb5-246a9a302a9a> ;
    #     rdfs:isDefinedBy <urn:uuid:97afbbc6-05ff-5d00-8227-5d600d7f385f> .

    # <urn:uuid:02C2BE16-FC6C-4BD7-A1AB-49C0E32AD44D> a ns4:Entiteittype;
    # ns4:attribuut <urn:uuid:0F34BC24-1EA7-4E7E-A2B3-64712E4150F9>;
    # ns4:attribuut <urn:uuid:33E3027D-C674-4A24-9494-5D2409C52B89>;
    # ns4:attribuut <urn:uuid:3A1B8384-A383-4730-A6B2-EB7903BDA1D2>;
    # ns4:attribuut <urn:uuid:45727573-769F-4629-81D8-ED5F58DEB18B>;
    # ns4:attribuut <urn:uuid:8B43B445-3A07-46B5-8190-114B67539EC3>;
    # ns4:attribuut <urn:uuid:91565AC5-AB3A-4DB4-A9CE-30221C23DCC1>;
    # rdfs:isDefinedBy <http://modellenbibliotheek.belastingdienst.nl/lgd/BAG/1.0.0>;
    # rdfs:label "verblijfsobject kenmerk in onderzoek"^^xsd:string

    from LDMHandler import LDMHandler
    for mdl in LDMHandler.getmdlNodes(lm):
        mdl_Props = LDMHandler.getmdlProps(mdl)
        for ent in LDMHandler.getEntNodesInmdl(mdl):
            ent_Props = LDMHandler.getEntProps(ent)
            entity_name = ent_Props["Name"]
            print(f'entity_name :{entity_name}')
            EntityObjectID = ent_Props["ObjectID"]
            NS_LGD = Namespace(
                "http://modellenbibliotheek.belastingdienst.nl/def/lgd#")
            subject = uri(f"{EntityObjectID}")
            g.add((subject, RDF.type, NS_LGD.Entiteittype))
            # <urn:uuid:87eac245-5d91-5238-9d0d-f1caefb878c8> a lgd:Entiteittype .

            for atb in LDMHandler.getAtbNodesInEnt(ent):
                atb_Props = LDMHandler.getAtbProps(atb)
                AttributeObjectID = atb_Props["ObjectID"]
                attribute_name = atb_Props["Name"]
                print(f'    attribute_name :{attribute_name}')
                g.add((subject, NS_LGD.attribuut, uri(f"{AttributeObjectID}")))
                # lgd:attribuut <urn:uuid:5f385aef-6fa1-53e7-80f5-2ac5033f6a37> .
            g.add((subject, RDFS.label, Literal(entity_name)))
            # rdfs:label "Natuurlijk persoon" ;
            # rdfs:isDefinedBy <urn:uuid:97afbbc6-05ff-5d00-8227-5d600d7f385f> .
            g.add((subject, RDFS.isDefinedBy, modelURI))


def method_attribute_console(modelURI, lm, g):
    from LDMHandler import LDMHandler
    for mdl in LDMHandler.getmdlNodes(lm):
        mdl_Props = LDMHandler.getmdlProps(mdl)
        for ent in LDMHandler.getEntNodesInmdl(mdl):
            ent_Props = LDMHandler.getEntProps(ent)
            # print(" Entity:", ent.getAttribute("Id"), ent_Props["ObjectID"], ent_Props["Name"], ent_Props["Code"],
            # print("###Entity:", ent.getAttribute("Id"), ent_Props["ObjectID"], ent_Props["Code"])
            for atb in LDMHandler.getAtbNodesInEnt(ent):
                atb_Props = LDMHandler.getAtbProps(atb)

                # De lineage tussen de LGD onderdelen en de begrippen
                # loopt via het "description" veld.
                # Uitdaging is dat dit veld gestructureerd is conform het RTF formaat:
                # handigste is mogelijk om een Python script te gebruiken dat dit RTF f
                # ormaat omzet in iets wat beter te verwerken is.
                # De lineage wordt nu gerealiseerd door tussen "<" en ">"
                # de begripsnaam te zetten (bv: "<woonplaats>").
                # Het resultaat hiervan komt terecht in de triple met property lgd:begripsnaam.

                from striprtf.striprtf import rtf_to_text

                text = rtf_to_text(atb_Props["Description"])
                text = text.replace('\n', "")
                print("Entity:", ent_Props["Name"],
                      " has Attribute:", atb_Props["Name"], text)

                atbdomain_Props = LDMHandler.getAtbDomainProps(atb)
                attribute_domain_refentid = atbdomain_Props["RefEntID"]
                #attribute_domain_refentid ="o89"
                if len(attribute_domain_refentid) > 0:
                    print(
                        f'  hello atb domain refentid, nice to see you ->  {attribute_domain_refentid}')

def method_attributes(modelURI, lm, g):
    from LDMHandler import LDMHandler
    for mdl in LDMHandler.getmdlNodes(lm):
        mdl_Props = LDMHandler.getmdlProps(mdl)
        for ent in LDMHandler.getEntNodesInmdl(mdl):
            ent_Props = LDMHandler.getEntProps(ent)
            print("[Entity:]",  ent_Props["Name"])
            for atb in LDMHandler.getAtbNodesInEnt(ent):
                atb_Props = LDMHandler.getAtbProps(atb)
                attributeObjectID = atb_Props["ObjectID"]
                attribute_name = atb_Props["Name"]

                # label
                NS_LGD = Namespace(
                    "http://modellenbibliotheek.belastingdienst.nl/def/lgd#")
                subject = uri(f"{attributeObjectID }")
                g.add((subject, RDF.type, NS_LGD.Attribuuttype))
                # <urn:uuid:00d765d2-e2d1-5e7d-9379-c3997a00b880> a lgd:Attribuuttype .
                g.add((subject, RDFS.label, Literal(attribute_name)))
                # rdfs:label "bsn" .

                # begripsnaam
                from striprtf.striprtf import rtf_to_text
                attribute_description = rtf_to_text(atb_Props["Description"])
                attribute_description = attribute_description.replace('\n', "")
                print("  Entity:", ent_Props["Name"],
                      " has Attribute:", atb_Props["Name"], attribute_description)
                if len(attribute_description) > 0:
                    g.add((subject, NS_LGD.begripsnaam,
                          Literal(attribute_description)))
                    # lgd:begripsnaam "het [bovenaanzicht] van een verblijfsobject is een 2-dimensionale [geometrie]" .

                # domain
                atbdomain_Props = LDMHandler.getAtbDomainProps(atb)
                attribute_domain_refentid = atbdomain_Props["RefEntID"]
                #attribute_domain_refentid ="o89"
                

                for domain in LDMHandler.getDomainNodesInmdl(mdl):
                    domain_Props = LDMHandler.getDomainProps(domain)
                    if domain.getAttribute("Id") == attribute_domain_refentid:
                        DomainObjectID = domain_Props["ObjectID"]
                        print( f'  hello atb domain refentid, nice to see you ->  {domain.getAttribute("Id")}')
                        g.add((subject, NS_LGD.attribuutdomein,
                              uri(f"{DomainObjectID }")))
                        # lgd:attribuutdomein <urn:uuid:22c5dafc-766e-54a6-ac03-d4a9dd3d99fc> ;
                 
                # shortcuts
                atbshortcut_Props = LDMHandler.getAtbDomainShortcutProps(atb)
                attribute_shortcut_refentid = atbshortcut_Props["RefEntID"]
                #print( f' hello atb shortcut refentid, nice to see you2 ->  {attribute_shortcut_refentid} ')
                for shortcut in LDMHandler.getShortcutNodesInmdl(mdl):
                    shortcut_Props = LDMHandler.getShortcutProps(shortcut)
                    if shortcut.getAttribute("Id") == attribute_shortcut_refentid:
                        ShortcutObjectID = shortcut_Props["ObjectID"]
                        print( f'  hello atb shortcut refentid, nice to see you ->  {shortcut.getAttribute("Id")}')
                        g.add((subject, NS_LGD.attribuutdomein,
                              uri(f"{ShortcutObjectID }")))
                        # lgd:attribuutdomein <urn:uuid:22c5dafc-766e-54a6-ac03-d4a9dd3d99fc> ; 


def method_relationships_console(modelURI, lm, g):
    from LDMHandler import LDMHandler
    for mdl in LDMHandler.getmdlNodes(lm):
        mdl_Props = LDMHandler.getmdlProps(mdl)
        for rel in LDMHandler.getRelNodesInmdl(mdl):
            rel_Props = LDMHandler.getRelProps(rel)
            print(" Relationship:", rel.getAttribute("Id"), rel_Props["Code"], rel_Props["ObjectID"], rel_Props["Name"],
                  rel_Props["Entity1ToEntity2Role"], rel_Props["Entity2ToEntity1Role"])


def method_relationships(modelURI, lm, g):
    from LDMHandler import LDMHandler
    for mdl in LDMHandler.getmdlNodes(lm):
        mdl_Props = LDMHandler.getmdlProps(mdl)
        for rel in LDMHandler.getRelNodesInmdl(mdl):
             rel_Props = LDMHandler.getRelProps(rel)
             RelationObjectID = rel_Props["ObjectID"]
             relationship_name = rel_Props["Name"]
             print(f'relationship_name :{relationship_name}')
             NS_LGD = Namespace(
                 "http://modellenbibliotheek.belastingdienst.nl/def/lgd#")
             subject = uri(f"{RelationObjectID}")
             g.add((subject, RDF.type, NS_LGD.Relatietype))
             # <urn:uuid:87eac245-5d91-5238-9d0d-f1caefb878c8> a lgd:Entiteittype  
             g.add((subject, RDFS.label, Literal(relationship_name)))
             #rdfs:label "natuurlijk persoon is getrouwd met" ;
             g.add((subject, RDFS.isDefinedBy, modelURI))
             #rdfs:isDefinedBy <urn:uuid:97afbbc6-05ff-5d00-8227-5d600d7f385f> .
             
             # naarCardinaliteit
             naarCardinaliteit =rel_Props["Entity1ToEntity2RoleCardinality"] # 0,n
             #print(naarCardinaliteit)
             #g.add((subject, NS_LGD.naarCardinaliteit , Literal(naarCardinaliteit))
             
             relent_Props1 = LDMHandler.getRelEnt1Props(rel)
             refentid1 = relent_Props1["RefEntID"]
             for ent in LDMHandler.getEntNodesInmdl(mdl):
                 ent_Props = LDMHandler.getEntProps(ent)
                 if ent.getAttribute("Id") == refentid1:
                     naarEntiteittype = ent_Props["ObjectID"]
                     g.add((subject, NS_LGD.naarEntiteittype , uri(f"{naarEntiteittype}") ))
             
             # vanCardinaliteit
             #vanCardinaliteit =  rel_attrs["Entity2ToEntity1RoleCardinality"] 
             #f.write("    ns4:vanCardinaliteit " + vanCardinaliteit + "^^xsd:string;\n")
             
             relent_Props2 = LDMHandler.getRelEnt2Props(rel)
             refentid2 = relent_Props2["RefEntID"]
             for ent in LDMHandler.getEntNodesInmdl(mdl):
                 ent_Props2 = LDMHandler.getEntProps(ent)
                 if ent.getAttribute("Id") == refentid2:
                    vanEntiteittype = ent_Props2["ObjectID"]
                    g.add((subject, NS_LGD.vanEntiteittype , uri(f"{vanEntiteittype}") ))

def method_domains_console(modelURI, lm, g):
    from LDMHandler import LDMHandler
    for mdl in LDMHandler.getmdlNodes(lm):
        mdl_Props = LDMHandler.getmdlProps(mdl)
        for domain in LDMHandler.getDomainNodesInmdl(mdl):
            domain_Props = LDMHandler.getDomainProps(domain)
            print(" Domain:", domain.getAttribute("Id"), domain_Props["ObjectID"], domain_Props["Name"],
                  domain_Props["Code"])

def method_domains(modelURI, lm, g):
    from LDMHandler import LDMHandler
    for mdl in LDMHandler.getmdlNodes(lm):
        mdl_Props = LDMHandler.getmdlProps(mdl)
        for domain in LDMHandler.getDomainNodesInmdl(mdl):
            domain_Props = LDMHandler.getDomainProps(domain)
            DomainObjectid = domain_Props["ObjectID"]
            domain_name =  domain_Props["Name"] 
            #print(f'domain_name :{domain_name}')
            NS_LGD = Namespace(
                "http://modellenbibliotheek.belastingdienst.nl/def/lgd#")
            subject = uri(f"{DomainObjectid}")
            g.add((subject, RDF.type, NS_LGD.Attribuutdomein))
            #<urn:uuid:3b2107be-30df-53b8-a7b3-81fdb4761336> a lgd:Attribuutdomein .
            g.add((subject, RDFS.label, Literal(domain_name)))
            #rdfs:label "eigen geometrie2D" ;
            g.add((subject, RDFS.isDefinedBy, modelURI))
            #rdfs:isDefinedBy <urn:uuid:97afbbc6-05ff-5d00-8227-5d600d7f385f> .
            
def method_shortcuts_console(modelURI, lm, g):
    from LDMHandler import LDMHandler
    for mdl in LDMHandler.getmdlNodes(lm):
        mdl_Props = LDMHandler.getmdlProps(mdl)
        for shortcut in LDMHandler.getShortcutNodesInmdl(mdl):
            shortcut_Props = LDMHandler.getShortcutProps(shortcut)
            print(" Shortcut:", shortcut.getAttribute("Id"), shortcut_Props["ObjectID"], shortcut_Props["Name"],
                  shortcut_Props["Code"])


def method_shortcuts(modelURI, lm, g):
    from LDMHandler import LDMHandler
    for mdl in LDMHandler.getmdlNodes(lm):
        mdl_Props = LDMHandler.getmdlProps(mdl)
        for shortcut in LDMHandler.getShortcutNodesInmdl(mdl):
            shortcut_Props = LDMHandler.getShortcutProps(shortcut)
            ShortcutDomainObjectid = shortcut_Props["ObjectID"]
            ShortcutDomainName = shortcut_Props["Name"]
            #print(f'domain_name :{ShortcutDomainName}')
            NS_LGD = Namespace(
                "http://modellenbibliotheek.belastingdienst.nl/def/lgd#")
            subject = uri(f"{ShortcutDomainObjectid}")
            g.add((subject, RDF.type, NS_LGD.Attribuutdomein))
            #<urn:uuid:3b2107be-30df-53b8-a7b3-81fdb4761336> a lgd:Attribuutdomein .
            g.add((subject, RDFS.label, Literal(ShortcutDomainName)))
            # rdfs:label "(DT) tijdvak - kalenderjaar" ;
            g.add((subject, RDFS.isDefinedBy, modelURI))
            #rdfs:isDefinedBy <urn:uuid:97afbbc6-05ff-5d00-8227-5d600d7f385f> .