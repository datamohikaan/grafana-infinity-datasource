import os
import re
import uuid
import xml.dom.minidom
from datetime import datetime
import shutil
import json
from rdflib import Graph, URIRef, Literal
from rdflib.namespace import RDF, RDFS, DCTERMS, SKOS, XSD
from striprtf.striprtf import rtf_to_text
import utils.constants as cn
import utils.utils_ldm_handler as ldm
from transformation.mde.pd_ldm_preprocessor import PowerDesignerLDMPreprocessor
from transformation.mde import xml_extractor, ldm2json
from utils.utils import create_uri


class LDMTransformer:
    def __init__(self, file_dir: str, file: str, file_name: str):
        self.file_dir = file_dir
        self.file_name = file_name
        self.file_path = file_dir + os.sep + file
        self.file_name_turtle = self.file_name + cn.TURTLE_EXTENSION
        self.yaml = None
        self.json = None
        self.input_xml = xml.dom.minidom.parse(self.file_path)
        self.g = Graph()
        self.versie_num_model = None
        self.model_uri = None
        self.naam_model = None
        self.logisch_model = None
        self.versie_datum_model = None
        self.naam_kb = None
        self.naam_kdgb = None
        self.code_kb = None
        self.code_kdgb = None

        # TODO: Beneden zijn de MDE variabelen - refactor de namen als de transformatie compleet is
        #MDE
        self.mde_model_uuid = None
        self.mde_model_code = None
        self.mde_model_name = None
        self.mde_repositoryfilename = None
        self.mde_modificationdate = None
        self.mde_versie_datum_model = None
        self.mde_model_version = None
        self.dom_mde_model_file_name = None

    def generate_json(self):
        """Generates the JSON file needed for the transformation to turtle. Code is obtained from the MDE.
        """
        MDE_ROOT_DIR = os.path.join(os.getcwd(), "transformation", "mde")
        #MDE_ROOT_DIR = os.path.join(os.getcwd().replace("\\frontend", ""), "transformation", "mde")
        # if MDE_ROOT_DIR == "/transformation/mde":  # in case ROOT running in the POD
        #     MDE_ROOT_DIR = "/deployment/transformation/mde"
        MDE_OUTPUT_DIR = os.path.join(self.file_dir, "output")

        if os.path.isdir(MDE_OUTPUT_DIR):
            shutil.rmtree(MDE_OUTPUT_DIR)

        # Recreate output directory
        os.mkdir(MDE_OUTPUT_DIR)

        # Run preprocessor
        preprocessor: PowerDesignerLDMPreprocessor = PowerDesignerLDMPreprocessor()
        preprocessor.preprocess_ldm(self.file_path)

        # Runs XML extractor
        xml_extractor.extract(self.file_path.replace(".ldm", "_preprocessed.ldm"),
                              os.path.join(MDE_ROOT_DIR, "mde_utils" + os.sep + "powerdesigner-extractor-config.yml"),
                              MDE_OUTPUT_DIR)

        # Run JSON convertor
        ldm2json.generate_json(source_path=MDE_OUTPUT_DIR, target_file=self.file_path.replace(".ldm", ".yml")) # target file wordt niet gebruikt bij json productie
        with open(f'{MDE_OUTPUT_DIR}/ldm.json', 'r') as json_file:
            self.json = json.load(json_file)

        print(self.json)  # TODO: Verwijder na refactoring

        # Saving yaml - wellicht voor de toekomst
        # with open(self.file_path.replace(".ldm", ".yml"), "r") as file:
        #     self.yaml = yaml.safe_load(file)

    def create_namespace_graph(self):
        """Creates the Namespace graph with the specified namespaces.
        :return: returns the created Namespace Graph.
        """
        # Obtaining MDE model information
        self.mde_model_uuid = self.json['model']['uuid']
        self.mde_model_code = self.json['model']['code']
        self.mde_model_name = self.json['model']['name']
        self.mde_model_version = self.json['model']['version']
        self.mde_repositoryfilename = self.json['model']['repositoryfilename']
        self.mde_modificationdate = self.json['model']['modificationdate']
        dt_object = datetime.fromtimestamp(int(self.mde_modificationdate))
        self.mde_versie_datum_model = str(dt_object.year) + "-" + str(dt_object.month) + "-" + str(dt_object.day)
        PROPERTY_PATTERN = r'(\d+(?:\.\d+){2})'
        self.mde_model_version = str(re.findall(PROPERTY_PATTERN, self.mde_model_version))
        self.mde_model_version = re.sub(r"[\([{})\]]", "", self.mde_model_version)
        self.mde_model_version = re.sub("'", "", self.mde_model_version)
        self.dom_mde_model_file_name = self.mde_model_uuid + self.mde_model_version

        # Adding custom namespaces
        naam_kb = self.mde_model_name.replace("LDM", "CIM")
        self.g.bind("mb", cn.NS_MB)
        self.g.bind("lgd", cn.NS_LGD)
        self.g.bind("kgr", cn.NS_KGR)
        self.g.bind("skos", SKOS)
        self.g.bind("rdfs", RDFS)
        self.g.bind("dcterms", DCTERMS)

        self.logisch_model = "Logisch model " + Literal(self.mde_model_name)
        hash_uuid = uuid.uuid5(uuid.NAMESPACE_URL, str(self.dom_mde_model_file_name))
        self.model_uri = URIRef(f'urn:uuid:{hash_uuid}')
        model_version_uri = (URIRef(cn.LM_PREFIX + self.mde_model_version))

        # Adding gathered DOM and MDE  model information to the graph
        self.g.add((self.model_uri, RDF.type, cn.NS_LGD.LogischGegevensdefinitieModel))
        self.g.add((self.model_uri, RDF.type, cn.NS_MB.Model))
        self.g.add((self.model_uri, cn.NS_KGR.kennisgebied, URIRef(("http://modellenbibliotheek.belastingdienst.nl/id/kennisgebied/" + naam_kb).replace(" ", "-"))))
        self.g.add((self.model_uri, RDFS.label, Literal(self.logisch_model)))
        self.g.add((model_version_uri, RDF.type, cn.NS_MB.Modelversie))
        self.g.add((model_version_uri, cn.NS_MB.versieVan, self.model_uri))
        self.g.add((model_version_uri, cn.NS_MB.versiedatum, Literal(self.mde_versie_datum_model, datatype=XSD.date)))
        self.g.add((model_version_uri, cn.NS_MB.versienummer, Literal(self.mde_model_version)))
        self.g.add((model_version_uri, RDFS.label, Literal(self.logisch_model)))
        self.g.add((model_version_uri, cn.NS_MB.status, cn.NS_MB.Finaal))
        self.g.add((model_version_uri, cn.NS_MB.naam, Literal(self.mde_model_name + "-" + self.mde_model_version)))
        self.g.add((model_version_uri, cn.NS_MB.titel, Literal(self.mde_model_name + "-" + self.mde_model_version)))

    def process_entities(self):
        """Processes the entity properties and adds it to the NameSpace graph"""
        for entity in self.json['model']['entities']:
            clean_entity_description = rtf_to_text(entity["description"]).strip()
            subject = create_uri(str(entity["uuid"]))
            self.g.add((subject, RDFS.isDefinedBy, self.model_uri))
            self.g.add((subject, RDF.type, cn.NS_LGD.Entiteittype))
            self.g.add((subject, RDFS.label, Literal(entity["name"])))
            self.g.add((subject, cn.NS_LGD.gegevensdefinitie, Literal(clean_entity_description)))
            for attribute in entity["attributes"]:
                if attribute["inheritedfrom"] == '-':
                    self.g.add((subject, cn.NS_LGD.attribuut, create_uri(str(attribute["uuid"]))))

    def process_attributes(self):
        """Processes the attribute properties and adds it to the graph"""
        for model in ldm.get_model_nodes(self.input_xml):
            for entity in ldm.get_entity_nodes_in_model(model):

                for attribute in ldm.get_attribute_nodes_in_entities(entity):
                    attribute_properties = ldm.get_attribute_properties(attribute)
                    subject = create_uri(f"{attribute_properties[cn.OBJECT_ID]}")
                    self.g.add((subject, RDF.type, cn.NS_LGD.Attribuuttype))
                    self.g.add((subject, RDFS.label, Literal(attribute_properties[cn.NAME])))
                    attribute_description = rtf_to_text(attribute_properties[cn.DESCRIPTION])
                    attribute_description = attribute_description.replace('\n', "")
                    if len(attribute_description) > 0:
                        self.g.add((subject, cn.NS_LGD.begripsnaam, Literal(attribute_description)))

                    # Domain
                    attribute_domain_properties = ldm.get_attribute_domain_properties(attribute)
                    for domain in ldm.get_domain_nodes_in_model(model):
                        domain_properties = ldm.get_domain_properties(domain)
                        if domain.getAttribute(cn.ID) == attribute_domain_properties[cn.REF_ENT_ID]:
                            self.g.add(
                                (subject, cn.NS_LGD.attribuutdomein, create_uri(f"{domain_properties[cn.OBJECT_ID]}")))

                    # Shortcuts
                    attribute_shortcut_properties = ldm.get_attribute_domain_shortcut_properties(attribute)
                    for shortcut in ldm.get_shortcut_nodes_in_model(model):
                        shortcut_properties = ldm.get_shortcut_properties(shortcut)
                        if shortcut.getAttribute(cn.ID) == attribute_shortcut_properties[cn.REF_ENT_ID]:
                            self.g.add((subject, cn.NS_LGD.attribuutdomein,
                                        create_uri(f"{shortcut_properties[cn.OBJECT_ID]}")))

    def process_relations(self):
        """Processes the relation properties and adds it to the graph"""
        for model in ldm.get_model_nodes(self.input_xml):
            for relation in ldm.get_relation_nodes_in_model(model):
                relation_properties = ldm.get_relation_properties(relation)
                subject = create_uri(f"{relation_properties[cn.OBJECT_ID]}")
                self.g.add((subject, RDF.type, cn.NS_LGD.Relatietype))
                self.g.add((subject, RDFS.label, Literal(relation_properties[cn.NAME])))
                self.g.add((subject, RDFS.isDefinedBy, self.model_uri))
                self.g.add((subject, cn.NS_LGD.naarRolnaam,
                            Literal(relation_properties[cn.ENTITY1TOENTITY2ROLE])
                            ))
                self.g.add((subject, cn.NS_LGD.vanrRolnaam,
                            Literal(relation_properties[cn.ENTITY2TOENTITY1ROLE])
                            ))
                self.g.add((subject, cn.NS_LGD.naarCardinaliteit,
                            Literal(relation_properties[cn.ENTITY2TOENTITY1ROLECARDINALITY])
                            ))
                self.g.add((subject, cn.NS_LGD.vanCardinaliteit,
                            Literal(relation_properties[cn.ENTITY1TOENTITY2ROLECARDINALITY])
                            ))

                relation_entity_properties_1 = ldm.get_relation_entity_1_properties(relation)
                for entity in ldm.get_entity_nodes_in_model(model):
                    entity_properties = ldm.get_entity_properties(entity)
                    if entity.getAttribute(cn.ID) == relation_entity_properties_1[cn.REF_ENT_ID]:
                        self.g.add(
                            (subject, cn.NS_LGD.naarEntiteittype, create_uri(f"{entity_properties[cn.OBJECT_ID]}")))

                relation_entity_properties_2 = ldm.get_relation_entity_2_properties(relation)
                for entity in ldm.get_entity_nodes_in_model(model):
                    entity_properties = ldm.get_entity_properties(entity)
                    if entity.getAttribute(cn.ID) == relation_entity_properties_2[cn.REF_ENT_ID]:
                        self.g.add(
                            (subject, cn.NS_LGD.vanEntiteittype, create_uri(f"{entity_properties[cn.OBJECT_ID]}")))

    def process_domains(self):
        """Processes the domain properties and adds it to the graph"""
        for model in ldm.get_model_nodes(self.input_xml):
            for domain in ldm.get_domain_nodes_in_model(model):
                domain_properties = ldm.get_domain_properties(domain)
                subject = create_uri(f"{domain_properties[cn.OBJECT_ID]}")
                self.g.add((subject, RDF.type, cn.NS_LGD.Attribuutdomein))
                self.g.add((subject, RDFS.label, Literal(domain_properties[cn.NAME])))
                self.g.add((subject, RDFS.isDefinedBy, self.model_uri))

    def process_shortcuts(self):
        """Processes the shortcut properties and adds it to the graph"""
        for model in ldm.get_model_nodes(self.input_xml):
            for shortcut in ldm.get_shortcut_nodes_in_model(model):
                shortcut_properties = ldm.get_shortcut_properties(shortcut)
                subject = create_uri(f"{shortcut_properties[cn.OBJECT_ID]}")
                self.g.add((subject, RDF.type, cn.NS_LGD.Attribuutdomein))
                self.g.add((subject, RDFS.label, Literal(shortcut_properties[cn.NAME])))
                self.g.add((subject, RDFS.isDefinedBy, self.model_uri))

    def get_model_uri(self):
        """Returns the model uri"""
        return self.model_uri

    def get_file_name_turtle(self):
        """Returns the name of the turtle file"""
        return self.file_name_turtle

    def get_yml_data(self):
        """Returns the generated yaml file"""
        return self.yaml

    def get_vda_model_name(self):
        return f"CIM {self.code_kb} {self.naam_kdgb}" if self.code_kdgb is not None else f"CIM {self.naam_kb}"

    def transform_ldm_xml_to_rdf(self):
        """Main function that processes the LDM input file and transforms it into the Turtle file"""
        from timeit import default_timer as timer
        start_mde_runner = timer()
        self.generate_json()
        self.create_namespace_graph()
        self.process_entities()
        self.process_attributes()
        self.process_relations()
        self.process_domains()
        self.process_shortcuts()
        self.g.serialize(destination=self.file_dir + self.file_name_turtle)
        end_mde_runner = timer()
        elapsed_time = round((end_mde_runner - start_mde_runner), 2)
        print(">>>Measure of the Elapsed Time from mde_runner = " + str(elapsed_time) + " seconds<<<")
