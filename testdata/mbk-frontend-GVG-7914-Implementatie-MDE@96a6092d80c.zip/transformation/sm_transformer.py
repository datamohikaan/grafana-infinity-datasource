from utils.utils import read_sheet_as_dataframe, create_uri, get_column_index, capitalize_df, lookup_kb_uri, lookup_begrip_uri, find_uri_in_graph, get_datastore_endpoint
from datetime import datetime
import uuid
import re
from rdflib import Graph, URIRef, Literal
import pandas as pd
import utils.constants as cn
from frontend.ep.config import DATASTORE_ENDPOINT
from rdflib.namespace import RDF, RDFS, XSD, DCTERMS, SKOS


class SMTransformer:
    def __init__(self, file_dir: str, file_name: str, input_xlsx):
        self.file_dir = file_dir
        self.file_name = file_name
        self.file_name_turtle = self.file_name + cn.TURTLE_EXTENSION
        self.input_xlsx = input_xlsx
        self.g = Graph()
        self.naam_model = None
        self.titel_model = None
        self.naam_kb = None
        self.code_kb = None
        self.naam_kdgb = None
        self.code_kdgb = None
        self.versie_num_model = None
        self.versie_num_model_without_snapshot = None
        self.versie_datum_model = None
        self.taal_model = None
        self.taal_model_lower = None
        self.sec_taal_model = None
        self.sec_taal_model_lower = None
        self.uri = None
        self.modelURI = None

    def transform_sm_xml_to_rdf(self):
        """Main function that needs to be called in order to transform XML to turtle.
        :return: the file name of the created turtle file.
        """
        self.process_algemeen()
        self.set_uri()
        self.create_namespace_graph()
        self.process_kennisbronnen()
        self.process_begrippen()
        if cn.TERMVORMEN in self.input_xlsx.sheet_names:
            self.process_termvormen()
        self.g.serialize(destination=self.file_dir + self.file_name_turtle)

    def set_uri(self):
        """Setting the graph URI"""
        model_file_name = "KG_" + self.naam_kb + "_-_" + self.naam_model + \
                          "_-_" + "v" + str(self.versie_num_model_without_snapshot) + "_-_" + \
                          self.versie_datum_model
        hash_uuid = uuid.uuid5(uuid.NAMESPACE_URL, str(model_file_name))
        self.uri = f'urn:uuid:{hash_uuid}'

    def get_uri(self):
        """Returning the graph URI"""
        return self.uri

    def get_file_name_turtle(self):
        """Returning the name of the turtle file"""
        return self.file_name_turtle

    def get_vda_model_name(self):
        return f"SBM {self.code_kb} {self.naam_kdgb}" if self.code_kdgb is not None else f"SBM {self.naam_kb}"

    def create_namespace_graph(self):
        """Creates the Namespace graph with the specified namespaces.
        :return: returns the created Namespace Graph.
        """
        # Creating and adding custom namespaces
        self.g.bind("mb", cn.NS_MB)
        self.g.bind("kgr", cn.NS_KGR)
        self.g.bind("skos", SKOS)
        self.g.bind("skosxl", cn.NS_SKOSXL)
        self.g.bind("rdfs", RDFS)
        self.g.bind("dcterms", DCTERMS)
        self.g.bind("sm", cn.NS_SM)

        # Defining names
        self.modelURI = create_uri(f"{self.code_kb}/{self.naam_kdgb}")
        modelversieURI = URIRef(self.uri)
        registratie_moment = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")

        # Look up
        lookup_code_kb = '"{}"'.format(self.code_kb)  # EXM
        kennisgebiedURI = lookup_kb_uri(DATASTORE_ENDPOINT, lookup_code_kb, is_kg=True)
        lookup_code_kdgb = '"{}"'.format(self.code_kdgb)  # EXM
        kennisdeelgebiedURI = lookup_kb_uri(DATASTORE_ENDPOINT, lookup_code_kdgb, is_kg=False)

        self.g.add((self.modelURI, RDF.type, SKOS.ConceptScheme))
        self.g.add((self.modelURI, RDF.type, cn.NS_MB.Model))
        self.g.add((self.modelURI, cn.NS_MB.naam, Literal(self.naam_model)))
        self.g.add((self.modelURI, RDFS.label, Literal(self.titel_model)))
        self.g.add((self.modelURI, DCTERMS.title, Literal(self.titel_model)))
        self.g.add((self.modelURI, cn.NS_KGR.kennisgebied, URIRef(kennisgebiedURI)))
        self.g.add((modelversieURI, RDF.type, cn.NS_MB.Modelversie))
        self.g.add((modelversieURI, cn.NS_MB.versieVan, self.modelURI))
        self.g.add((modelversieURI, cn.NS_MB.versiedatum, Literal(self.versie_datum_model, datatype=XSD.date)))
        self.g.add((modelversieURI, cn.NS_MB.versienummer, Literal(self.versie_num_model)))
        self.g.add((modelversieURI, RDFS.label, Literal(self.naam_model) + " " + self.versie_num_model_without_snapshot))
        self.g.add((modelversieURI, DCTERMS.title, Literal(self.naam_model) + " " + self.versie_num_model_without_snapshot))
        self.g.add((modelversieURI, cn.NS_MB.status, cn.NS_MB.Finaal))
        self.g.add((modelversieURI, cn.NS_MB.registratiemoment, Literal(registratie_moment, datatype=XSD.dateTime)))
        if pd.notna(kennisdeelgebiedURI):
            self.g.add((self.modelURI, cn.NS_KGR.kennisdeelgebied, URIRef(kennisdeelgebiedURI)))

    def process_algemeen(self):
        """Function that handles the sheet "Algemeen"""
        def handle_naam_model(naam_model: str):
            naam_model_splitted = naam_model.split("-")
            if naam_model_splitted[0] == cn.SM:
                if len(naam_model_splitted) == 2:
                    return naam_model_splitted[1]
                elif (len(naam_model_splitted) > 2) & (naam_model_splitted[1] != self.code_kb):
                    return naam_model
                else:
                    return ' '.join(naam_model_splitted[2:])
            else:
                return naam_model

        df = read_sheet_as_dataframe(
            xls_file=self.input_xlsx,
            sheet_name=cn.ALGEMEEN,
            index_column=0,
            rename_columns=True,
            column_mapping=cn.ALGEMEEN_COLUMN_MAPPING,
            rename_index=True,
            index_mapping=cn.ALGEMEEN_FIELD_MAPPING
        )
        df = capitalize_df(df, capitalize_index=True, capitalize_columns=True)

        # Declaring the important fields, not including timestamp and replacing spaces in values with '-'
        self.versie_datum_model = df.loc[cn.VERSIE_DATUM_MODEL][cn.WAARDEN].strftime("%Y-%m-%d")
        df.loc[cn.VERSIE_DATUM_MODEL] = self.versie_datum_model

        df[cn.WAARDEN] = df[cn.WAARDEN].str.replace(' ', '-')
        self.naam_kb = df.loc[cn.NAAM_KB][cn.WAARDEN]
        self.code_kb = df.loc[cn.CODE_KB][cn.WAARDEN]
        self.naam_kdgb = df.loc[cn.NAAM_KDGB][cn.WAARDEN]
        self.code_kdgb = df.loc[cn.CODE_KDGB][cn.WAARDEN]
        self.naam_model = handle_naam_model(df.loc[cn.NAAM_MODEL][cn.WAARDEN])
        self.titel_model = df.loc[cn.NAAM_MODEL][cn.WAARDEN]
        self.versie_num_model = df.loc[cn.VERSIE_NUM_MODEL][cn.WAARDEN]
        self.versie_num_model_without_snapshot = self.versie_num_model.split("-", maxsplit=1)[0]
        self.taal_model = df.loc[cn.TAAL_MODEL][cn.WAARDEN]
        self.taal_model_lower = self.taal_model.lower()
        if pd.notna(df.loc[cn.SECTAAL_MODEL][cn.WAARDEN]):
            self.sec_taal_model = df.loc[cn.SECTAAL_MODEL][cn.WAARDEN]
            self.sec_taal_model_lower = self.sec_taal_model.lower()

    def process_kennisbronnen(self):
        """Function that handles the sheet "Kennisbronnen"
        """
        df = read_sheet_as_dataframe(
            xls_file=self.input_xlsx,
            sheet_name=cn.KENNISBRONNEN,
            rename_columns=True,
            column_mapping=cn.KENNISBRONNEN_COLUMN_MAPPING
        )
        df = capitalize_df(df, capitalize_columns=True)

        for i in df.itertuples():
            grondslagURI = create_uri(str(i[get_column_index(df, cn.CITEERTITEL)]))
            self.g.add((grondslagURI, RDF.type, DCTERMS.BibliographicResource))

            if pd.notna(i[get_column_index(df, cn.CITEERTITEL)]):
                self.g.add((grondslagURI, RDFS.label,
                            Literal(i[get_column_index(df, cn.CITEERTITEL)])))
                self.g.add((grondslagURI, DCTERMS.alternative,
                            Literal(i[get_column_index(df, cn.CITEERTITEL)])))

            if pd.notna(i[get_column_index(df, cn.ONDERDEELVAN)]):
                if i[get_column_index(df, cn.ONDERDEELVAN)] in df[cn.CITEERTITEL].unique():
                    self.g.add((grondslagURI, DCTERMS.isPartOf, create_uri(i[get_column_index(df, cn.ONDERDEELVAN)])))

            if pd.notna(i[get_column_index(df, cn.BRONNAAM)]):
                self.g.add((grondslagURI, DCTERMS.title, Literal(i[get_column_index(df, cn.BRONNAAM)])))

            if pd.notna(i[get_column_index(df, cn.BRONLOCATIE)]):
                if str(i[4][:4]) == cn.HTTP:
                    self.g.add((grondslagURI, DCTERMS.bibliographicCitation, URIRef(i[get_column_index(df, cn.BRONLOCATIE)])))
                if str(i[4][:4]) != cn.HTTP:
                    self.g.add((grondslagURI, DCTERMS.bibliographicCitation, Literal(i[get_column_index(df, cn.BRONLOCATIE)])))

    def process_begrippen(self):
        """Function that handles the sheet "Begrippen"
        """
        df_begrippen = read_sheet_as_dataframe(
            xls_file=self.input_xlsx,
            sheet_name=cn.BEGRIPPEN,
            rename_columns=True,
            column_mapping=cn.BEGRIPPEN_COLUMN_MAPPING
        )
        df_kennisbronnen = read_sheet_as_dataframe(
            xls_file=self.input_xlsx,
            sheet_name=cn.KENNISBRONNEN,
            rename_columns=True,
            column_mapping=cn.KENNISBRONNEN_COLUMN_MAPPING
        )
        df_begrippen = capitalize_df(df_begrippen, capitalize_columns=True)
        df_kennisbronnen = capitalize_df(df_kennisbronnen, capitalize_columns=True)
        lookup_code_kb = '"{}"'.format(self.code_kb)
        lookedup_kg_uri = lookup_kb_uri(DATASTORE_ENDPOINT, lookup_code_kb, is_kg=True)

        for i in df_begrippen.itertuples():
            subject = create_uri(f"{self.code_kb}/{self.naam_model}{i[get_column_index(df_begrippen, cn.VOORKEURSTERM)]}")
            self.g.add((subject, RDF.type, SKOS.Concept))
            self.g.add((subject, SKOS.inScheme, self.modelURI))
            self.g.add((subject, cn.NS_KGR.kennisgebied, URIRef(lookedup_kg_uri)))

            # Voorkeursterm
            self.g.add((subject, RDFS.label, Literal(i[get_column_index(df_begrippen, cn.VOORKEURSTERM)], lang=self.taal_model_lower)))
            self.g.add((subject, SKOS.prefLabel, Literal(i[get_column_index(df_begrippen, cn.VOORKEURSTERM)], lang=self.taal_model_lower)))

            # Bovenliggend begrip
            if pd.notna(i[get_column_index(df_begrippen, cn.BOVENLIGGEND_BEGRIP)]):
                predicate = SKOS.broader
                object = create_uri(f"{self.code_kb}/{self.naam_model}{i[get_column_index(df_begrippen, cn.BOVENLIGGEND_BEGRIP)]}")
                self.g.add((subject, predicate, object))

            # Definitie
            if pd.notna(i[get_column_index(df_begrippen, cn.DEFINITIE)]):
                predicate = SKOS.definition
                object = Literal(i[get_column_index(df_begrippen, cn.DEFINITIE)], lang=self.taal_model_lower)
                self.g.add((subject, predicate, object))
                # Verwijzing van begrippen https://jira.belastingdienst.nl/browse/GVG-4800
                resDefinitie = re.findall(r'\[.*?\]', i[get_column_index(df_begrippen, cn.DEFINITIE)])
                for begrip_bron in resDefinitie:

                    for j in df_begrippen.itertuples():
                        term = "[" + str(j[get_column_index(df_begrippen, cn.VOORKEURSTERM)]) + "]"
                        if term.casefold() == begrip_bron.casefold():
                            # print("The strings are the same (case insensitive)")
                            predicate2 = SKOS.related
                            object2 = create_uri(
                                f"{self.code_kb}/{self.naam_model}{str(j[get_column_index(df_begrippen, cn.VOORKEURSTERM)])}")
                            self.g.add((subject, predicate2, object2))

                    if begrip_bron.count('.') == 1:
                        parts = str(begrip_bron)[1:-1].split(".") # Format is [{Code kb}.{Begrip}]
                        lookup_endpoint_dev = "https://fuseki.ont.belastingdienst.nl/modellenbibliotheek-ontw/sparql"
                        lookup_endpoint = get_datastore_endpoint() + "/sparql" if get_datastore_endpoint() else lookup_endpoint_dev
                        lookup_code_kb = '{}'.format(parts[0])
                        lookup_externe_begrip = '{}'.format(parts[1])
                        begrip_uri = lookup_begrip_uri(lookup_endpoint, lookup_code_kb, lookup_externe_begrip)
                        if begrip_uri is not None:
                            self.g.add((subject, SKOS.related, URIRef(begrip_uri)))

            # Toelichting
            if pd.notna(i[get_column_index(df_begrippen, cn.TOELICHTING)]):
                self.g.add((subject, SKOS.scopeNote, Literal(str(i[get_column_index(df_begrippen, cn.TOELICHTING)]), lang=self.taal_model_lower)))

            # Redactionele opmerking
            if (cn.REDACTIONELE_OPMERKING in df_begrippen.columns):
                if pd.notna(i[get_column_index(df_begrippen, cn.REDACTIONELE_OPMERKING)]):
                    self.g.add(
                        (subject, SKOS.editorialNote,
                         Literal(str(i[get_column_index(df_begrippen, cn.REDACTIONELE_OPMERKING)]), lang=self.taal_model_lower))
                    )

            # Alternatieve Term(en)
            if pd.notna(i[get_column_index(df_begrippen, cn.ALTERNATIEVE_TERMEN)]):
                self.g.add((subject, SKOS.altLabel, Literal(i[get_column_index(df_begrippen, cn.ALTERNATIEVE_TERMEN)], lang=self.taal_model_lower)))

            # Kennisbron(nen)
            if pd.notna(i[get_column_index(df_begrippen, cn.BEGRIPPEN_KENNISBRONNEN)]):
                kennisbronnen = i[get_column_index(df_begrippen, cn.BEGRIPPEN_KENNISBRONNEN)].replace(
                    '; ', ';').replace(', jo.', ' jo.').replace(' jo.', ';').split(";")
                if len(kennisbronnen) == 1:
                    kennisbronnen = kennisbronnen[0].split("\n")

                for begrip_bron in kennisbronnen:
                    trimmed_begrip_bron = begrip_bron.lstrip().rstrip()
                    kennisbron_uri = create_uri(f"{trimmed_begrip_bron}")
                    self.g.add((subject, cn.NS_MB["grondslag"], kennisbron_uri))
                    self.g.add((kennisbron_uri, RDF.type, DCTERMS.BibliographicResource))
                    self.g.add((kennisbron_uri, RDFS.label, Literal(begrip_bron)))

                    if len(trimmed_begrip_bron.split()) > 1:
                        begrip_bron_one_word = trimmed_begrip_bron.split()[::-1][0]
                        begrip_bron_two_words = ' '.join(begrip_bron.split()[-2:])

                        determine_grondslag_uri = lambda bron: \
                            find_uri_in_graph(self.g, Literal(bron)) \
                                if find_uri_in_graph(self.g, Literal(bron)) \
                                else create_uri(bron)

                        begrip_bron_uri = determine_grondslag_uri(begrip_bron_one_word) \
                            if begrip_bron_one_word in df_kennisbronnen[cn.CITEERTITEL].values \
                            else (
                                determine_grondslag_uri(begrip_bron_two_words)
                                if begrip_bron_two_words in df_kennisbronnen[cn.CITEERTITEL].values
                                else None
                            )

                        if begrip_bron_uri:
                            if begrip_bron_uri != kennisbron_uri:
                                self.g.add((kennisbron_uri, DCTERMS.isPartOf, begrip_bron_uri))

                    if begrip_bron in df_kennisbronnen[cn.CITEERTITEL].values:
                        k = df_kennisbronnen.index[df_kennisbronnen[cn.CITEERTITEL] == begrip_bron]
                        found_uri = find_uri_in_graph(self.g, Literal(begrip_bron))
                        grondslag_uri = found_uri if found_uri else create_uri(str(df_kennisbronnen.iloc[k][cn.BRONNAAM]))

                        if grondslag_uri != kennisbron_uri:
                            self.g.add((kennisbron_uri, DCTERMS.isPartOf, grondslag_uri))

            # Voorbeelden
            if pd.notna(i[get_column_index(df_begrippen, cn.VOORBEELDEN)]):
                self.g.add((subject, SKOS.example, Literal(i[get_column_index(df_begrippen, cn.VOORBEELDEN)])))

            if cn.VOORKEURSTERM_SECUNDAIRE_TAAL in df_begrippen.columns:
                if pd.notna(i[get_column_index(df_begrippen, cn.VOORKEURSTERM_SECUNDAIRE_TAAL)]):
                    self.g.add((subject, SKOS.prefLabel,
                                Literal(i[get_column_index(df_begrippen, cn.VOORKEURSTERM_SECUNDAIRE_TAAL)],
                                        lang=self.sec_taal_model_lower)))

            if cn.DEFINITIE_SECUNDAIRE_TAAL in df_begrippen.columns:
                if pd.notna(i[get_column_index(df_begrippen, cn.DEFINITIE_SECUNDAIRE_TAAL)]):
                    self.g.add((subject, SKOS.definition,
                                Literal(i[get_column_index(df_begrippen, cn.DEFINITIE_SECUNDAIRE_TAAL)],
                                        lang=self.sec_taal_model_lower)))

    def process_termvormen(self):
        """Function that handles the sheet "Termvormen"
        """
        df = read_sheet_as_dataframe(
            xls_file=self.input_xlsx,
            sheet_name=cn.TERMVORMEN,
            rename_columns=True,
            column_mapping=cn.TERMVORMEN_COLUMN_MAPPING
        )
        capitalize_df(df, capitalize_columns=True)

        for i in df.itertuples():
            enkelvoud_uri = create_uri(str(i[get_column_index(df, cn.ENKELVOUD)]))
            meervoud_uri = create_uri(str(i[get_column_index(df, cn.MEERVOUD)]))
            afkorting_uri = create_uri(str(i[get_column_index(df, cn.AFKORTING)]))

            # Enkelvoud
            if pd.notna(i[get_column_index(df, cn.ENKELVOUD)]):
                self.g.add((enkelvoud_uri, cn.NS_SKOSXL.literalForm, Literal(str(i[get_column_index(df, cn.ENKELVOUD)]))))
                self.g.add((enkelvoud_uri, RDF.type, cn.NS_SKOSXL.Label))
                self.g.add((enkelvoud_uri, cn.NS_SM.meervoud, meervoud_uri))
                self.g.add((enkelvoud_uri, cn.NS_SKOSXL.hiddenLabel, meervoud_uri))

            # Meervoud
            if pd.notna(i[get_column_index(df, cn.MEERVOUD)]):
                self.g.add((meervoud_uri, cn.NS_SKOSXL.literalForm, Literal(str(i[get_column_index(df, cn.MEERVOUD)]))))
                self.g.add((meervoud_uri, RDF.type, cn.NS_SKOSXL.Label))
                self.g.add((meervoud_uri, cn.NS_SM.enkelvoud, enkelvoud_uri))

            # Afkorting
            if pd.notna(i[get_column_index(df, cn.AFKORTING)]):
                self.g.add((afkorting_uri, cn.NS_SKOSXL.literalForm, Literal(str(i[get_column_index(df, cn.AFKORTING)]))))
                self.g.add((afkorting_uri, RDF.type, cn.NS_SKOSXL.Label))
                self.g.add((afkorting_uri, cn.NS_SM.afkorting, enkelvoud_uri))
                self.g.add((afkorting_uri, cn.NS_SKOSXL.hiddenLabel, enkelvoud_uri))
