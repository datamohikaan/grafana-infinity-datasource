# -*- coding: utf-8 -*-
"""
Created on Thu Jan 12 09:36:48 2023
@author: Nigel van der Laan
"""

import re
import uuid
from timeit import default_timer as timer

import pandas as pd
from numpy import nan
from rdflib import Graph, URIRef, Literal
# Turtle libs
from rdflib.namespace import Namespace, RDF, RDFS, XSD, DCTERMS, SKOS


# create uri
# Elke canonieke URI heeft de volgende opbouw, conform RFC4122:


def uri(name):
    uuidstr = uuid.uuid5(uuid.NAMESPACE_URL, name)
    return URIRef(f'urn:uuid:{uuidstr}')


# create NamedGraph_uri
def named_graph_uri(file_dir, file, file_name):

    xls = pd.ExcelFile(file_dir + file)

    if 'Algemeen' in xls.sheet_names:
        df1 = pd.read_excel(xls, 'Algemeen')
        get_file_info(df1)

    # KG_Loc atie_-_BAG_-_v3.0.3_-_2022-12-06
    model_file_name = "KG_"+naam_kb+"_-_"+naam_model + \
        "_-_"+"v"+str(versie_num_model)+"_-_" + \
        versie_datum_model.strftime("%Y-%m-%d")
    print(f'derived_model_file_name : {model_file_name}')

    hash_uuid = uuid.uuid5(uuid.NAMESPACE_URL, str(model_file_name))
    uri = f'urn:uuid:{hash_uuid}'
    print(f'Named_graph/URI: {uri}')

    return uri


# convert excel to .ttl

def turtlemania(file_dir, file, file_name):

    #############################################################
    #  o__         __o        ,__o        __o           __o
    #  ,>/_       -\<,      _-\_<,       _`\<,_       _ \<_
    # (*)`(*).....O/ O.....(*)/'(*).....(*)/ (*).....(_)/(_)
    # RESULTING CONSENSED RDF .ttl structure
    # -------------------------------------
    # Omzetting excel conform begripstemplate naar turtle conform metamodel SM
    # https://jira.belastingdienst.nl/browse/GVG-3278
    # https://confluence.belastingdienst.nl/display/MBIEB/Bronnen+-+wet-+en+regelgeving?src=contextnavpagetreemode
    start_timer_sm_xml2rdf = timer()

    xls = pd.ExcelFile(file_dir + file)
    tabs = pd.ExcelFile(file_dir + file).sheet_names
    #print(tabs)

    if 'Algemeen' in xls.sheet_names:
        df1 = pd.read_excel(xls, 'Algemeen')
        #get_file_info(df1)
    if 'Begrippen' in xls.sheet_names:
        df2 = pd.read_excel(xls, 'Begrippen')
        get_file_info2(df2)
    if 'Kennisbronnen' in xls.sheet_names:
        df3 = pd.read_excel(xls, 'Kennisbronnen')
        get_file_info3(df3)

    file_name_turtle = file_name+".ttl"
    g = Graph()
    # Custom namespaces
    NS_MB = Namespace("http://modellenbibliotheek.belastingdienst.nl/def/mb#")
    NS_KGR = Namespace(
        "http://modellenbibliotheek.belastingdienst.nl/def/kgr#")

    # add custom namespaces
    g.bind("mb", NS_MB)
    g.bind("kgr", NS_KGR)
    g.bind("skos", SKOS)
    g.bind("rdfs", RDFS)
    g.bind("dcterms", DCTERMS)

    KGPREFIX = URIRef("http://modellenbibliotheek.belastingdienst.nl/def/kgr#")
    SMPREFIX = URIRef("http://modellenbibliotheek.belastingdienst.nl/sm/")

    kennisgebied = naam_model

    modelURI = (URIRef(SMPREFIX + kennisgebied))
    g.add((modelURI, RDF.type, SKOS.ConceptScheme))
    g.add((modelURI, RDF.type, NS_MB.Model))
    g.add((modelURI, NS_KGR.kennisgebied, URIRef(
        "http://modellenbibliotheek.belastingdienst.nl/id/kennisgebied/"+code_kb)))

    semantisch_model = "Semantisch model " + Literal(naam_model)
    g.add((modelURI, RDFS.label, Literal(semantisch_model)))
    # modelversie
    # add triples to the rdf graph

    modelversieURI = (
        URIRef(SMPREFIX + kennisgebied + "/" + versie_num_model))
    g.add((modelversieURI, RDF.type, NS_MB.Modelversie))
    g.add((modelversieURI, NS_MB.versieVan, modelURI))
    g.add((modelversieURI, NS_MB.versiedatum, Literal(
        versie_datum_model, datatype=XSD.date)))
    g.add((modelversieURI, NS_MB.versienummer, Literal(versie_num_model)))
    g.add((modelversieURI, RDFS.label, Literal(
        semantisch_model) + " "+versie_num_model))
    g.add((modelversieURI, NS_MB.status, NS_MB.Finaal))

    # begrippen
    if 'Begrippen' in tabs:

        for i in df2.itertuples():

            subject = uri(f"{code_kb}/{naam_model}{i[TERM]}")
            g.add((subject, RDF.type, SKOS.Concept))
            # https://jira.belastingdienst.nl/browse/GVG-4910 Correcte link naar kennisgebied maken

            g.add((subject, NS_KGR.kennisgebied, URIRef(
                "http://modellenbibliotheek.belastingdienst.nl/id/kennisgebied/"+code_kb)))

            # Voorkeursterm
            g.add((subject, RDFS.label, Literal(i[TERM])))

            # Bovenliggend begrip
            if i[BOVENLIGGEND] is not nan:
                predicate = SKOS.broader
                object = uri(f"{code_kb}/{naam_model}{i[BOVENLIGGEND]}")
                g.add((subject, predicate, object))

            # Definitie
            if i[DEFINITIE] is not nan:
                predicate = SKOS.definition
                object = Literal(i[DEFINITIE])
                g.add((subject, predicate, object))
                # Verwijzing van begrippen https://jira.belastingdienst.nl/browse/GVG-4800
                resDefinitie = re.findall(r'\[.*?\]', i[DEFINITIE])
                for x in resDefinitie:

                  for j in df2.itertuples():
                           term = "["+str(j[TERM])+"]"
                           if term.casefold() == x.casefold():
                                # print("The strings are the same (case insensitive)")
                                predicate2 = SKOS.related
                                object2 = uri(
                                    f"{code_kb}/{naam_model}{str(j[TERM])}")
                                g.add((subject, predicate2, object2))

            # Toelichting
            if i[TOELICHTING] is not nan:
                g.add((subject, SKOS.scopeNote, Literal(
                    i[TOELICHTING], lang=taal_model)))

            # Synoniem(en)
            if i[SYNONIEM] is not nan:
                g.add((subject, SKOS.altLabel, Literal(
                    i[SYNONIEM], lang=taal_model)))

            resKennisbron = ""
            if i[KENNISBRON] is not nan:

                resKennisbron = i[KENNISBRON].replace(
                    '; ', ';').replace(', jo.', ' jo.').replace(' jo.', ';').split(";")

            for x in resKennisbron:
                if len(x) > 0:
                    kennisbron = uri(f"{x}")
                    g.add((subject, NS_MB["grondslag"], kennisbron))
                    g.add((kennisbron, RDF.type, DCTERMS.BibliographicResource))
                    g.add((kennisbron, RDFS.label, Literal(x)))

                    for k in df3.itertuples():
                            grondslag = str(k[CITEERTITEL])
                            if (grondslag in x):
                                grondslagURI = uri(k[BRONNAAM])
                                g.add((kennisbron, DCTERMS.isPartOf, grondslagURI))

    if 'Kennisbronnen' in tabs:

        for i in df3.itertuples():

            grondslagURI = uri(i[CITEERTITEL])
            g.add((grondslagURI, RDF.type, DCTERMS.BibliographicResource))

            if i[CITEERTITEL] is not nan:
                g.add((grondslagURI, DCTERMS.alternative,
                      Literal(i[CITEERTITEL])))

            if i[ONDERDEELVAN] is not nan:

                for j in df3.itertuples():

                    if i[ONDERDEELVAN] == j[CITEERTITEL]:
                        g.add((grondslagURI, DCTERMS.isPartOf,
                              uri(i[ONDERDEELVAN])))

            if i[BRONNAAM] is not nan:
                g.add((grondslagURI, DCTERMS.title, Literal(i[BRONNAAM])))
                g.add((grondslagURI, RDFS.label, Literal(i[BRONNAAM])))

            if i[BRONLOCATIE] is not nan:
                if str(i[4][:4]) == "http":
                    g.add((grondslagURI, DCTERMS.bibliographicCitation,
                          URIRef(i[BRONLOCATIE])))
                if str(i[4][:4]) != "http":
                    g.add((grondslagURI, DCTERMS.bibliographicCitation,
                          Literal(i[BRONLOCATIE])))

    g.serialize(destination=file_dir + file_name_turtle)

    end_timer_sm_xml2rdf = timer()
    elapsed_time = round((end_timer_sm_xml2rdf - start_timer_sm_xml2rdf), 2)
    print(">>>Measure of the Elapsed Time SM_xml2rdf = " +
          str(elapsed_time) + " seconds<<<")

    return file_name_turtle


def get_file_info(df1):   # Algemeen vars
    #will ensure that a variable has some value before use:
    global naam_kb
    global code_kb
    global naam_kgdb
    global code_kdgb
    global naam_model
    global taal_model
    global sectaal_model
    global versie_num_model
    global versie_datum_model
    global bms_versie

    for i in range(len(df1)):

        try:
           rowkey = df1['Kennisgebied en metadata'].values[i]
        except:
          rowkey = df1['KENNISGEBIED & METADATA'].values[i]

        try:
          rowval = df1['In te vullen waarden'].values[i]
        except:
          rowval = df1['IN TE VULLEN WAARDEN'].values[i]
 
        # print ( str(rowkey) + " : " + str(rowval))
        # Naam kennisgebied
        if rowkey == "Naam kennisgebied":
            naam_kb = rowval
            naam_kb = naam_kb.replace(" ", "-")

        # Code kennisgebied
        if rowkey == "Code kennisgebied":
            code_kb = rowval

        # Naam kennisdeelgebied
        if rowkey == "Naam kennisdeelgebied":
            naam_kdgb = rowval
            naam_kdgb = naam_kdgb.replace(" ", "-")

        # Code kennisdeelgebied
        if rowkey == "Code kennisdeelgebied":
            code_kdgb = rowval

        # Naam model
        if rowkey == "Naam model":
            naam_model = rowval
            naam_model = naam_model.replace(" ", "-")

        # Primaire taal van het model
        if rowkey == "Primaire taal van het model":
            taal_model = rowval

        # Secundaire taal van het model
        if rowkey == "Secundaire taal van het model":
            sectaal_model = rowval

        # Versienummer model
        if rowkey == "Versienummer model":
            versie_num_model = rowval
            pattern = r'(\d+(?:\.\d+){2})'
            versie_num_model = re.findall(pattern, str(versie_num_model))
            versie_num_model = versie_num_model[0]

        # Versiedatum model
        if rowkey == "Versiedatum model":
            versie_datum_model = rowval

        # Gebaseerd op BMS-template versie
        if rowkey == "Gebaseerd op BMS-template versie":
            bms_versie = rowval

    print("")
    print("---------------------------------------")
    print("")
    print("#  o__         __o        ,__o        __o           __o")
    print("#  ,>/_       -\<,      _-\_<,       _`\<,_       _ \<_")
    print("# (*)`(*).....O/ O.....(*)/'(*).....(*)/ (*).....(_)/(_")
    print("Tabblad Algmeen")

    try:
        print(f'[Naam Kennisgebied]: {naam_kb}')
    except NameError:
        raise ValueError(
            "[Naam Kennisgebied] komt niet voor op tabblad Algemeen")

    try:
        print(f'[Code Kennisgebied]: {code_kb}')
    except NameError:
        raise ValueError(
            "[Code Kennisgebied] komt niet voor op tabblad Algemeen")

    try:
        print(f'[Naam kennisdeelgebied]: {naam_kdgb}')
    except NameError:
       pass 
       #raise ValueError( "[Naam kennisdeelgebied] komt niet voor op tabblad Algemeen")

    try:
          print(f'[Code kennisdeelgebied]: {code_kdgb}')
    except NameError:
       pass
       #raise ValueError(" [Code Kennisdeelgebied] komt niet voor op tabblad Algemeen")

    try:
        print(f'[Naam model]: {naam_model}')
    except NameError:
        raise ValueError(
            "[Naam model] komt niet voor op tabblad Algemeen")

    try:
        print(f'[Versienummer model]: {versie_num_model}')
    except NameError:
        raise ValueError(
            "[Versienummer model] komt niet voor op tabblad Algemeen")

    try:
        print(f'[Primaire taal van het model]: {taal_model}')
    except NameError:
        raise ValueError(
            "[Primaire taal van het model] komt niet voor op tabblad Algemeen")

    try:
        print(f'[Secundaire taal van het model]: {sectaal_model}')
    except NameError:
        pass
        #Print "[Secundaire taal van het model] komt niet voor op tabblad Algemeen")
        #raise ValueError(
        #    "[Secundaire taal van het model] komt niet voor op tabblad Algemeen")

    try:
        print(f'[Versiedatum model]: {versie_datum_model}')
    except NameError:
        raise ValueError(
            "[Versiedatum model] komt niet voor op tabblad Algemeen")

    try:
        print(f'[Gebaseerd op BMS-template versie]: {bms_versie}')
    except NameError:
        raise ValueError(
            "[Gebaseerd op BMS-template versie] komt niet voor op tabblad Algemeen")

    # Now you're free to use AlgemeenVars without Python complaining.
    print("")
    print("---------------------------------------")
    print("")


def get_file_info2(df2):  # begrippen
    #will ensure that a variable has some value before use:
    # KOLOMNAMEN begrippen
    global TERM
    global BOVENLIGGEND
    global DEFINITIE
    global TOELICHTING
    global SYNONIEM
    global KENNISBRON
    # iterating the columns
    colnum = 0
    for col in df2.columns:
        colnum = colnum + 1
        if col.lower() == 'voorkeursterm':
            TERM = colnum
        if col.lower() == 'bovenliggend begrip':
            BOVENLIGGEND = colnum
        if col.lower() == 'definitie':
            DEFINITIE = colnum
        if col.lower() == 'toelichting':
            TOELICHTING = colnum
        if col.lower() == 'synoniem(en)':
            SYNONIEM = colnum
        if col.lower() == 'alternatieve term(en)':
            SYNONIEM = colnum
        if col.lower() == 'kennisbron(nen)':
            KENNISBRON = colnum

    print("")
    print("---------------------------------------")
    print("")
    print("#  o__         __o        ,__o        __o           __o")
    print("#  ,>/_       -\<,      _-\_<,       _`\<,_       _ \<_")
    print("# (*)`(*).....O/ O.....(*)/'(*).....(*)/ (*).....(_)/(_")
    print("# tabblad begrippen:")
    try:
        print(f'[Voorkeursterm]: {TERM}')
    except NameError:
        raise ValueError(
            "[Voorkeursterm] komt niet voor op tabblad Begrippen")
    try:
        print(f'[Bovenliggend begrip]: {BOVENLIGGEND}')
    except NameError:
        raise ValueError(
            "[Bovenliggend begrip] komt niet voor op tabblad Begrippen")
    try:
        print(f'[Definitie]: {DEFINITIE}')
    except NameError:
        raise ValueError(
            "[Definitie] komt niet voor op tabblad Begrippen")

    try:
        print(f'[Toelichting]: {TOELICHTING}')
    except NameError:
        raise ValueError(
            "[Toelichting] komt niet voor op tabblad Begrippen")

    try:
        print(f'[Synoniem(en)] cq [Alternatieve termen]: {SYNONIEM}')
    except NameError:
        raise ValueError(
            "[Synoniem(en)] of [Alternatieve termen] komt niet voor op tabblad Begrippen")
    try:
        print(f'[Kennisbron(nen]: {KENNISBRON}')
    except NameError:
        raise ValueError(
            "[Kennisbron(nen] komt niet voor op tabblad Begrippen")

    # Now you're free to use AlgemeenVars without Python complaining.
    print("")
    print("---------------------------------------")
    print("")
    #print("#  o__         __o        ,__o        __o           __o")
    #print("#  ,>/_       -\<,      _-\_<,       _`\<,_       _ \<_")
    #print("# (*)`(*).....O/ O.....(*)/'(*).....(*)/ (*).....(_)/(_")


def get_file_info3(df3):   # Kennisbronnen grondslagen
    #will ensure that a variable has some value before use:
    # KOLOMNAMEN kennisbronnen
    global CITEERTITEL
    global ONDERDEELVAN
    global BRONNAAM
    global BRONLOCATIE

    colnum = 0
    for col in df3.columns:
         colnum = colnum + 1
         if col.lower() == 'citeertitel':
             CITEERTITEL = colnum
         if col.lower() == 'onderdeel van':
             ONDERDEELVAN = colnum
         if col.lower() == 'bronnaam':
             BRONNAAM = colnum
         if col.lower() == 'bronlocatie':
             BRONLOCATIE = colnum

    print("")
    print("---------------------------------------")
    print("")
    print("#  o__         __o        ,__o        __o           __o")
    print("#  ,>/_       -\<,      _-\_<,       _`\<,_       _ \<_")
    print("# (*)`(*).....O/ O.....(*)/'(*).....(*)/ (*).....(_)/(_")
    print("Tabblad Kennisbronnen ")
    try:
         print(f'[Citeertitel]: {CITEERTITEL}')
    except NameError:
         raise ValueError(
             "[Citeertitel] komt niet voor op tabblad Kennisbronnen")

    try:
         print(f'[Onderdeel van]: {ONDERDEELVAN}')
    except NameError:
         raise ValueError(
             "[Onderdeel van komt niet voor op tabblad Kennisbronnen")

    try:
         print(f'[Bronnaam]: {BRONNAAM}')
    except NameError:
         raise ValueError(
             "[Bronnaam] komt niet voor op tabblad Kennisbronnen")

    try:
         print(f'[Bronlocatie]: {BRONLOCATIE}')
    except NameError:
         raise ValueError(
             "[Bronlocatie] komt niet voor op tabblad Kennisbronnen")

    # Now you're free to use AlgemeenVars without Python complaining.
    print("")
    print("---------------------------------------")
    print("")
    #print("#  o__         __o        ,__o        __o           __o")
    #print("#  ,>/_       -\<,      _-\_<,       _`\<,_       _ \<_")
    #print("# (*)`(*).....O/ O.....(*)/'(*).....(*)/ (*).....(_)/(_")
