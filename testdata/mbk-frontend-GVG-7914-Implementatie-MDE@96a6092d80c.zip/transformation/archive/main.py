#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar 21 10:39:56 2022.

@author: Peter Bosch. 
"""
# ********** instructies **********
# run script handmatig!
# cd /Users/boscp08/src/Projects/gitlab-tiemen/_indeling-modellenbibliotheek/lab/modellenbeheer
# python3 main.py kennismodellen/locatie/SM0.xlsx kennismodellen/locatie/SM1.xlsx   kennismodellen/locatie/SM2.xlsx etc
# als ware het [export CHANGED_FILES=`git diff ${CI_COMMIT_BEFORE_SHA} ${CI_COMMIT_SHA} --name-only]   .gitlab-ci.yml

import os.path
import sys

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.append(os.path.dirname(CURRENT_DIR))
from transformation.sm_transformer import SMTransformer
from transformation.ldm_transformer import LDMTransformer
from rdflib import Graph
from os import path
from utils.loaderquads import LoaderQuads
# program starts here acutally
# .gitlab-ci.yml  ->   - python3 main.py ${CHANGED_FILES}

ROOT_DIR = os.path.realpath(os.path.join(os.path.dirname(__file__), ''))
file: str
file_dir: str
file_name: str 
file_extension: str
file_name_turtle: str
uri: str


def main(GITLAB_CHANGED_FILES):
    for idx, arg in enumerate(GITLAB_CHANGED_FILES[1:], start=1):
        ###########################################
        # export CHANGED_FILES=`git diff ${CI_COMMIT_BEFORE_SHA} ${CI_COMMIT_SHA} --name-only
        print("Argument #{} is {}".format(idx, arg))
        # Argument #1 is kennismodellen/locatie/SM0.xlsx
        raw_filename = sys.argv[idx]
        # print (raw_filename) #kennismodellen/locatie/SM3278.xlsx
        set_file_info(raw_filename)

        print("hele pad filedir + file="+file_dir + file)
        if path.isfile(file_dir + file):
            print_file_info(file, file_dir, file_name, file_extension)
            if file_extension == ".ttl":
                handle_turtle_file(file, file_dir, file_name, file_extension)
            else:
                handle_non_turtle_file(
                    file, file_dir, file_name, file_extension)
            LoaderQuads(file_dir, file_name, uri, file_name_turtle).load_sparql()

     
    print("Number of elements excluding the name of the program:", (len(sys.argv) - 1))

def set_file_info(raw_filename):
    global file
    global file_dir
    global file_name
    global file_extension
    file = raw_filename.rsplit('/', 1)[-1]
    relative_path = raw_filename.replace(file, "")
    file_dir = os.path.join(ROOT_DIR, relative_path)
    split_filename_extension = os.path.splitext(file)
    file_name = split_filename_extension[0]
    file_extension = split_filename_extension[1]

def handle_non_turtle_file(file, directory, name, extension):
    global file_name_turtle
    global uri
    if extension == ".ldm":
        print("hoi ldm nice to see you again!")
        ldm_handler = LDMTransformer(directory, file, name)
        ldm_handler.transform_ldm_xml_to_rdf()

        # Obtaining the graph uri and name of the turtle file
        uri = ldm_handler.get_model_uri()
        file_name_turtle = ldm_handler.get_file_name_turtle()
        print("\nuri = " + uri)

    elif extension == ".xlsx":
        print("hoi SM nice to see you again!")
        sm_handler = SMTransformer(directory, file, name)
        sm_handler.transform_sm_xml_to_rdf()

        # Obtaining the graph uri and name of the turtle file
        uri = sm_handler.get_uri()
        file_name_turtle = sm_handler.get_file_name_turtle()
        print("\nuri = " + uri)
    else:
        raise ValueError("unexpected file type" + extension)


def handle_turtle_file(file, directory, name, extension):
    global file_name_turtle
    global uri
    kennisgebiedenregister_dir = ROOT_DIR + \
        os.sep + "kennisgebiedenregister" + os.sep
    if kennisgebiedenregister_dir != directory:
        raise ValueError(
            "turtle file in andere directory dan kennisgebiedenregister")
        
    parse_and_serialize_kennisgebiedenregister(kennisgebiedenregister_dir)
    uri = "urn:name:kennisgebiedenregister"
    print(uri)
    file_name_turtle = "sjebang_kennisgebiedenregister.ttl"
    print("file_name_turtle=" + directory + file_name_turtle)


def parse_and_serialize_kennisgebiedenregister(kennisgebiedenregister):
    g1 = Graph()
    #g1.parse(ROOT_DIR + "/" + file_dir + "/" + file, format="turtle")
    g1.parse(kennisgebiedenregister + "affiliatie.ttl")
    g2 = Graph()
    g2.parse(kennisgebiedenregister +
             "domeinen.ttl")
    g3 = Graph()
    g3.parse(kennisgebiedenregister +
             "kennisdeelgebieden.ttl")
    g4 = Graph()
    g4.parse(kennisgebiedenregister +
             "kennisgebieden.ttl")
    g5 = Graph()
    g5.parse(kennisgebiedenregister +
             "wetgeving.ttl")
    graph = g1 + g2 + g3 + g4 + g5
    graph.serialize(kennisgebiedenregister +
                    "sjebang_kennisgebiedenregister.ttl", format="turtle")  # final rdf


def print_file_info(file, directory, name, extension):
    if path.isfile(directory + file):
        print("directory = " + directory)
        print("file_name = " + name)
        print("file_extension = " + extension)
        print("Is it File?" + str(path.isfile(directory + file)))  # True
        if extension != ".ttl":
            print("target directory = " + directory)
            print("file_name = " + name)
            print("file_extension = .ttl ")


if __name__ == "__main__":
    main(sys.argv)
