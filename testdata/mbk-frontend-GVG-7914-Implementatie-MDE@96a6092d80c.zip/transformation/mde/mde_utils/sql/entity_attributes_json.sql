With attributes_extended as
(
select *
     , case when DataType = 'I' then 'integer'
            when DataType = 'SI' then 'smallinteger'
            when DataType = 'LI' then 'largeinteger'
            when DataType = 'DT' then 'dateandtime'
            when DataType = 'TS' then 'timestamp'
            when DataType = 'D' then 'date'
            when DataType = 'T' then 'time'
            when substring(datatype,1,2) = 'VA' then 'variablecharacters'
            when substring(datatype,1,2) = 'DC' then 'numeric'
            when substring(datatype,1,1) = 'A' then 'characters'
            when substring(datatype,1,1) = 'N' then 'numeric'
            else 'text'
       end as dt
     , tijdscontext_oid is not null as historized
from '%MDE_SOURCE_PATH%/attribute.parquet'
)
select entity_uuid
     , json_object('attributes',json_group_array(json_object('code',code
                                                            ,'name',name
                                                            ,'uuid',uuid
                                                            ,'type',dt
                                                            ,'length', length::integer
                                                            ,'precision',precision
                                                            ,'mandatory',mandatory::boolean
                                                            ,'historized',historized
                                                            ,'stereotype', stereotype
                                                            ,'inheritedfrom', ifnull(inheritedfrom, '-')
                                                            ,'path', ifnull(mde_AttributePath, '')
                                                            )
                                                )
                  ) 
       as attributes_json
  from attributes_extended
 group by entity_uuid
 
 