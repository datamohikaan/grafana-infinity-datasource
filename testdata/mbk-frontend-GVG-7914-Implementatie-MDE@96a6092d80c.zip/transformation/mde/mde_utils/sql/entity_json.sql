select ent.model_uuid
     , ent.uuid as entity_uuid
     , json_object('code',ent.code
                  ,'name',ent.name 
                  ,'uuid', ent.uuid
                  ,'comment',ent.comment
                  ,'stereotype', ent.stereotype
                  ,'description', ent.description
                  ,'sql_expression', ent.mdde_sql_expression
                  ,'path', ent.mde_EntityPath                  
                  ,'validity', 
                  json_object(
                    'functional_validity_type', ent.mde_TypeOfFunctionalValidity,
                    'functional_valid_from_field', func_val_from.code,
                    'functional_valid_until_field', func_val_until.code,
                    'functional_valid_until_is_inclusive', ent.mde_FunctionalUntilFieldIsInclusive,
                    'technical_valid_from_field', tech_val_from.code,
                    'technical_valid_until_field', tech_val_until.code,
                    'technical_valid_until_is_inclusive', ent.mde_TechnicalUntilFieldIsInclusive
                  )
                  ) 
       as entity_json
  from '%MDE_SOURCE_PATH%/entity.parquet' ent
  left join '%MDE_SOURCE_PATH%/attribute.parquet' func_val_from
   on ent.mde_FunctionalValidFromField = func_val_from.oid
  left join '%MDE_SOURCE_PATH%/attribute.parquet' func_val_until
   on ent.mde_FunctionalValidUntilField = func_val_until.oid
  left join '%MDE_SOURCE_PATH%/attribute.parquet' tech_val_from
   on ent.mde_TechnicalValidFromField = tech_val_from.oid
  left join '%MDE_SOURCE_PATH%/attribute.parquet' tech_val_until
   on ent.mde_TechnicalValidUntilField = tech_val_until.oid 
 where coalesce(ent.stereotype,'') not in ('tijdscontext','beweringscontext','registratiecontext','contextgroep')