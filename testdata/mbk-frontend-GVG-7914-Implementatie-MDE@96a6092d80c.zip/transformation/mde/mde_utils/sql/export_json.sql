select model_json as model
     
     --, entities_json as entities
from model_json
-- left join entities_json using(model_uuid)
