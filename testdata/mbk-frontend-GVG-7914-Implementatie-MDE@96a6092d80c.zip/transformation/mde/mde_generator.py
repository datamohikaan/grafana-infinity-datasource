# import psycopg
# import pandas as pd
# import os
# import shutil
#
# import yaml
#
# from transformation.mde.pd_ldm_preprocessor import PowerDesignerLDMPreprocessor
# from transformation.mde import xml_extractor, ldm2yaml, mde_generator
# from frontend.ep.config import DB_CONFIG
#
# if __name__ == "__main__":
#     # Clear output directory
#     if (os.path.isdir('./mde/output'.replace("/", os.sep))):
#         shutil.rmtree('./mde/output'.replace("/", os.sep))
#
#     # Recreate output directory
#     os.mkdir('./mde/output'.replace("/", os.sep))
#
#     # Run preprocessor
#     preprocessor: PowerDesignerLDMPreprocessor = PowerDesignerLDMPreprocessor()
#     #preprocessor.preprocess_ldm("C:\\Users\\akbam04\\Modellenbibliotheek\\mbk-frontend\\mbk-frontend\\transformation\\mde\\LGA_MBK_Testmodel.ldm")
#     #preprocessor.preprocess_ldm("C:\\Users\\akbam04\\Modellenbibliotheek\\mbk-frontend\\mbk-frontend\\transformation\\mde\\bag.ldm")
#     preprocessor.preprocess_ldm("/transformation/mde/LGD_EXM_Ander_kennisgebied_Kern.ldm")
#     # Run extractor
#     xml_extractor.extract("mde/LGD_EXM_Ander_kennisgebied_Kern_preprocessed.ldm", "mde/powerdesigner-extractor-config.yml", "mde/output".replace("/", os.sep))
#
#     # Run YML convertor
#     #ldm2yaml.generate_yml(source_path="mde/output".replace("/", os.sep), target_file="./LGA_MBK_Testmodel.yml".replace("/", os.sep))
#     #ldm2yaml.generate_yml(source_path="mde/output".replace("/", os.sep), target_file="./bag.yml".replace("/", os.sep))
#     ldm2yaml.generate_yml(source_path="mde/output".replace("/", os.sep), target_file="./LGD_EXM_Ander_kennisgebied_Kern.yml".replace("/", os.sep))
#
#     with open("/transformation/LGD_EXM_Ander_kennisgebied_Kern.yml", "r") as file:
#         yaml_data = yaml.safe_load(file)
#
#     df = pd.DataFrame(yaml_data)
#     print(df)
#
#
#     # # Run Code generator
#     # #generator.generate(config_file="./mde/generator-config.yml".replace("/", os.sep), model_file="./LGA_MBK_Testmodel.yml".replace("/", os.sep))
#     # generator.generate(config_file="./mde/generator-config.yml".replace("/", os.sep), model_file="./bag.yml".replace("/", os.sep))
#     # conn = psycopg.connect(**DB_CONFIG)
#     # cur = conn.cursor()
#     # output_dir = f"{os.path.dirname(__file__)}/mde/output".replace("/", os.sep)
#     # schemas = []
#     # tables = []
#     #
#     # # Deploy objects to database
#     # for subdir, dirs, files in os.walk(output_dir):
#     #     for file in files:
#     #         if (file.startswith("schema_") and file.endswith(".sql")):
#     #             schemas.append(file)
#     #         if (file.startswith("table_") and file.endswith(".sql")):
#     #             tables.append(file)
#     #
#     # # Drop all tables before (re)create
#     # for table in tables:
#     #     tab = table[6:].replace(".sql", "").replace("__", ".", 1)
#     #     qry = f"DROP TABLE IF EXISTS {tab};"
#     #     cur.execute(qry)
#     #     conn.commit()
#     #
#     # # Drop all schema's before (re)create
#     # for schema in schemas:
#     #     schma = schema[7:].replace(".sql", "")
#     #     qry = f"DROP SCHEMA IF EXISTS {schma};"
#     #     cur.execute(qry)
#     #     conn.commit()
#     #
#     # # Schema's
#     # for schema in schemas:
#     #     with open(file=f"{output_dir}/{schema}", mode='r') as f:
#     #         qry = f.read()
#     #         cur.execute(qry)
#     #         conn.commit()
#     #
#     # # Tables
#     # for table in tables:
#     #     with open(file=f"{output_dir}/{table}", mode='r') as f:
#     #         qry = f.read()
#     #         cur.execute(qry)
#     #         conn.commit()
#     #
#     #conn.close()