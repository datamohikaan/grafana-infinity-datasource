# export MDE_PATH=`pwd`
import sys
import logging
import os
import duckdb
import yaml
import json


def read_from_file(file_name: str, source_path: str) -> str:
    with open(file=file_name, mode='r') as f:
        return f.read().replace('%MDE_SOURCE_PATH%', source_path).replace("/", os.sep)

# funtie om None waarden uit de dictionary te filteren
def delete_none(_dict):
    """Delete None values recursively from all of the dictionaries, tuples, lists, sets"""
    if isinstance(_dict, dict):
        for key, value in list(_dict.items()):
            if isinstance(value, (list, dict, tuple, set)):
                _dict[key] = delete_none(value)
            elif value is None or key is None:
                del _dict[key]
    elif isinstance(_dict, (list, set, tuple)):
        _dict = type(_dict)(delete_none(item) for item in _dict if item is not None)

    return _dict

def generate_json (source_path: str, target_file: str):
    # query path is relatief aan deze file
    #query_path: str = f"{os.path.dirname(__file__)}/queries"
    query_path: str = f"{os.path.dirname(__file__)}" + os.sep + "mde_utils" + os.sep + "sql"
    # maak het attributes json blok voor een entity
    attributes_json = duckdb.sql(read_from_file(file_name=f"{query_path}/entity_attributes_json.sql".replace("/", os.sep), source_path=source_path))
    # maak het entity json , filter de context entities uit
    entity_json = duckdb.sql(read_from_file(file_name=f"{query_path}/entity_json.sql".replace("/", os.sep), source_path=source_path))
    # combineer entity en attribute json
    entity_attributes_json = duckdb.sql(read_from_file(file_name=f"{query_path}/entity_with_attributes_json.sql".replace("/", os.sep), source_path=source_path))

    # maak namespaces json aan
    namespaces_json = duckdb.sql(read_from_file(file_name=f"{query_path}/namespaces_json.sql".replace("/", os.sep), source_path=source_path))
    # combineer identifier attributes json
    identifiers_json = duckdb.sql(read_from_file(file_name=f"{query_path}/identifiers_json.sql".replace("/", os.sep), source_path=source_path))
    # Maak mappings aan incl attribute mappings
    mappings_json = duckdb.sql(read_from_file(file_name=f"{query_path}/mappings_with_attribute_mappings_json.sql".replace("/", os.sep), source_path=source_path))
    # Joins en join conditions
    joins_json = duckdb.sql(read_from_file(file_name=f"{query_path}/mappings_source_joins_json.sql".replace("/", os.sep), source_path=source_path))
    # Voeg samen en aggregeer naar entiteitniveau
    mappings_for_entity_json = duckdb.sql(read_from_file(file_name=f"{query_path}/mappings_for_entity_json.sql".replace("/", os.sep), source_path=source_path))
    # combineer entity en identifiers json
    entities_json = duckdb.sql(read_from_file(file_name=f"{query_path}/entity_with_mappings_and_identifiers.sql".replace("/", os.sep), source_path=source_path))
    model_json = duckdb.sql(read_from_file(file_name=f"{query_path}/model_json.sql", source_path=source_path))
    # maak relationships aan incl joins
    relationships_json = duckdb.sql(read_from_file(file_name=f"{query_path}/relationship_json.sql".replace("/", os.sep), source_path=source_path))
    # maak inheritance relationships
    inheritance_relationships_json = duckdb.sql(read_from_file(file_name=f"{query_path}/inheritance_relationships_json.sql".replace("/", os.sep), source_path=source_path))
    # groepeer de inheritance links op inheritance in een json array
    # maak inheritances json aan
    inheritances_json = duckdb.sql(read_from_file(file_name=f"{query_path}/inheritances_json.sql".replace("/", os.sep), source_path=source_path))
    # combineer de top level json objecten tot een model json tbv json export

    export_json = duckdb.sql(read_from_file(file_name=f"{query_path}/export_json.sql".replace("/", os.sep), source_path=source_path))
    # export export_json naar bestand
    duckdb.sql(f"copy(select * from export_json) to '{source_path}/ldm.json'")
    # open model (json)
    # model_dict = {}
    with open(f'{source_path}/ldm.json', 'r') as json_file:
        model_dict = json.load(json_file)
    # verwijder alle None's uit de dictionairy
    # model_dict_no_none =
    delete_none(model_dict)
    # schijf weg als model yaml bestand
    # with open(f'{target_file}', 'w') as yaml_file:
    #     yaml.dump(model_dict, yaml_file, sort_keys=False, default_flow_style=False, allow_unicode=True, width=500)